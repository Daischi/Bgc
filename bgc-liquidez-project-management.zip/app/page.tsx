"use client";

import { useState } from "react";
import { AppProvider } from "@/lib/app-context";
import { Sidebar } from "@/components/sidebar";
import { MainContent } from "@/components/main-content";
import { SettingsPanel } from "@/components/settings-panel";
import { MobileSidebar, MobileHeader } from "@/components/mobile-sidebar";

function Dashboard() {
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  return (
    <div className="flex flex-col lg:flex-row min-h-screen">
      {/* Desktop Sidebar */}
      <div className="hidden lg:block w-72 shrink-0">
        <Sidebar onOpenSettings={() => setIsSettingsOpen(true)} />
      </div>

      {/* Mobile Header */}
      <MobileHeader onOpenSidebar={() => setIsMobileSidebarOpen(true)} />

      {/* Mobile Sidebar */}
      <MobileSidebar
        isOpen={isMobileSidebarOpen}
        onClose={() => setIsMobileSidebarOpen(false)}
        onOpenSettings={() => setIsSettingsOpen(true)}
      />

      {/* Main Content */}
      <MainContent onOpenSettings={() => setIsSettingsOpen(true)} />

      {/* Settings Panel */}
      <SettingsPanel
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
      />
    </div>
  );
}

export default function Home() {
  return (
    <AppProvider>
      <Dashboard />
    </AppProvider>
  );
}
