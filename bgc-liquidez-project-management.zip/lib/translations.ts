export type Language = "pt-BR" | "en-US";

export const translations = {
  "pt-BR": {
    projectManagement: "Gestao de Projetos",
    projects: "Projetos",
    project: "Projeto",
    followProgress: "Acompanhe o progresso das fases do projeto",
    overallProgress: "Progresso Geral",
    aboutProject: "Sobre o Projeto",
    phase: "Fase",
    phases_label: "Fases",
    aboutPhase: "SOBRE ESTA FASE",
    activities: "ATIVIDADES",
    tasksCompleted: "tarefas concluidas",
    settings: "Configuracoes",
    theme: "Tema",
    lightTheme: "Tema Claro",
    darkTheme: "Tema Escuro",
    language: "Idioma",
    portuguese: "Portugues",
    english: "Ingles",
    close: "Fechar",
    dashboard: "Dashboard",
    completedProjects: "Concluidos",
    inProgress: "Em Andamento",
    noCompletedProjects: "Nenhum projeto concluido ainda",
    projectsOverview: "Visao Geral dos Projetos",
    totalProjects: "Total de Projetos",
    completed: "Concluidos",
    averageProgress: "Progresso Medio",
    projectPhases: "FASES DO PROJETO",
    // Project phases
    phases: {
      about: "Sobre o Projeto",
      phase1: "Fase 1",
      phase2: "Fase 2",
      phase3: "Fase 3",
      phase4: "Fase 4",
    },
    // Phase titles
    phaseTitles: {
      about: "Sobre o Projeto",
      phase1: "Planejamento e Analise Inicial",
      phase2: "Desenvolvimento e Implementacao",
      phase3: "Testes e Validacao",
      phase4: "Entrega e Monitoramento",
    },
    // Phase descriptions
    phaseDescriptions: {
      about:
        "Sistema de gestao integrada para otimizar processos internos da BGC Liquidez, incluindo automacao de fluxos de trabalho, integracao com sistemas legados e dashboard de acompanhamento em tempo real.",
      phase1:
        "Nesta fase inicial, focamos em entender completamente o escopo do projeto, levantando todos os requisitos funcionais e nao-funcionais junto aos stakeholders. Realizamos analises detalhadas do ambiente atual e definimos a arquitetura da solucao.",
      phase2:
        "Durante esta fase, a equipe de desenvolvimento implementa as funcionalidades planejadas. Utilizamos metodologias ageis para entregas incrementais, permitindo feedback continuo e ajustes rapidos conforme necessario.",
      phase3:
        "Fase dedicada a validacao completa da solucao. Executamos testes unitarios, de integracao e de aceitacao do usuario. Corrigimos bugs identificados e otimizamos a performance do sistema.",
      phase4:
        "Na fase final, realizamos a implantacao em producao, treinamento dos usuarios e configuracao do monitoramento continuo. Estabelecemos metricas de sucesso e acompanhamos os indicadores de performance.",
    },
    // Tasks with descriptions
    tasks: {
      about: [
        {
          title: "Revisar documentacao inicial do projeto",
          description: "Analisar todos os documentos de escopo, requisitos e especificacoes tecnicas fornecidos pelos stakeholders."
        },
        {
          title: "Alinhar objetivos com stakeholders",
          description: "Realizar reunioes de alinhamento para garantir que todos os envolvidos estejam de acordo com os objetivos do projeto."
        },
        {
          title: "Definir marcos e entregas principais",
          description: "Estabelecer os principais milestones do projeto e as entregas esperadas em cada fase."
        },
      ],
      phase1: [
        {
          title: "Realizar levantamento de requisitos",
          description: "Conduzir entrevistas e workshops com usuarios para identificar todas as necessidades do sistema."
        },
        {
          title: "Documentar requisitos funcionais",
          description: "Criar documentacao detalhada de todos os requisitos funcionais identificados no levantamento."
        },
        {
          title: "Aprovar documento de escopo",
          description: "Obter aprovacao formal do documento de escopo com todos os stakeholders principais."
        },
      ],
      phase2: [
        {
          title: "Configurar ambiente de desenvolvimento",
          description: "Preparar toda a infraestrutura necessaria para o desenvolvimento, incluindo servidores e ferramentas."
        },
        {
          title: "Desenvolver modulo principal",
          description: "Implementar as funcionalidades core do sistema seguindo as especificacoes aprovadas."
        },
        {
          title: "Implementar integracoes",
          description: "Desenvolver as integracoes com sistemas externos e APIs de terceiros."
        },
        {
          title: "Revisar codigo com equipe",
          description: "Realizar code reviews em equipe para garantir qualidade e padronizacao do codigo."
        },
      ],
      phase3: [
        {
          title: "Executar testes unitarios",
          description: "Criar e executar testes unitarios para validar cada componente individualmente."
        },
        {
          title: "Realizar testes de integracao",
          description: "Testar a integracao entre os diferentes modulos e sistemas externos."
        },
        {
          title: "Conduzir testes de aceitacao",
          description: "Realizar testes com usuarios finais para validar se o sistema atende aos requisitos."
        },
        {
          title: "Documentar resultados",
          description: "Registrar todos os resultados dos testes e criar relatorios de qualidade."
        },
      ],
      phase4: [
        {
          title: "Preparar ambiente de producao",
          description: "Configurar servidores de producao e realizar deploy do ambiente."
        },
        {
          title: "Realizar deploy da aplicacao",
          description: "Executar o deploy da aplicacao em producao seguindo o plano de rollout."
        },
        {
          title: "Treinar usuarios finais",
          description: "Conduzir sessoes de treinamento para capacitar os usuarios no uso do sistema."
        },
        {
          title: "Configurar monitoramento",
          description: "Implementar ferramentas de monitoramento e alertas para acompanhamento continuo."
        },
      ],
    },
  },
  "en-US": {
    projectManagement: "Project Management",
    projects: "Projects",
    project: "Project",
    followProgress: "Track the progress of project phases",
    overallProgress: "Overall Progress",
    aboutProject: "About Project",
    phase: "Phase",
    phases_label: "Phases",
    aboutPhase: "ABOUT THIS PHASE",
    activities: "ACTIVITIES",
    tasksCompleted: "tasks completed",
    settings: "Settings",
    theme: "Theme",
    lightTheme: "Light Theme",
    darkTheme: "Dark Theme",
    language: "Language",
    portuguese: "Portuguese",
    english: "English",
    close: "Close",
    dashboard: "Dashboard",
    completedProjects: "Completed",
    inProgress: "In Progress",
    noCompletedProjects: "No completed projects yet",
    projectsOverview: "Projects Overview",
    totalProjects: "Total Projects",
    completed: "Completed",
    averageProgress: "Average Progress",
    projectPhases: "PROJECT PHASES",
    // Project phases
    phases: {
      about: "About Project",
      phase1: "Phase 1",
      phase2: "Phase 2",
      phase3: "Phase 3",
      phase4: "Phase 4",
    },
    // Phase titles
    phaseTitles: {
      about: "About Project",
      phase1: "Planning and Initial Analysis",
      phase2: "Development and Implementation",
      phase3: "Testing and Validation",
      phase4: "Delivery and Monitoring",
    },
    // Phase descriptions
    phaseDescriptions: {
      about:
        "Integrated management system to optimize internal processes at BGC Liquidez, including workflow automation, legacy system integration and real-time monitoring dashboard.",
      phase1:
        "In this initial phase, we focus on fully understanding the project scope, gathering all functional and non-functional requirements from stakeholders. We conduct detailed analyses of the current environment and define the solution architecture.",
      phase2:
        "During this phase, the development team implements planned features. We use agile methodologies for incremental deliveries, allowing continuous feedback and quick adjustments as needed.",
      phase3:
        "Phase dedicated to complete solution validation. We run unit, integration, and user acceptance tests. We fix identified bugs and optimize system performance.",
      phase4:
        "In the final phase, we perform production deployment, user training, and continuous monitoring setup. We establish success metrics and track performance indicators.",
    },
    // Tasks with descriptions
    tasks: {
      about: [
        {
          title: "Review initial project documentation",
          description: "Analyze all scope documents, requirements and technical specifications provided by stakeholders."
        },
        {
          title: "Align objectives with stakeholders",
          description: "Conduct alignment meetings to ensure all involved parties agree on project objectives."
        },
        {
          title: "Define milestones and main deliverables",
          description: "Establish the main project milestones and expected deliverables for each phase."
        },
      ],
      phase1: [
        {
          title: "Conduct requirements gathering",
          description: "Conduct interviews and workshops with users to identify all system needs."
        },
        {
          title: "Document functional requirements",
          description: "Create detailed documentation of all functional requirements identified during gathering."
        },
        {
          title: "Approve scope document",
          description: "Obtain formal approval of the scope document from all key stakeholders."
        },
      ],
      phase2: [
        {
          title: "Configure development environment",
          description: "Prepare all necessary infrastructure for development, including servers and tools."
        },
        {
          title: "Develop main module",
          description: "Implement core system functionalities following approved specifications."
        },
        {
          title: "Implement integrations",
          description: "Develop integrations with external systems and third-party APIs."
        },
        {
          title: "Review code with team",
          description: "Perform team code reviews to ensure quality and code standardization."
        },
      ],
      phase3: [
        {
          title: "Execute unit tests",
          description: "Create and execute unit tests to validate each component individually."
        },
        {
          title: "Perform integration tests",
          description: "Test integration between different modules and external systems."
        },
        {
          title: "Conduct acceptance tests",
          description: "Perform tests with end users to validate if the system meets requirements."
        },
        {
          title: "Document results",
          description: "Record all test results and create quality reports."
        },
      ],
      phase4: [
        {
          title: "Prepare production environment",
          description: "Configure production servers and perform environment deployment."
        },
        {
          title: "Deploy application",
          description: "Execute application deployment in production following rollout plan."
        },
        {
          title: "Train end users",
          description: "Conduct training sessions to enable users to use the system."
        },
        {
          title: "Configure monitoring",
          description: "Implement monitoring tools and alerts for continuous tracking."
        },
      ],
    },
  },
};

export function getTranslation(lang: Language) {
  return translations[lang];
}
