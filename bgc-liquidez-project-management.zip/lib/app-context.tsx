"use client";

import {
  createContext,
  useContext,
  useState,
  useEffect,
  type ReactNode,
} from "react";
import { type Language, getTranslation } from "./translations";
import {
  type Project,
  initialProjects,
  calculateProjectProgress,
  calculatePhaseProgress,
} from "./project-data";

type ViewType = "dashboard" | "project" | "completed";

interface AppContextType {
  // Theme
  theme: "light" | "dark";
  setTheme: (theme: "light" | "dark") => void;
  // Language
  language: Language;
  setLanguage: (language: Language) => void;
  t: ReturnType<typeof getTranslation>;
  // View
  currentView: ViewType;
  setCurrentView: (view: ViewType) => void;
  // Projects
  projects: Project[];
  selectedProjectId: string;
  setSelectedProjectId: (id: string) => void;
  selectedPhaseId: string;
  setSelectedPhaseId: (id: string) => void;
  // Actions
  toggleTask: (projectId: string, phaseId: string, taskId: string) => void;
  getProjectProgress: (projectId: string) => number;
  getPhaseProgress: (projectId: string, phaseId: string) => number;
  getCompletedProjects: () => Project[];
  getInProgressProjects: () => Project[];
  getTotalTasksCount: (projectId: string) => { completed: number; total: number };
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEY = "bgc-liquidez-data";

interface StoredData {
  theme: "light" | "dark";
  language: Language;
  projects: Project[];
  selectedProjectId: string;
  selectedPhaseId: string;
  currentView: ViewType;
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<"light" | "dark">("light");
  const [language, setLanguageState] = useState<Language>("pt-BR");
  const [projects, setProjects] = useState<Project[]>(initialProjects);
  const [selectedProjectId, setSelectedProjectId] = useState("project-1");
  const [selectedPhaseId, setSelectedPhaseId] = useState("about");
  const [currentView, setCurrentView] = useState<ViewType>("dashboard");
  const [isHydrated, setIsHydrated] = useState(false);

  // Load data from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        const data: StoredData = JSON.parse(stored);
        setThemeState(data.theme);
        setLanguageState(data.language);
        setProjects(data.projects);
        setSelectedProjectId(data.selectedProjectId);
        setSelectedPhaseId(data.selectedPhaseId);
        if (data.currentView) {
          setCurrentView(data.currentView);
        }
      } catch {
        // If parsing fails, use defaults
      }
    }
    setIsHydrated(true);
  }, []);

  // Apply theme class to document
  useEffect(() => {
    if (isHydrated) {
      document.documentElement.classList.toggle("dark", theme === "dark");
    }
  }, [theme, isHydrated]);

  // Save data to localStorage whenever it changes
  useEffect(() => {
    if (isHydrated) {
      const data: StoredData = {
        theme,
        language,
        projects,
        selectedProjectId,
        selectedPhaseId,
        currentView,
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    }
  }, [theme, language, projects, selectedProjectId, selectedPhaseId, currentView, isHydrated]);

  const setTheme = (newTheme: "light" | "dark") => {
    setThemeState(newTheme);
  };

  const setLanguage = (newLanguage: Language) => {
    setLanguageState(newLanguage);
  };

  const toggleTask = (projectId: string, phaseId: string, taskId: string) => {
    setProjects((prev) =>
      prev.map((project) => {
        if (project.id !== projectId) return project;
        return {
          ...project,
          phases: project.phases.map((phase) => {
            if (phase.id !== phaseId) return phase;
            return {
              ...phase,
              tasks: phase.tasks.map((task) => {
                if (task.id !== taskId) return task;
                return { ...task, completed: !task.completed };
              }),
            };
          }),
        };
      })
    );
  };

  const getProjectProgress = (projectId: string): number => {
    const project = projects.find((p) => p.id === projectId);
    return project ? calculateProjectProgress(project) : 0;
  };

  const getPhaseProgress = (projectId: string, phaseId: string): number => {
    const project = projects.find((p) => p.id === projectId);
    const phase = project?.phases.find((p) => p.id === phaseId);
    return phase ? calculatePhaseProgress(phase) : 0;
  };

  const getCompletedProjects = (): Project[] => {
    return projects.filter((p) => calculateProjectProgress(p) === 100);
  };

  const getInProgressProjects = (): Project[] => {
    return projects.filter((p) => calculateProjectProgress(p) < 100);
  };

  const getTotalTasksCount = (projectId: string): { completed: number; total: number } => {
    const project = projects.find((p) => p.id === projectId);
    if (!project) return { completed: 0, total: 0 };
    const allTasks = project.phases.flatMap((phase) => phase.tasks);
    const completed = allTasks.filter((task) => task.completed).length;
    return { completed, total: allTasks.length };
  };

  const t = getTranslation(language);

  if (!isHydrated) {
    return null;
  }

  return (
    <AppContext.Provider
      value={{
        theme,
        setTheme,
        language,
        setLanguage,
        t,
        currentView,
        setCurrentView,
        projects,
        selectedProjectId,
        setSelectedProjectId,
        selectedPhaseId,
        setSelectedPhaseId,
        toggleTask,
        getProjectProgress,
        getPhaseProgress,
        getCompletedProjects,
        getInProgressProjects,
        getTotalTasksCount,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error("useApp must be used within an AppProvider");
  }
  return context;
}
