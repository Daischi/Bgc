export interface Task {
  id: string;
  completed: boolean;
}

export interface Phase {
  id: string;
  tasks: Task[];
}

export interface Project {
  id: string;
  name: string;
  phases: Phase[];
}

export const initialProjects: Project[] = [
  {
    id: "project-1",
    name: "Projeto 1",
    phases: [
      {
        id: "about",
        tasks: [
          { id: "about-1", completed: false },
          { id: "about-2", completed: false },
          { id: "about-3", completed: false },
        ],
      },
      {
        id: "phase1",
        tasks: [
          { id: "phase1-1", completed: false },
          { id: "phase1-2", completed: false },
          { id: "phase1-3", completed: false },
        ],
      },
      {
        id: "phase2",
        tasks: [
          { id: "phase2-1", completed: false },
          { id: "phase2-2", completed: false },
          { id: "phase2-3", completed: false },
          { id: "phase2-4", completed: false },
        ],
      },
      {
        id: "phase3",
        tasks: [
          { id: "phase3-1", completed: false },
          { id: "phase3-2", completed: false },
          { id: "phase3-3", completed: false },
          { id: "phase3-4", completed: false },
        ],
      },
      {
        id: "phase4",
        tasks: [
          { id: "phase4-1", completed: false },
          { id: "phase4-2", completed: false },
          { id: "phase4-3", completed: false },
          { id: "phase4-4", completed: false },
        ],
      },
    ],
  },
  {
    id: "project-2",
    name: "Projeto 2",
    phases: [
      {
        id: "about",
        tasks: [
          { id: "about-1", completed: false },
          { id: "about-2", completed: false },
          { id: "about-3", completed: false },
        ],
      },
      {
        id: "phase1",
        tasks: [
          { id: "phase1-1", completed: false },
          { id: "phase1-2", completed: false },
          { id: "phase1-3", completed: false },
        ],
      },
      {
        id: "phase2",
        tasks: [
          { id: "phase2-1", completed: false },
          { id: "phase2-2", completed: false },
          { id: "phase2-3", completed: false },
          { id: "phase2-4", completed: false },
        ],
      },
      {
        id: "phase3",
        tasks: [
          { id: "phase3-1", completed: false },
          { id: "phase3-2", completed: false },
          { id: "phase3-3", completed: false },
          { id: "phase3-4", completed: false },
        ],
      },
      {
        id: "phase4",
        tasks: [
          { id: "phase4-1", completed: false },
          { id: "phase4-2", completed: false },
          { id: "phase4-3", completed: false },
          { id: "phase4-4", completed: false },
        ],
      },
    ],
  },
  {
    id: "project-3",
    name: "Projeto 3",
    phases: [
      {
        id: "about",
        tasks: [
          { id: "about-1", completed: false },
          { id: "about-2", completed: false },
          { id: "about-3", completed: false },
        ],
      },
      {
        id: "phase1",
        tasks: [
          { id: "phase1-1", completed: false },
          { id: "phase1-2", completed: false },
          { id: "phase1-3", completed: false },
        ],
      },
      {
        id: "phase2",
        tasks: [
          { id: "phase2-1", completed: false },
          { id: "phase2-2", completed: false },
          { id: "phase2-3", completed: false },
          { id: "phase2-4", completed: false },
        ],
      },
      {
        id: "phase3",
        tasks: [
          { id: "phase3-1", completed: false },
          { id: "phase3-2", completed: false },
          { id: "phase3-3", completed: false },
          { id: "phase3-4", completed: false },
        ],
      },
      {
        id: "phase4",
        tasks: [
          { id: "phase4-1", completed: false },
          { id: "phase4-2", completed: false },
          { id: "phase4-3", completed: false },
          { id: "phase4-4", completed: false },
        ],
      },
    ],
  },
];

export function calculateProjectProgress(project: Project): number {
  const allTasks = project.phases.flatMap((phase) => phase.tasks);
  const completedTasks = allTasks.filter((task) => task.completed).length;
  return allTasks.length > 0
    ? Math.round((completedTasks / allTasks.length) * 100)
    : 0;
}

export function calculatePhaseProgress(phase: Phase): number {
  const completedTasks = phase.tasks.filter((task) => task.completed).length;
  return phase.tasks.length > 0
    ? Math.round((completedTasks / phase.tasks.length) * 100)
    : 0;
}
