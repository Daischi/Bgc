"use client";

import { useApp } from "@/lib/app-context";
import { CheckCircle, Trophy, Calendar } from "lucide-react";

export function CompletedView() {
  const {
    t,
    getCompletedProjects,
    getTotalTasksCount,
    setCurrentView,
    setSelectedProjectId,
    setSelectedPhaseId,
  } = useApp();

  const completedProjects = getCompletedProjects();

  const handleProjectClick = (projectId: string) => {
    setSelectedProjectId(projectId);
    setSelectedPhaseId("about");
    setCurrentView("project");
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <div className="w-14 h-14 rounded-full bg-green-500/10 flex items-center justify-center">
          <Trophy className="w-7 h-7 text-green-500" />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-foreground">{t.completedProjects}</h1>
          <p className="text-muted-foreground mt-1">
            {completedProjects.length} {completedProjects.length === 1 ? "projeto concluido" : "projetos concluidos"}
          </p>
        </div>
      </div>

      {completedProjects.length === 0 ? (
        <div className="bg-card rounded-xl p-12 border border-border text-center">
          <div className="w-20 h-20 rounded-full bg-muted mx-auto mb-4 flex items-center justify-center">
            <CheckCircle className="w-10 h-10 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-semibold text-card-foreground mb-2">
            {t.noCompletedProjects}
          </h3>
          <p className="text-muted-foreground max-w-md mx-auto">
            Continue trabalhando nos seus projetos. Quando um projeto atingir 100% de progresso, ele aparecera aqui.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {completedProjects.map((project) => {
            const { total } = getTotalTasksCount(project.id);

            return (
              <button
                key={project.id}
                onClick={() => handleProjectClick(project.id)}
                className="w-full text-left bg-card rounded-xl p-6 border border-border hover:border-green-500/50 hover:shadow-lg transition-all group"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full bg-green-500/10 flex items-center justify-center group-hover:bg-green-500/20 transition-colors">
                      <CheckCircle className="w-6 h-6 text-green-500" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-card-foreground text-lg">{project.name}</h3>
                      <p className="text-sm text-muted-foreground">
                        {total} tarefas concluidas
                      </p>
                    </div>
                  </div>
                  <span className="px-3 py-1 bg-green-500/10 text-green-600 text-sm font-medium rounded-full">
                    100%
                  </span>
                </div>

                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Calendar className="w-4 h-4" />
                  <span>Projeto finalizado com sucesso</span>
                </div>

                {/* Progress bars all at 100% */}
                <div className="mt-4 space-y-2">
                  {["phase1", "phase2", "phase3", "phase4"].map((phaseId) => (
                    <div key={phaseId} className="h-1 bg-green-500 rounded-full" />
                  ))}
                </div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
