"use client";

import { useApp } from "@/lib/app-context";
import { ProgressCircle } from "./progress-circle";
import { Check, ChevronDown, ChevronUp } from "lucide-react";
import { useState } from "react";

export function PhaseContent() {
  const {
    t,
    projects,
    selectedProjectId,
    selectedPhaseId,
    toggleTask,
    getPhaseProgress,
  } = useApp();

  const [expandedTasks, setExpandedTasks] = useState<Set<string>>(new Set());

  const project = projects.find((p) => p.id === selectedProjectId);
  const phase = project?.phases.find((p) => p.id === selectedPhaseId);

  if (!project || !phase) return null;

  const progress = getPhaseProgress(selectedProjectId, selectedPhaseId);
  const completedCount = phase.tasks.filter((t) => t.completed).length;
  const totalTasks = phase.tasks.length;

  const phaseTitle =
    t.phaseTitles[selectedPhaseId as keyof typeof t.phaseTitles];
  const phaseDescription =
    t.phaseDescriptions[selectedPhaseId as keyof typeof t.phaseDescriptions];
  const taskTexts = t.tasks[selectedPhaseId as keyof typeof t.tasks];

  const toggleExpanded = (taskId: string) => {
    setExpandedTasks((prev) => {
      const next = new Set(prev);
      if (next.has(taskId)) {
        next.delete(taskId);
      } else {
        next.add(taskId);
      }
      return next;
    });
  };

  return (
    <div className="space-y-6">
      {/* Phase Card Header */}
      <div className="bg-card rounded-xl p-6 border border-border">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <h3 className="text-xl font-semibold text-card-foreground">
              {phaseTitle}
            </h3>
            <p className="text-sm text-muted-foreground mt-1">
              {completedCount} de {totalTasks} {t.tasksCompleted}
            </p>
            {/* Progress Bar */}
            <div className="mt-4 h-2 bg-muted rounded-full overflow-hidden">
              <div
                className="h-full bg-primary rounded-full transition-all duration-500 ease-out"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
          <ProgressCircle progress={progress} size="md" className="ml-6" />
        </div>
      </div>

      {/* About This Phase */}
      <div className="bg-card rounded-xl p-6 border border-border">
        <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">
          {t.aboutPhase}
        </h4>
        <p className="text-card-foreground leading-relaxed">{phaseDescription}</p>
      </div>

      {/* Activities */}
      <div className="bg-card rounded-xl p-6 border border-border">
        <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-4">
          {t.activities}
        </h4>
        <ul className="space-y-2">
          {phase.tasks.map((task, index) => {
            const taskData = taskTexts[index];
            const isExpanded = expandedTasks.has(task.id);
            
            return (
              <li key={task.id} className="border border-border rounded-lg overflow-hidden">
                <div className="flex items-center gap-3 p-4 hover:bg-muted/30 transition-colors">
                  <button
                    onClick={() => toggleTask(selectedProjectId, selectedPhaseId, task.id)}
                    className={`w-5 h-5 rounded flex-shrink-0 flex items-center justify-center border-2 transition-all ${
                      task.completed
                        ? "bg-primary border-primary"
                        : "border-muted-foreground hover:border-primary"
                    }`}
                  >
                    {task.completed && (
                      <Check className="w-3 h-3 text-primary-foreground" />
                    )}
                  </button>
                  <div className="flex-1 min-w-0">
                    <span
                      className={`block transition-all ${
                        task.completed
                          ? "text-muted-foreground line-through"
                          : "text-card-foreground"
                      }`}
                    >
                      {taskData.title}
                    </span>
                  </div>
                  <button
                    onClick={() => toggleExpanded(task.id)}
                    className="p-1 hover:bg-muted rounded transition-colors text-muted-foreground hover:text-foreground"
                  >
                    {isExpanded ? (
                      <ChevronUp className="w-4 h-4" />
                    ) : (
                      <ChevronDown className="w-4 h-4" />
                    )}
                  </button>
                </div>
                {isExpanded && (
                  <div className="px-4 pb-4 pt-0 ml-8 border-t border-border mt-0">
                    <p className="text-sm text-muted-foreground pt-3">
                      {taskData.description}
                    </p>
                  </div>
                )}
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}
