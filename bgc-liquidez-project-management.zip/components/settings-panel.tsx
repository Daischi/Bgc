"use client";

import { useApp } from "@/lib/app-context";
import { X, Sun, Moon, Globe } from "lucide-react";
import type { Language } from "@/lib/translations";

interface SettingsPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SettingsPanel({ isOpen, onClose }: SettingsPanelProps) {
  const { t, theme, setTheme, language, setLanguage } = useApp();

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/50 z-40 transition-opacity"
        onClick={onClose}
      />

      {/* Panel */}
      <div className="fixed right-0 top-0 bottom-0 w-80 bg-card z-50 shadow-2xl border-l border-border animate-in slide-in-from-right duration-300">
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-border">
            <h2 className="text-lg font-semibold text-card-foreground">
              {t.settings}
            </h2>
            <button
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
              aria-label={t.close}
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 p-6 space-y-8">
            {/* Theme Section */}
            <div>
              <h3 className="flex items-center gap-2 text-sm font-semibold text-card-foreground mb-4">
                <Sun className="w-4 h-4" />
                {t.theme}
              </h3>
              <div className="space-y-2">
                <button
                  onClick={() => setTheme("light")}
                  className={`w-full flex items-center gap-3 p-3 rounded-lg transition-all ${
                    theme === "light"
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted hover:bg-muted/80 text-card-foreground"
                  }`}
                >
                  <Sun className="w-5 h-5" />
                  <span>{t.lightTheme}</span>
                </button>
                <button
                  onClick={() => setTheme("dark")}
                  className={`w-full flex items-center gap-3 p-3 rounded-lg transition-all ${
                    theme === "dark"
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted hover:bg-muted/80 text-card-foreground"
                  }`}
                >
                  <Moon className="w-5 h-5" />
                  <span>{t.darkTheme}</span>
                </button>
              </div>
            </div>

            {/* Language Section */}
            <div>
              <h3 className="flex items-center gap-2 text-sm font-semibold text-card-foreground mb-4">
                <Globe className="w-4 h-4" />
                {t.language}
              </h3>
              <div className="space-y-2">
                <button
                  onClick={() => setLanguage("pt-BR")}
                  className={`w-full flex items-center gap-3 p-3 rounded-lg transition-all ${
                    language === "pt-BR"
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted hover:bg-muted/80 text-card-foreground"
                  }`}
                >
                  <span className="text-lg">🇧🇷</span>
                  <span>{t.portuguese}</span>
                </button>
                <button
                  onClick={() => setLanguage("en-US" as Language)}
                  className={`w-full flex items-center gap-3 p-3 rounded-lg transition-all ${
                    language === "en-US"
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted hover:bg-muted/80 text-card-foreground"
                  }`}
                >
                  <span className="text-lg">🇺🇸</span>
                  <span>{t.english}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
