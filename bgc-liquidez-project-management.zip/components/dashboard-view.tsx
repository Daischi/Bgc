"use client";

import { useApp } from "@/lib/app-context";
import { ProgressCircle } from "./progress-circle";
import { FolderOpen, CheckCircle, TrendingUp, Layers } from "lucide-react";

export function DashboardView() {
  const {
    t,
    projects,
    getProjectProgress,
    getTotalTasksCount,
    setCurrentView,
    setSelectedProjectId,
    setSelectedPhaseId,
    getPhaseProgress,
  } = useApp();

  const completedProjects = projects.filter((p) => getProjectProgress(p.id) === 100);
  const inProgressProjects = projects.filter((p) => getProjectProgress(p.id) < 100);
  
  const averageProgress = projects.length > 0
    ? Math.round(projects.reduce((sum, p) => sum + getProjectProgress(p.id), 0) / projects.length)
    : 0;

  const handleProjectClick = (projectId: string) => {
    setSelectedProjectId(projectId);
    setSelectedPhaseId("about");
    setCurrentView("project");
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground">{t.dashboard}</h1>
        <p className="text-muted-foreground mt-1">{t.projectsOverview}</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-card rounded-xl p-5 border border-border flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
            <FolderOpen className="w-6 h-6 text-primary" />
          </div>
          <div>
            <p className="text-3xl font-bold text-card-foreground">{projects.length}</p>
            <p className="text-sm text-muted-foreground">{t.totalProjects}</p>
          </div>
        </div>

        <div className="bg-card rounded-xl p-5 border border-border flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-green-500/10 flex items-center justify-center">
            <CheckCircle className="w-6 h-6 text-green-500" />
          </div>
          <div>
            <p className="text-3xl font-bold text-card-foreground">{completedProjects.length}</p>
            <p className="text-sm text-muted-foreground">{t.completed}</p>
          </div>
        </div>

        <div className="bg-card rounded-xl p-5 border border-border flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-blue-500/10 flex items-center justify-center">
            <TrendingUp className="w-6 h-6 text-blue-500" />
          </div>
          <div>
            <p className="text-3xl font-bold text-card-foreground">{inProgressProjects.length}</p>
            <p className="text-sm text-muted-foreground">{t.inProgress}</p>
          </div>
        </div>

        <div className="bg-card rounded-xl p-5 border border-border flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-amber-500/10 flex items-center justify-center">
            <Layers className="w-6 h-6 text-amber-500" />
          </div>
          <div>
            <p className="text-3xl font-bold text-card-foreground">{averageProgress}%</p>
            <p className="text-sm text-muted-foreground">{t.averageProgress}</p>
          </div>
        </div>
      </div>

      {/* Projects List */}
      <div className="bg-card rounded-xl p-6 border border-border">
        <h2 className="text-lg font-semibold text-card-foreground mb-4">{t.projects}</h2>
        <div className="space-y-4">
          {projects.map((project) => {
            const progress = getProjectProgress(project.id);
            const { completed, total } = getTotalTasksCount(project.id);
            const isComplete = progress === 100;

            return (
              <button
                key={project.id}
                onClick={() => handleProjectClick(project.id)}
                className="w-full text-left border border-border rounded-xl p-5 hover:bg-muted/30 transition-all"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      isComplete ? "bg-green-500/10" : "bg-primary/10"
                    }`}>
                      {isComplete ? (
                        <CheckCircle className="w-5 h-5 text-green-500" />
                      ) : (
                        <FolderOpen className="w-5 h-5 text-primary" />
                      )}
                    </div>
                    <div>
                      <h3 className="font-semibold text-card-foreground">{project.name}</h3>
                      <p className="text-sm text-muted-foreground">
                        {completed}/{total} {t.tasksCompleted}
                      </p>
                    </div>
                  </div>
                  <ProgressCircle progress={progress} size="md" />
                </div>

                {/* Phase Progress Bars */}
                <div className="space-y-2">
                  {["phase1", "phase2", "phase3", "phase4"].map((phaseId, index) => {
                    const phaseProgress = getPhaseProgress(project.id, phaseId);
                    return (
                      <div key={phaseId} className="flex items-center gap-3">
                        <span className="text-xs text-muted-foreground w-16">
                          {t.phases[phaseId as keyof typeof t.phases]}
                        </span>
                        <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full bg-primary rounded-full transition-all duration-500"
                            style={{ width: `${phaseProgress}%` }}
                          />
                        </div>
                        <span className="text-xs text-muted-foreground w-10 text-right">
                          {phaseProgress}%
                        </span>
                      </div>
                    );
                  })}
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
