"use client";

import { useApp } from "@/lib/app-context";
import { Info } from "lucide-react";

const phaseIds = ["about", "phase1", "phase2", "phase3", "phase4"];

export function PhaseStepper() {
  const { t, selectedProjectId, selectedPhaseId, setSelectedPhaseId, getPhaseProgress } =
    useApp();

  const phaseLabels = [
    t.phases.about,
    t.phases.phase1,
    t.phases.phase2,
    t.phases.phase3,
    t.phases.phase4,
  ];

  return (
    <div className="w-full overflow-x-auto py-2">
      <div className="flex items-center gap-2 min-w-max">
        {phaseIds.map((phaseId, index) => {
          const isActive = phaseId === selectedPhaseId;
          const isAbout = phaseId === "about";

          return (
            <div key={phaseId} className="flex items-center">
              <button
                onClick={() => setSelectedPhaseId(phaseId)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-lg transition-all duration-200 ${
                  isActive
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : "bg-transparent hover:bg-muted text-muted-foreground hover:text-foreground"
                }`}
              >
                {isAbout ? (
                  <Info className="w-4 h-4" />
                ) : (
                  <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-semibold border-2 ${
                    isActive 
                      ? "border-primary-foreground bg-primary-foreground/20" 
                      : "border-current"
                  }`}>
                    {index}
                  </span>
                )}
                <span className="font-medium text-sm whitespace-nowrap">
                  {phaseLabels[index]}
                </span>
              </button>
              {index < phaseIds.length - 1 && (
                <div className="w-8 h-px bg-border mx-1" />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
