"use client";

import { useApp } from "@/lib/app-context";
import { ProgressCircle } from "./progress-circle";
import { Target, Layers, CheckCircle } from "lucide-react";

export function ProjectOverview() {
  const {
    t,
    projects,
    selectedProjectId,
    getProjectProgress,
    getPhaseProgress,
    getTotalTasksCount,
  } = useApp();

  const project = projects.find((p) => p.id === selectedProjectId);
  if (!project) return null;

  const progress = getProjectProgress(selectedProjectId);
  const { completed, total } = getTotalTasksCount(selectedProjectId);
  const phasesCount = project.phases.length;

  const phaseLabels = [
    t.phaseTitles.phase1,
    t.phaseTitles.phase2,
    t.phaseTitles.phase3,
    t.phaseTitles.phase4,
  ];

  const phaseIds = ["phase1", "phase2", "phase3", "phase4"];

  return (
    <div className="space-y-6">
      {/* Project Description */}
      <div className="bg-card rounded-xl p-6 border border-border">
        <h3 className="text-lg font-semibold text-card-foreground mb-3">
          {t.phases.about}
        </h3>
        <p className="text-muted-foreground leading-relaxed">
          {t.phaseDescriptions.about}
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-card rounded-xl p-5 border border-border flex items-center gap-4">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
            <Target className="w-5 h-5 text-primary" />
          </div>
          <div>
            <p className="text-2xl font-bold text-card-foreground">{progress}%</p>
            <p className="text-sm text-muted-foreground">{t.overallProgress}</p>
          </div>
        </div>

        <div className="bg-card rounded-xl p-5 border border-border flex items-center gap-4">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
            <Layers className="w-5 h-5 text-primary" />
          </div>
          <div>
            <p className="text-2xl font-bold text-card-foreground">{phasesCount}</p>
            <p className="text-sm text-muted-foreground">{t.phases_label}</p>
          </div>
        </div>

        <div className="bg-card rounded-xl p-5 border border-border flex items-center gap-4">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
            <CheckCircle className="w-5 h-5 text-primary" />
          </div>
          <div>
            <p className="text-2xl font-bold text-card-foreground">{completed}/{total}</p>
            <p className="text-sm text-muted-foreground">{t.tasksCompleted}</p>
          </div>
        </div>
      </div>

      {/* Phases Progress List */}
      <div className="bg-card rounded-xl p-6 border border-border">
        <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-4">
          {t.projectPhases}
        </h4>
        <div className="space-y-4">
          {phaseIds.map((phaseId, index) => {
            const phaseProgress = getPhaseProgress(selectedProjectId, phaseId);
            return (
              <div key={phaseId} className="border border-border rounded-lg p-4">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="w-6 h-6 rounded bg-primary/10 text-primary flex items-center justify-center text-xs font-semibold">
                        {index + 1}
                      </span>
                      <span className="font-semibold text-card-foreground">
                        {t.phases[phaseId as keyof typeof t.phases]}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground ml-8">
                      {phaseLabels[index]}
                    </p>
                  </div>
                  <span className="text-sm font-medium text-muted-foreground">
                    {phaseProgress}%
                  </span>
                </div>
                <div className="ml-8 h-1.5 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-primary rounded-full transition-all duration-500 ease-out"
                    style={{ width: `${phaseProgress}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
