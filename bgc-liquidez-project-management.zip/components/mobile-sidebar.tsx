"use client";

import { useApp } from "@/lib/app-context";
import { ProgressCircle } from "./progress-circle";
import { Settings, X, Menu, LayoutDashboard, CheckCircle2, FolderOpen } from "lucide-react";

interface MobileSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenSettings: () => void;
}

export function MobileSidebar({
  isOpen,
  onClose,
  onOpenSettings,
}: MobileSidebarProps) {
  const {
    t,
    projects,
    selectedProjectId,
    setSelectedProjectId,
    setSelectedPhaseId,
    getProjectProgress,
    currentView,
    setCurrentView,
    getCompletedProjects,
    getInProgressProjects,
  } = useApp();

  const handleProjectSelect = (projectId: string) => {
    setSelectedProjectId(projectId);
    setSelectedPhaseId("about");
    setCurrentView("project");
    onClose();
  };

  const handleOpenSettings = () => {
    onClose();
    onOpenSettings();
  };

  const handleViewChange = (view: "dashboard" | "completed") => {
    setCurrentView(view);
    onClose();
  };

  const inProgressProjects = getInProgressProjects();
  const completedProjects = getCompletedProjects();

  return (
    <>
      {/* Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed left-0 top-0 bottom-0 w-72 bg-gradient-to-b from-[#1a1a1a] to-[#2d2d2d] text-white flex flex-col z-50 transform transition-transform duration-300 lg:hidden ${
          isOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        {/* Logo Section */}
        <div className="p-6 border-b border-white/10 flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-white">
              BGC Liquidez
            </h1>
            <p className="text-sm text-gray-400 mt-1">
              {t.projectManagement}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4 overflow-auto">
          {/* Dashboard */}
          <button
            onClick={() => handleViewChange("dashboard")}
            className={`w-full flex items-center gap-3 p-3 rounded-lg transition-all duration-200 mb-4 ${
              currentView === "dashboard"
                ? "bg-primary text-primary-foreground"
                : "hover:bg-white/10 text-gray-300"
            }`}
          >
            <LayoutDashboard className="w-5 h-5" />
            <span className="font-medium">{t.dashboard}</span>
          </button>

          {/* In Progress Projects */}
          <h2 className="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-3 px-3">
            {t.inProgress}
          </h2>
          <ul className="space-y-1 mb-6">
            {inProgressProjects.map((project) => {
              const progress = getProjectProgress(project.id);
              const isSelected = project.id === selectedProjectId && currentView === "project";

              return (
                <li key={project.id}>
                  <button
                    onClick={() => handleProjectSelect(project.id)}
                    className={`w-full flex items-center justify-between p-3 rounded-lg transition-all duration-200 ${
                      isSelected
                        ? "bg-primary text-primary-foreground"
                        : "hover:bg-white/10 text-gray-300"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <FolderOpen className="w-4 h-4" />
                      <span className="font-medium">{project.name}</span>
                    </div>
                    <ProgressCircle
                      progress={progress}
                      size="sm"
                      showPercentage={true}
                      className={isSelected ? "text-primary-foreground" : ""}
                    />
                  </button>
                </li>
              );
            })}
          </ul>

          {/* Completed Projects */}
          <button
            onClick={() => handleViewChange("completed")}
            className={`w-full flex items-center justify-between p-3 rounded-lg transition-all duration-200 ${
              currentView === "completed"
                ? "bg-primary text-primary-foreground"
                : "hover:bg-white/10 text-gray-300"
            }`}
          >
            <div className="flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5" />
              <span className="font-medium">{t.completedProjects}</span>
            </div>
            {completedProjects.length > 0 && (
              <span className={`text-xs px-2 py-0.5 rounded-full ${
                currentView === "completed" ? "bg-white/20" : "bg-primary/20 text-primary"
              }`}>
                {completedProjects.length}
              </span>
            )}
          </button>
        </nav>

        {/* Settings Button */}
        <div className="p-4 border-t border-white/10">
          <button
            onClick={handleOpenSettings}
            className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-white/10 transition-colors text-gray-300"
          >
            <Settings className="w-5 h-5" />
            <span>{t.settings}</span>
          </button>
        </div>
      </aside>
    </>
  );
}

interface MobileHeaderProps {
  onOpenSidebar: () => void;
}

export function MobileHeader({ onOpenSidebar }: MobileHeaderProps) {
  const { t } = useApp();

  return (
    <header className="lg:hidden bg-gradient-to-r from-[#1a1a1a] to-[#2d2d2d] text-white p-4 flex items-center gap-4">
      <button
        onClick={onOpenSidebar}
        className="p-2 rounded-lg hover:bg-white/10 transition-colors"
      >
        <Menu className="w-6 h-6" />
      </button>
      <div>
        <h1 className="text-lg font-bold">BGC Liquidez</h1>
        <p className="text-xs text-gray-400">{t.projectManagement}</p>
      </div>
    </header>
  );
}
