"use client";

interface ProgressCircleProps {
  progress: number;
  size?: "sm" | "md" | "lg" | "xl";
  showPercentage?: boolean;
  className?: string;
  trackColor?: string;
  progressColor?: string;
}

export function ProgressCircle({
  progress,
  size = "md",
  showPercentage = true,
  className = "",
  trackColor,
  progressColor,
}: ProgressCircleProps) {
  const sizes = {
    sm: { width: 36, strokeWidth: 3, fontSize: "text-[10px]" },
    md: { width: 60, strokeWidth: 4, fontSize: "text-sm" },
    lg: { width: 100, strokeWidth: 6, fontSize: "text-xl" },
    xl: { width: 120, strokeWidth: 8, fontSize: "text-2xl" },
  };

  const { width, strokeWidth, fontSize } = sizes[size];
  const radius = (width - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (progress / 100) * circumference;

  return (
    <div className={`relative inline-flex items-center justify-center ${className}`}>
      <svg width={width} height={width} className="transform -rotate-90">
        <circle
          cx={width / 2}
          cy={width / 2}
          r={radius}
          fill="none"
          stroke={trackColor || "currentColor"}
          strokeWidth={strokeWidth}
          className={trackColor ? "" : "text-muted/20"}
        />
        <circle
          cx={width / 2}
          cy={width / 2}
          r={radius}
          fill="none"
          stroke={progressColor || "currentColor"}
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          className={progressColor ? "" : "text-primary transition-all duration-500 ease-out"}
        />
      </svg>
      {showPercentage && (
        <span
          className={`absolute ${fontSize} font-bold text-foreground`}
        >
          {progress}%
        </span>
      )}
    </div>
  );
}
