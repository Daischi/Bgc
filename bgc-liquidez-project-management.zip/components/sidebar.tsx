"use client";

import { useApp } from "@/lib/app-context";
import { ProgressCircle } from "./progress-circle";
import { Settings, LayoutDashboard, CheckCircle2, FolderOpen } from "lucide-react";

interface SidebarProps {
  onOpenSettings: () => void;
}

export function Sidebar({ onOpenSettings }: SidebarProps) {
  const {
    t,
    projects,
    selectedProjectId,
    setSelectedProjectId,
    setSelectedPhaseId,
    getProjectProgress,
    currentView,
    setCurrentView,
    getCompletedProjects,
    getInProgressProjects,
  } = useApp();

  const handleProjectSelect = (projectId: string) => {
    setSelectedProjectId(projectId);
    setSelectedPhaseId("about");
    setCurrentView("project");
  };

  const inProgressProjects = getInProgressProjects();
  const completedProjects = getCompletedProjects();

  return (
    <aside className="w-72 bg-gradient-to-br from-[#1f1f1f] via-[#262626] to-[#333333] text-sidebar-foreground flex flex-col h-screen fixed left-0 top-0 shadow-2xl">
      {/* Logo Section */}
      <div className="p-6 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center shadow-lg">
            <span className="text-white font-bold text-lg">B</span>
          </div>
          <div>
            <h1 className="text-lg font-bold text-white tracking-tight">
              BGC Liquidez
            </h1>
            <p className="text-xs text-gray-400">{t.projectManagement}</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 overflow-y-auto scrollbar-thin">
        {/* Dashboard */}
        <button
          onClick={() => setCurrentView("dashboard")}
          className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all duration-200 mb-2 ${
            currentView === "dashboard"
              ? "bg-primary text-white shadow-lg shadow-primary/30"
              : "hover:bg-white/5 text-gray-300"
          }`}
        >
          <LayoutDashboard className="w-5 h-5" />
          <span className="font-medium">{t.dashboard}</span>
        </button>

        {/* Divider */}
        <div className="h-px bg-white/10 my-4" />

        {/* In Progress Projects */}
        <h2 className="text-[11px] font-semibold uppercase tracking-widest text-gray-500 mb-3 px-3 flex items-center gap-2">
          <FolderOpen className="w-3.5 h-3.5" />
          {t.inProgress}
        </h2>
        <ul className="space-y-1 mb-4">
          {inProgressProjects.map((project) => {
            const progress = getProjectProgress(project.id);
            const isSelected = project.id === selectedProjectId && currentView === "project";

            return (
              <li key={project.id}>
                <button
                  onClick={() => handleProjectSelect(project.id)}
                  className={`w-full flex items-center justify-between p-3 rounded-xl transition-all duration-200 group ${
                    isSelected
                      ? "bg-primary text-white shadow-lg shadow-primary/30"
                      : "hover:bg-white/5 text-gray-300"
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className={`w-2 h-2 rounded-full ${isSelected ? "bg-white" : "bg-primary"}`} />
                    <span className="font-medium truncate">{project.name}</span>
                  </div>
                  <ProgressCircle
                    progress={progress}
                    size="sm"
                    showPercentage={true}
                    className={isSelected ? "text-white" : ""}
                  />
                </button>
              </li>
            );
          })}
        </ul>

        {/* Divider */}
        <div className="h-px bg-white/10 my-4" />

        {/* Completed Projects */}
        <button
          onClick={() => setCurrentView("completed")}
          className={`w-full flex items-center justify-between p-3 rounded-xl transition-all duration-200 ${
            currentView === "completed"
              ? "bg-primary text-white shadow-lg shadow-primary/30"
              : "hover:bg-white/5 text-gray-300"
          }`}
        >
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5" />
            <span className="font-medium">{t.completedProjects}</span>
          </div>
          {completedProjects.length > 0 && (
            <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${
              currentView === "completed" ? "bg-white/20 text-white" : "bg-green-500/20 text-green-400"
            }`}>
              {completedProjects.length}
            </span>
          )}
        </button>
      </nav>

      {/* Settings Button */}
      <div className="p-4 border-t border-white/10">
        <button
          onClick={onOpenSettings}
          className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-white/5 transition-all duration-200 text-gray-400 hover:text-gray-200"
        >
          <Settings className="w-5 h-5" />
          <span className="font-medium">{t.settings}</span>
        </button>
      </div>
    </aside>
  );
}
