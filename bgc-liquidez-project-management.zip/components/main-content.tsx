"use client";

import { useApp } from "@/lib/app-context";
import { ProgressCircle } from "./progress-circle";
import { PhaseStepper } from "./phase-stepper";
import { PhaseContent } from "./phase-content";
import { ProjectOverview } from "./project-overview";
import { DashboardView } from "./dashboard-view";
import { CompletedView } from "./completed-view";
import { Settings } from "lucide-react";

interface MainContentProps {
  onOpenSettings: () => void;
}

export function MainContent({ onOpenSettings }: MainContentProps) {
  const { t, projects, selectedProjectId, selectedPhaseId, getProjectProgress, currentView } = useApp();

  const project = projects.find((p) => p.id === selectedProjectId);
  const progress = getProjectProgress(selectedProjectId);

  // Dashboard View
  if (currentView === "dashboard") {
    return (
      <main className="flex-1 bg-background min-h-screen overflow-auto">
        <div className="max-w-5xl mx-auto p-8">
          <div className="flex justify-end mb-6">
            <button
              onClick={onOpenSettings}
              className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
            >
              <Settings className="w-5 h-5" />
            </button>
          </div>
          <DashboardView />
        </div>
      </main>
    );
  }

  // Completed Projects View
  if (currentView === "completed") {
    return (
      <main className="flex-1 bg-background min-h-screen overflow-auto">
        <div className="max-w-5xl mx-auto p-8">
          <div className="flex justify-end mb-6">
            <button
              onClick={onOpenSettings}
              className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
            >
              <Settings className="w-5 h-5" />
            </button>
          </div>
          <CompletedView />
        </div>
      </main>
    );
  }

  // Project View
  if (!project) return null;

  return (
    <main className="flex-1 bg-background min-h-screen overflow-auto">
      <div className="max-w-5xl mx-auto p-8">
        {/* Settings Button */}
        <div className="flex justify-end mb-2">
          <button
            onClick={onOpenSettings}
            className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>

        {/* Project Header */}
        <header className="flex items-start justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground">
              {project.name}
            </h1>
            <p className="text-muted-foreground mt-1">{t.followProgress}</p>
          </div>
          <div className="flex flex-col items-center gap-1">
            <ProgressCircle progress={progress} size="xl" />
            <span className="text-xs text-muted-foreground mt-2">
              {t.overallProgress}
            </span>
          </div>
        </header>

        {/* Phase Stepper */}
        <div className="mb-8">
          <PhaseStepper />
        </div>

        {/* Phase Content */}
        {selectedPhaseId === "about" ? (
          <ProjectOverview />
        ) : (
          <PhaseContent />
        )}
      </div>
    </main>
  );
}
