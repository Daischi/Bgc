"use client";

import { cn } from "@/lib/utils";
import { Phase } from "@/lib/data";
import { Info } from "lucide-react";
import { useLanguage } from "@/lib/i18n";

interface PhaseStepperProps {
  phases: Phase[];
  activePhaseIndex: number;
  onSelectPhase: (index: number) => void;
  showAboutProject: boolean;
  onToggleAboutProject: () => void;
}

export function PhaseStepper({
  phases,
  activePhaseIndex,
  onSelectPhase,
  showAboutProject,
  onToggleAboutProject,
}: PhaseStepperProps) {
  const { t } = useLanguage();

  return (
    <div className="w-full">
      {/* Desktop stepper */}
      <div className="hidden md:flex items-center justify-between">
        {/* About Project Tab */}
        <div className="flex items-center">
          <button
            onClick={onToggleAboutProject}
            className={cn(
              "flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200",
              showAboutProject
                ? "bg-primary text-primary-foreground shadow-md"
                : "bg-card hover:bg-muted text-muted-foreground hover:text-foreground"
            )}
          >
            <span
              className={cn(
                "flex items-center justify-center w-8 h-8 rounded-full transition-colors",
                showAboutProject
                  ? "bg-primary-foreground/10 text-primary-foreground"
                  : "bg-background text-foreground"
              )}
            >
              <Info className="w-4 h-4" />
            </span>
            <span className="font-medium text-sm whitespace-nowrap">{t.aboutProject}</span>
          </button>
          <div
            className={cn(
              "flex-1 h-0.5 mx-2 w-8 transition-colors",
              showAboutProject ? "bg-primary" : "bg-border"
            )}
          />
        </div>

        {/* Phase tabs */}
        {phases.map((phase, index) => (
          <div key={phase.id} className="flex items-center flex-1">
            <button
              onClick={() => {
                onSelectPhase(index);
              }}
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200",
                !showAboutProject && activePhaseIndex === index
                  ? "bg-primary text-primary-foreground shadow-md"
                  : "bg-card hover:bg-muted text-muted-foreground hover:text-foreground"
              )}
            >
              <span
                className={cn(
                  "flex items-center justify-center w-8 h-8 rounded-full text-sm font-semibold border-2 transition-colors",
                  !showAboutProject && activePhaseIndex === index
                    ? "border-primary-foreground/30 bg-primary-foreground/10 text-primary-foreground"
                    : "border-border bg-background text-foreground"
                )}
              >
                {index + 1}
              </span>
              <span className="font-medium text-sm whitespace-nowrap">{phase.name}</span>
            </button>
            {index < phases.length - 1 && (
              <div
                className={cn(
                  "flex-1 h-0.5 mx-2 transition-colors",
                  !showAboutProject && index < activePhaseIndex ? "bg-primary" : "bg-border"
                )}
              />
            )}
          </div>
        ))}
      </div>

      {/* Mobile tabs */}
      <div className="md:hidden flex overflow-x-auto gap-2 pb-2 -mx-2 px-2">
        {/* About Project Tab - Mobile */}
        <button
          onClick={onToggleAboutProject}
          className={cn(
            "flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium whitespace-nowrap transition-colors",
            showAboutProject
              ? "bg-primary text-primary-foreground"
              : "bg-card text-muted-foreground hover:bg-muted"
          )}
        >
          <span
            className={cn(
              "flex items-center justify-center w-6 h-6 rounded-full",
              showAboutProject
                ? "bg-primary-foreground/20 text-primary-foreground"
                : "bg-muted text-muted-foreground"
            )}
          >
            <Info className="w-3 h-3" />
          </span>
          {t.aboutProject}
        </button>

        {/* Phase tabs - Mobile */}
        {phases.map((phase, index) => (
          <button
            key={phase.id}
            onClick={() => {
              onSelectPhase(index);
            }}
            className={cn(
              "flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium whitespace-nowrap transition-colors",
              !showAboutProject && activePhaseIndex === index
                ? "bg-primary text-primary-foreground"
                : "bg-card text-muted-foreground hover:bg-muted"
            )}
          >
            <span
              className={cn(
                "flex items-center justify-center w-6 h-6 rounded-full text-xs font-semibold",
                !showAboutProject && activePhaseIndex === index
                  ? "bg-primary-foreground/20 text-primary-foreground"
                  : "bg-muted text-muted-foreground"
              )}
            >
              {index + 1}
            </span>
            {phase.name}
          </button>
        ))}
      </div>
    </div>
  );
}
