"use client";

import { Moon, Sun, Globe, Settings } from "lucide-react";
import { useTheme } from "next-themes";
import { useLanguage } from "@/lib/i18n";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export function SettingsDropdown() {
  const { theme, setTheme } = useTheme();
  const { language, setLanguage, t } = useLanguage();
  const currentTheme = theme || "light";

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="icon" className="h-9 w-9 bg-transparent">
          <Settings className="h-4 w-4" />
          <span className="sr-only">Settings</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48">
        <DropdownMenuLabel className="flex items-center gap-2">
          <Sun className="h-4 w-4" />
          {t.theme}
        </DropdownMenuLabel>
        <DropdownMenuItem
          onClick={() => setTheme("light")}
          className={cn(currentTheme === "light" && "bg-accent")}
        >
          <Sun className="h-4 w-4 mr-2" />
          {t.light}
        </DropdownMenuItem>
        <DropdownMenuItem
          onClick={() => setTheme("dark")}
          className={cn(currentTheme === "dark" && "bg-accent")}
        >
          <Moon className="h-4 w-4 mr-2" />
          {t.dark}
        </DropdownMenuItem>

        <DropdownMenuSeparator />

        <DropdownMenuLabel className="flex items-center gap-2">
          <Globe className="h-4 w-4" />
          {t.language}
        </DropdownMenuLabel>
        <DropdownMenuItem
          onClick={() => setLanguage("pt-BR")}
          className={cn(language === "pt-BR" && "bg-accent")}
        >
          Portugues (BR)
        </DropdownMenuItem>
        <DropdownMenuItem
          onClick={() => setLanguage("en")}
          className={cn(language === "en" && "bg-accent")}
        >
          English
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
