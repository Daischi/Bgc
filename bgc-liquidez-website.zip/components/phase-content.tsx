"use client";

import { cn } from "@/lib/utils";
import { Phase, TaskItem } from "@/lib/data";
import { Check, Info, ChevronDown, ChevronRight } from "lucide-react";
import { useLanguage } from "@/lib/i18n";
import { useState } from "react";

interface PhaseContentProps {
  phase: Phase;
  onToggleTask: (itemId: string) => void;
}

export function PhaseContent({ phase, onToggleTask }: PhaseContentProps) {
  const { t } = useLanguage();
  const completedTasks = phase.items.filter(
    (item) => item.type === "task" && item.completed
  ).length;
  const totalTasks = phase.items.filter((item) => item.type === "task").length;

  return (
    <div className="bg-card rounded-xl border border-border shadow-sm">
      {/* Header */}
      <div className="px-6 py-5 border-b border-border">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h3 className="text-lg font-semibold text-foreground">{phase.description}</h3>
            <p className="text-sm text-muted-foreground mt-1">
              {totalTasks > 0 && (
                <span>
                  {completedTasks} de {totalTasks} {t.tasksCompleted}
                </span>
              )}
            </p>
          </div>
          {totalTasks > 0 && (
            <div className="flex items-center gap-2">
              <div className="w-32 h-2 bg-muted rounded-full overflow-hidden">
                <div
                  className="h-full bg-primary rounded-full transition-all duration-300"
                  style={{ width: `${(completedTasks / totalTasks) * 100}%` }}
                />
              </div>
              <span className="text-sm font-medium text-muted-foreground">
                {Math.round((completedTasks / totalTasks) * 100)}%
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Phase Summary */}
      <div className="px-6 py-4 border-b border-border bg-muted/30">
        <h4 className="text-sm font-semibold text-foreground uppercase tracking-wide mb-2">
          {t.phaseSummary}
        </h4>
        <p className="text-sm text-muted-foreground leading-relaxed">
          {phase.summary}
        </p>
      </div>

      {/* Items */}
      <div className="p-6">
        <h4 className="text-sm font-semibold text-foreground uppercase tracking-wide mb-4">
          {t.activities}
        </h4>
        <ul className="space-y-3">
          {phase.items.map((item) => (
            <TaskItemComponent
              key={item.id}
              item={item}
              onToggle={() => onToggleTask(item.id)}
            />
          ))}
        </ul>
      </div>
    </div>
  );
}

interface TaskItemComponentProps {
  item: TaskItem;
  onToggle: () => void;
}

function TaskItemComponent({ item, onToggle }: TaskItemComponentProps) {
  const [expanded, setExpanded] = useState(false);
  const { t } = useLanguage();

  if (item.type === "info") {
    return (
      <li className="flex flex-col gap-2 p-3 rounded-lg bg-muted/50">
        <div 
          className="flex items-start gap-3 cursor-pointer"
          onClick={() => item.description && setExpanded(!expanded)}
        >
          <div className="flex items-center justify-center w-6 h-6 rounded-full bg-primary/10 text-primary flex-shrink-0 mt-0.5">
            <Info className="w-3.5 h-3.5" />
          </div>
          <div className="flex-1">
            <span className="text-sm text-foreground leading-relaxed">{item.text}</span>
          </div>
          {item.description && (
            <div className="flex-shrink-0 text-muted-foreground">
              {expanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </div>
          )}
        </div>
        {expanded && item.description && (
          <div className="ml-9 text-xs text-muted-foreground leading-relaxed bg-background/50 p-2 rounded-md">
            {item.description}
          </div>
        )}
      </li>
    );
  }

  return (
    <li
      className={cn(
        "flex flex-col gap-2 p-3 rounded-lg transition-colors",
        item.completed
          ? "bg-primary/5 hover:bg-primary/10"
          : "bg-background hover:bg-muted/50 border border-border"
      )}
    >
      <div className="flex items-start gap-3">
        <button
          onClick={onToggle}
          className={cn(
            "flex items-center justify-center w-6 h-6 rounded-md border-2 flex-shrink-0 mt-0.5 transition-colors",
            item.completed
              ? "bg-primary border-primary text-primary-foreground"
              : "border-border bg-background hover:border-primary/50"
          )}
          aria-label={item.completed ? t.markIncomplete : t.markComplete}
        >
          {item.completed && <Check className="w-3.5 h-3.5" />}
        </button>
        <div 
          className="flex-1 cursor-pointer"
          onClick={() => item.description && setExpanded(!expanded)}
        >
          <span
            className={cn(
              "text-sm leading-relaxed transition-colors",
              item.completed ? "text-muted-foreground line-through" : "text-foreground"
            )}
          >
            {item.text}
          </span>
        </div>
        {item.description && (
          <div 
            className="flex-shrink-0 text-muted-foreground cursor-pointer"
            onClick={() => setExpanded(!expanded)}
          >
            {expanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </div>
        )}
      </div>
      {expanded && item.description && (
        <div className="ml-9 text-xs text-muted-foreground leading-relaxed bg-muted/30 p-2 rounded-md">
          {item.description}
        </div>
      )}
    </li>
  );
}
