"use client";

import { cn } from "@/lib/utils";
import { Project } from "@/lib/data";
import { FolderKanban, X, Menu, CheckCircle2 } from "lucide-react";
import { MiniCircularProgress } from "./mini-circular-progress";
import { useLanguage } from "@/lib/i18n";

interface ProjectSidebarProps {
  projects: Project[];
  selectedProjectId: string;
  onSelectProject: (projectId: string) => void;
  isOpen: boolean;
  onToggle: () => void;
  getProjectProgress: (projectId: string) => number;
}

export function ProjectSidebar({
  projects,
  selectedProjectId,
  onSelectProject,
  isOpen,
  onToggle,
  getProjectProgress,
}: ProjectSidebarProps) {
  const { t } = useLanguage();
  
  const activeProjects = projects.filter((p) => getProjectProgress(p.id) < 100);
  const completedProjects = projects.filter((p) => getProjectProgress(p.id) >= 100);

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={onToggle}
        />
      )}

      {/* Mobile toggle button */}
      <button
        onClick={onToggle}
        className="fixed top-4 left-4 z-50 lg:hidden p-2 rounded-md bg-sidebar text-sidebar-foreground"
        aria-label="Toggle menu"
      >
        {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
      </button>

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed left-0 top-0 z-40 h-screen w-64 bg-sidebar text-sidebar-foreground border-r border-sidebar-border transition-transform duration-300 ease-in-out flex flex-col",
          "lg:translate-x-0",
          isOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        {/* Logo */}
        <div className="flex items-center gap-3 px-6 py-6 border-b border-sidebar-border">
          <div className="flex items-center justify-center w-9 h-9 rounded-md bg-sidebar-primary">
            <span className="text-sidebar-primary-foreground font-bold text-sm">BGC</span>
          </div>
          <div>
            <h1 className="text-base font-semibold text-sidebar-foreground">BGC Liquidez</h1>
            <p className="text-xs text-sidebar-foreground/60">Gestão de Projetos</p>
          </div>
        </div>

        {/* Navigation */}
        <nav className="p-4 flex-1 overflow-y-auto">
          {/* Active Projects */}
          {activeProjects.length > 0 && (
            <div className="mb-6">
              <p className="text-xs font-medium text-sidebar-foreground/50 uppercase tracking-wider mb-3 px-2">
                {t.projects}
              </p>
              <ul className="space-y-1">
                {activeProjects.map((project) => {
                  const progress = getProjectProgress(project.id);
                  const isSelected = selectedProjectId === project.id;
                  return (
                    <li key={project.id}>
                      <button
                        onClick={() => {
                          onSelectProject(project.id);
                          if (window.innerWidth < 1024) {
                            onToggle();
                          }
                        }}
                        className={cn(
                          "w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors",
                          isSelected
                            ? "bg-sidebar-primary text-sidebar-primary-foreground"
                            : "text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                        )}
                      >
                        <FolderKanban className="h-4 w-4 flex-shrink-0" />
                        <span className="flex-1 text-left">{project.name}</span>
                        <MiniCircularProgress 
                          percentage={progress} 
                          isSelected={isSelected}
                        />
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>
          )}

          {/* Completed Projects */}
          {completedProjects.length > 0 && (
            <div>
              <p className="text-xs font-medium text-sidebar-foreground/50 uppercase tracking-wider mb-3 px-2 flex items-center gap-2">
                <CheckCircle2 className="h-3 w-3" />
                {t.completedProjects}
              </p>
              <ul className="space-y-1">
                {completedProjects.map((project) => {
                  const progress = getProjectProgress(project.id);
                  const isSelected = selectedProjectId === project.id;
                  return (
                    <li key={project.id}>
                      <button
                        onClick={() => {
                          onSelectProject(project.id);
                          if (window.innerWidth < 1024) {
                            onToggle();
                          }
                        }}
                        className={cn(
                          "w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors",
                          isSelected
                            ? "bg-sidebar-primary text-sidebar-primary-foreground"
                            : "text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                        )}
                      >
                        <CheckCircle2 className="h-4 w-4 flex-shrink-0 text-green-500" />
                        <span className="flex-1 text-left">{project.name}</span>
                        <MiniCircularProgress 
                          percentage={progress} 
                          isSelected={isSelected}
                        />
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>
          )}
        </nav>
      </aside>
    </>
  );
}
