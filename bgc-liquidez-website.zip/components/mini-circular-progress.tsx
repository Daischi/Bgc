"use client";

import { cn } from "@/lib/utils";

interface MiniCircularProgressProps {
  percentage: number;
  size?: number;
  strokeWidth?: number;
  className?: string;
  isSelected?: boolean;
}

export function MiniCircularProgress({
  percentage,
  size = 28,
  strokeWidth = 3,
  className,
  isSelected = false,
}: MiniCircularProgressProps) {
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const offset = circumference - (percentage / 100) * circumference;

  return (
    <div className={cn("relative inline-flex items-center justify-center flex-shrink-0", className)}>
      <svg width={size} height={size} className="-rotate-90">
        {/* Background circle */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="currentColor"
          strokeWidth={strokeWidth}
          className={cn(
            isSelected ? "text-sidebar-primary-foreground/20" : "text-sidebar-foreground/20"
          )}
        />
        {/* Progress circle */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="currentColor"
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          className={cn(
            "transition-all duration-300",
            isSelected ? "text-sidebar-primary-foreground" : "text-sidebar-primary"
          )}
        />
      </svg>
      {/* Percentage text */}
      <div className="absolute inset-0 flex items-center justify-center">
        <span className={cn(
          "text-[8px] font-semibold",
          isSelected ? "text-sidebar-primary-foreground" : "text-sidebar-foreground/80"
        )}>
          {Math.round(percentage)}%
        </span>
      </div>
    </div>
  );
}
