"use client";

import { Project } from "@/lib/data";
import { useLanguage } from "@/lib/i18n";
import { Target, Layers, CheckCircle2 } from "lucide-react";

interface ProjectSummaryProps {
  project: Project;
  overallProgress: number;
}

export function ProjectSummary({ project, overallProgress }: ProjectSummaryProps) {
  const { t } = useLanguage();

  // Calculate stats
  const totalPhases = project.phases.length;
  const totalTasks = project.phases.reduce(
    (acc, phase) => acc + phase.items.filter((item) => item.type === "task").length,
    0
  );
  const completedTasks = project.phases.reduce(
    (acc, phase) => acc + phase.items.filter((item) => item.type === "task" && item.completed).length,
    0
  );

  return (
    <div className="bg-card rounded-xl border border-border shadow-sm">
      {/* Header */}
      <div className="px-6 py-5 border-b border-border">
        <h3 className="text-lg font-semibold text-foreground">{t.projectSummary}</h3>
      </div>

      {/* Content */}
      <div className="p-6 space-y-6">
        {/* Summary Text */}
        <div>
          <p className="text-sm text-muted-foreground leading-relaxed">
            {project.summary}
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="flex items-center gap-3 p-4 rounded-lg bg-muted/50">
            <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary/10 text-primary">
              <Target className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{Math.round(overallProgress)}%</p>
              <p className="text-xs text-muted-foreground">{t.overallProgress}</p>
            </div>
          </div>

          <div className="flex items-center gap-3 p-4 rounded-lg bg-muted/50">
            <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary/10 text-primary">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{totalPhases}</p>
              <p className="text-xs text-muted-foreground">Fases</p>
            </div>
          </div>

          <div className="flex items-center gap-3 p-4 rounded-lg bg-muted/50">
            <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary/10 text-primary">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{completedTasks}/{totalTasks}</p>
              <p className="text-xs text-muted-foreground">{t.tasksCompleted}</p>
            </div>
          </div>
        </div>

        {/* Phases Overview */}
        <div>
          <h4 className="text-sm font-semibold text-foreground uppercase tracking-wide mb-4">
            Fases do Projeto
          </h4>
          <div className="space-y-3">
            {project.phases.map((phase, index) => {
              const phaseTasks = phase.items.filter((item) => item.type === "task");
              const phaseCompleted = phaseTasks.filter((item) => item.completed).length;
              const phaseProgress = phaseTasks.length > 0 ? (phaseCompleted / phaseTasks.length) * 100 : 0;

              return (
                <div key={phase.id} className="p-4 rounded-lg border border-border bg-background">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="flex items-center justify-center w-6 h-6 rounded-full bg-primary/10 text-primary text-xs font-semibold">
                        {index + 1}
                      </span>
                      <span className="font-medium text-sm text-foreground">{phase.name}</span>
                    </div>
                    <span className="text-xs font-medium text-muted-foreground">
                      {Math.round(phaseProgress)}%
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground mb-2">{phase.description}</p>
                  <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-primary rounded-full transition-all duration-300"
                      style={{ width: `${phaseProgress}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
