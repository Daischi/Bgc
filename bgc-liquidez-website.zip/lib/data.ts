export interface TaskItem {
  id: string;
  text: string;
  description?: string;
  type: "info" | "task";
  completed?: boolean;
}

export interface Phase {
  id: string;
  name: string;
  description: string;
  summary: string;
  items: TaskItem[];
}

export interface Project {
  id: string;
  name: string;
  summary: string;
  phases: Phase[];
}

export const projectsData: Project[] = [
  {
    id: "projeto-1",
    name: "Projeto 1",
    summary: "Sistema de gestao integrada para otimizar processos internos da BGC Liquidez, incluindo automacao de fluxos de trabalho, integracao com sistemas legados e dashboard de acompanhamento em tempo real.",
    phases: [
      {
        id: "fase-1",
        name: "Fase 1",
        description: "Planejamento e Analise Inicial",
        summary: "Nesta fase inicial, focamos em entender completamente o escopo do projeto, levantando todos os requisitos funcionais e nao-funcionais junto aos stakeholders. O objetivo e criar uma base solida de documentacao que guiara todo o desenvolvimento subsequente.",
        items: [
          { id: "1-1-1", text: "Definicao do escopo do projeto", description: "Documento que define os limites, objetivos e entregaveis do projeto.", type: "info" },
          { id: "1-1-2", text: "Analise de requisitos funcionais", description: "Levantamento detalhado das funcionalidades que o sistema deve possuir.", type: "info" },
          { id: "1-1-3", text: "Aprovacao do documento de visao", description: "Revisar e aprovar o documento que descreve a visao geral e os objetivos estrategicos do projeto.", type: "task", completed: true },
          { id: "1-1-4", text: "Reuniao de kickoff com stakeholders", description: "Agendar e conduzir reuniao inicial para alinhar expectativas com todas as partes interessadas.", type: "task", completed: true },
          { id: "1-1-5", text: "Definir cronograma preliminar", description: "Criar timeline inicial com marcos e datas estimadas para cada fase do projeto.", type: "task", completed: false },
        ],
      },
      {
        id: "fase-2",
        name: "Fase 2",
        description: "Desenvolvimento e Implementacao",
        summary: "A fase de desenvolvimento transforma os requisitos em codigo funcional. A equipe tecnica implementa os modulos principais do sistema, seguindo as melhores praticas de arquitetura de software e garantindo qualidade atraves de testes unitarios.",
        items: [
          { id: "1-2-1", text: "Arquitetura do sistema definida", description: "Diagrama tecnico com a estrutura de componentes, banco de dados e integracoes.", type: "info" },
          { id: "1-2-2", text: "Ambiente de desenvolvimento configurado", description: "Setup completo do ambiente local e de staging para desenvolvimento.", type: "info" },
          { id: "1-2-3", text: "Implementar modulo de autenticacao", description: "Desenvolver sistema de login, registro e gerenciamento de sessoes de usuarios.", type: "task", completed: true },
          { id: "1-2-4", text: "Desenvolver API de integracao", description: "Criar endpoints RESTful para comunicacao com sistemas externos e frontend.", type: "task", completed: false },
          { id: "1-2-5", text: "Criar testes unitarios", description: "Escrever testes automatizados para validar funcionalidades individuais do codigo.", type: "task", completed: false },
        ],
      },
      {
        id: "fase-3",
        name: "Fase 3",
        description: "Testes e Validacao",
        summary: "Fase critica onde validamos toda a implementacao atraves de testes rigorosos. Inclui testes de integracao, testes com usuarios piloto e correcao de bugs identificados para garantir que o sistema esta pronto para producao.",
        items: [
          { id: "1-3-1", text: "Plano de testes aprovado pela QA", description: "Documento com estrategias, casos de teste e criterios de aceitacao.", type: "info" },
          { id: "1-3-2", text: "Ambiente de homologacao disponivel", description: "Ambiente identico ao de producao para testes finais.", type: "info" },
          { id: "1-3-3", text: "Executar testes de integracao", description: "Validar a comunicacao entre diferentes modulos e servicos do sistema.", type: "task", completed: false },
          { id: "1-3-4", text: "Validar com usuarios piloto", description: "Conduzir sessoes de teste com usuarios reais para coletar feedback.", type: "task", completed: false },
          { id: "1-3-5", text: "Corrigir bugs identificados", description: "Resolver todos os problemas encontrados durante a fase de testes.", type: "task", completed: false },
        ],
      },
      {
        id: "fase-4",
        name: "Fase 4",
        description: "Deploy e Go-Live",
        summary: "O momento final do projeto onde o sistema e disponibilizado em producao. Inclui a execucao do deploy, monitoramento intensivo das metricas de performance e entrega da documentacao completa do projeto.",
        items: [
          { id: "1-4-1", text: "Checklist de producao completo", description: "Lista de verificacao com todos os requisitos para lancamento.", type: "info" },
          { id: "1-4-2", text: "Backup e plano de rollback definidos", description: "Procedimentos de seguranca caso seja necessario reverter a atualizacao.", type: "info" },
          { id: "1-4-3", text: "Realizar deploy em producao", description: "Executar a implantacao do sistema no ambiente de producao final.", type: "task", completed: false },
          { id: "1-4-4", text: "Monitorar metricas pos-deploy", description: "Acompanhar performance, erros e comportamento do sistema apos lancamento.", type: "task", completed: false },
          { id: "1-4-5", text: "Documentacao final entregue", description: "Entregar manuais de usuario, documentacao tecnica e guias de operacao.", type: "task", completed: false },
        ],
      },
    ],
  },
  {
    id: "projeto-2",
    name: "Projeto 2",
    summary: "Desenvolvimento de nova plataforma digital para relacionamento com clientes, com foco em experiencia do usuario e integracao omnichannel para melhorar o atendimento e aumentar a satisfacao dos clientes.",
    phases: [
      {
        id: "fase-1",
        name: "Fase 1",
        description: "Discovery e Pesquisa",
        summary: "Iniciamos com uma imersao profunda no universo do usuario. Realizamos pesquisas de mercado, analise competitiva e entrevistas para entender as reais necessidades e dores dos clientes que o produto deve resolver.",
        items: [
          { id: "2-1-1", text: "Pesquisa de mercado realizada", description: "Estudo do mercado-alvo, tendencias e oportunidades.", type: "info" },
          { id: "2-1-2", text: "Analise de concorrentes documentada", description: "Mapeamento das solucoes existentes e diferenciais competitivos.", type: "info" },
          { id: "2-1-3", text: "Entrevistar usuarios-chave", description: "Conduzir entrevistas com usuarios para entender suas necessidades e dores.", type: "task", completed: true },
          { id: "2-1-4", text: "Mapear jornada do cliente", description: "Documentar todos os pontos de contato do usuario com o produto ou servico.", type: "task", completed: true },
          { id: "2-1-5", text: "Validar hipoteses de negocio", description: "Testar suposicoes iniciais atraves de dados e feedback do mercado.", type: "task", completed: true },
        ],
      },
      {
        id: "fase-2",
        name: "Fase 2",
        description: "Design e Prototipagem",
        summary: "Transformamos os insights da pesquisa em solucoes visuais. Criamos wireframes, prototipos interativos e um design system completo, validando cada iteracao com testes de usabilidade com usuarios reais.",
        items: [
          { id: "2-2-1", text: "Wireframes de baixa fidelidade aprovados", description: "Esbocos iniciais das telas e fluxos de navegacao.", type: "info" },
          { id: "2-2-2", text: "Design system documentado", description: "Biblioteca de componentes visuais e diretrizes de design.", type: "info" },
          { id: "2-2-3", text: "Criar prototipo navegavel", description: "Desenvolver prototipo interativo para demonstracao e testes.", type: "task", completed: true },
          { id: "2-2-4", text: "Realizar testes de usabilidade", description: "Observar usuarios interagindo com o prototipo para identificar melhorias.", type: "task", completed: false },
          { id: "2-2-5", text: "Iterar baseado em feedback", description: "Ajustar o design com base nos insights coletados nos testes.", type: "task", completed: false },
        ],
      },
      {
        id: "fase-3",
        name: "Fase 3",
        description: "Construcao do MVP",
        summary: "Momento de colocar a mao na massa e construir o Produto Minimo Viavel. A equipe de desenvolvimento trabalha em sprints para entregar as funcionalidades essenciais e integrar com os sistemas existentes.",
        items: [
          { id: "2-3-1", text: "Stack tecnologica definida", description: "Escolha das tecnologias frontend, backend e infraestrutura.", type: "info" },
          { id: "2-3-2", text: "Sprints planejadas para 8 semanas", description: "Divisao do trabalho em ciclos de desenvolvimento agil.", type: "info" },
          { id: "2-3-3", text: "Desenvolver funcionalidades core", description: "Implementar as funcionalidades essenciais do produto minimo viavel.", type: "task", completed: false },
          { id: "2-3-4", text: "Integrar com sistemas legados", description: "Conectar o novo sistema com plataformas existentes da empresa.", type: "task", completed: false },
          { id: "2-3-5", text: "Preparar ambiente de staging", description: "Configurar ambiente de pre-producao para testes internos.", type: "task", completed: false },
        ],
      },
      {
        id: "fase-4",
        name: "Fase 4",
        description: "Lancamento e Monitoramento",
        summary: "Lancamento gradual do produto comecando por um grupo piloto e expandindo progressivamente. Acompanhamos de perto as metricas de adocao e coletamos feedback para ajustes continuos.",
        items: [
          { id: "2-4-1", text: "Campanha de comunicacao interna", description: "Materiais e comunicados para apresentar o produto aos colaboradores.", type: "info" },
          { id: "2-4-2", text: "Suporte tecnico estruturado", description: "Equipe e processos prontos para atender usuarios.", type: "info" },
          { id: "2-4-3", text: "Lancar para grupo piloto", description: "Disponibilizar o produto para um grupo restrito de usuarios iniciais.", type: "task", completed: false },
          { id: "2-4-4", text: "Expandir gradualmente para toda empresa", description: "Aumentar o acesso ao produto de forma controlada ate atingir todos os usuarios.", type: "task", completed: false },
          { id: "2-4-5", text: "Coletar metricas de adocao", description: "Medir taxa de uso, engajamento e satisfacao dos usuarios.", type: "task", completed: false },
        ],
      },
    ],
  },
  {
    id: "projeto-3",
    name: "Projeto 3",
    summary: "Iniciativa de transformacao operacional para otimizar processos internos, eliminar gargalos e implementar cultura de melhoria continua em todas as areas da organizacao.",
    phases: [
      {
        id: "fase-1",
        name: "Fase 1",
        description: "Auditoria e Diagnostico",
        summary: "Mapeamento completo da situacao atual da organizacao. Identificamos todos os processos existentes, suas dependencias tecnicas e os principais pontos de melhoria para criar um plano de acao assertivo.",
        items: [
          { id: "3-1-1", text: "Inventario de processos atual", description: "Listagem completa de todos os processos existentes na area.", type: "info" },
          { id: "3-1-2", text: "Mapa de dependencias tecnicas", description: "Diagrama mostrando relacoes entre sistemas e servicos.", type: "info" },
          { id: "3-1-3", text: "Identificar gargalos operacionais", description: "Encontrar pontos de lentidao ou ineficiencia nos processos atuais.", type: "task", completed: true },
          { id: "3-1-4", text: "Documentar riscos e mitigacoes", description: "Listar potenciais riscos do projeto e planos para minimiza-los.", type: "task", completed: false },
          { id: "3-1-5", text: "Priorizar oportunidades de melhoria", description: "Ordenar iniciativas por impacto e viabilidade de implementacao.", type: "task", completed: false },
        ],
      },
      {
        id: "fase-2",
        name: "Fase 2",
        description: "Reestruturacao de Processos",
        summary: "Redesenhamos os processos identificados como prioritarios. Implementamos automacoes, redefinimos responsabilidades e capacitamos as equipes para trabalhar de forma mais eficiente.",
        items: [
          { id: "3-2-1", text: "Novo fluxo de trabalho desenhado", description: "Processo otimizado com etapas claras e responsaveis definidos.", type: "info" },
          { id: "3-2-2", text: "Responsabilidades redefinidas", description: "Nova matriz RACI com papeis e responsabilidades atualizados.", type: "info" },
          { id: "3-2-3", text: "Implementar automacoes basicas", description: "Configurar ferramentas para automatizar tarefas repetitivas.", type: "task", completed: false },
          { id: "3-2-4", text: "Treinar equipes nos novos processos", description: "Capacitar colaboradores para executar os novos fluxos de trabalho.", type: "task", completed: false },
          { id: "3-2-5", text: "Criar dashboards de acompanhamento", description: "Desenvolver paineis visuais para monitorar indicadores de processo.", type: "task", completed: false },
        ],
      },
      {
        id: "fase-3",
        name: "Fase 3",
        description: "Otimizacao Continua",
        summary: "Estabelecemos mecanismos de monitoramento e feedback para garantir que os processos evoluam constantemente. Analisamos dados de performance e fazemos ajustes baseados em evidencias.",
        items: [
          { id: "3-3-1", text: "KPIs de processo definidos", description: "Indicadores chave para medir eficiencia e qualidade dos processos.", type: "info" },
          { id: "3-3-2", text: "Ciclo de feedback estabelecido", description: "Mecanismo para coleta continua de sugestoes de melhoria.", type: "info" },
          { id: "3-3-3", text: "Analisar dados de performance", description: "Revisar metricas coletadas para identificar padroes e anomalias.", type: "task", completed: false },
          { id: "3-3-4", text: "Ajustar processos conforme metricas", description: "Implementar mudancas baseadas na analise de dados de performance.", type: "task", completed: false },
          { id: "3-3-5", text: "Documentar licoes aprendidas", description: "Registrar insights e aprendizados para projetos futuros.", type: "task", completed: false },
        ],
      },
      {
        id: "fase-4",
        name: "Fase 4",
        description: "Consolidacao e Escala",
        summary: "Consolidamos os aprendizados em documentacao reutilizavel e expandimos as melhorias para outras areas da empresa, estabelecendo uma governanca que garante a sustentabilidade das mudancas.",
        items: [
          { id: "3-4-1", text: "Playbook de melhores praticas", description: "Guia com procedimentos padronizados e recomendacoes.", type: "info" },
          { id: "3-4-2", text: "Cases de sucesso documentados", description: "Historias de implementacoes bem-sucedidas para referencia.", type: "info" },
          { id: "3-4-3", text: "Replicar para outras areas", description: "Expandir as melhorias implementadas para outros departamentos.", type: "task", completed: false },
          { id: "3-4-4", text: "Estabelecer governanca de processos", description: "Criar estrutura para garantir manutencao e evolucao dos processos.", type: "task", completed: false },
          { id: "3-4-5", text: "Revisao trimestral institucionalizada", description: "Implementar ciclos regulares de revisao e ajuste de processos.", type: "task", completed: false },
        ],
      },
    ],
  },
];
