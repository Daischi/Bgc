"use client";

import { createContext, useContext, useState, ReactNode } from "react";

type Language = "pt-BR" | "en";

interface Translations {
  projectManagement: string;
  projects: string;
  completedProjects: string;
  trackProgress: string;
  tasksCompleted: string;
  description: string;
  info: string;
  markComplete: string;
  markIncomplete: string;
  overallProgress: string;
  complete: string;
  language: string;
  theme: string;
  light: string;
  dark: string;
  projectSummary: string;
  aboutProject: string;
  phaseSummary: string;
  activities: string;
}

const translations: Record<Language, Translations> = {
  "pt-BR": {
    projectManagement: "Gestão de Projetos",
    projects: "Projetos",
    completedProjects: "Projetos Concluídos",
    trackProgress: "Acompanhe o progresso das fases do projeto",
    tasksCompleted: "tarefas concluídas",
    description: "Descrição",
    info: "Informação",
    markComplete: "Marcar como concluída",
    markIncomplete: "Marcar como não concluída",
    overallProgress: "Progresso Geral",
    complete: "concluído",
    language: "Idioma",
    theme: "Tema",
    light: "Claro",
    dark: "Escuro",
    projectSummary: "Sobre o Projeto",
    aboutProject: "Sobre o Projeto",
    phaseSummary: "Sobre esta Fase",
    activities: "Atividades",
  },
  en: {
    projectManagement: "Project Management",
    projects: "Projects",
    completedProjects: "Completed Projects",
    trackProgress: "Track the progress of the project phases",
    tasksCompleted: "tasks completed",
    description: "Description",
    info: "Information",
    markComplete: "Mark as complete",
    markIncomplete: "Mark as incomplete",
    overallProgress: "Overall Progress",
    complete: "complete",
    language: "Language",
    theme: "Theme",
    light: "Light",
    dark: "Dark",
    projectSummary: "About the Project",
    aboutProject: "About Project",
    phaseSummary: "About this Phase",
    activities: "Activities",
  },
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: Translations;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>("pt-BR");

  return (
    <LanguageContext.Provider
      value={{
        language,
        setLanguage,
        t: translations[language],
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
}
