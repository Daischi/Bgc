"use client";

import { useState, useCallback, useMemo } from "react";
import { ProjectSidebar } from "@/components/project-sidebar";
import { PhaseStepper } from "@/components/phase-stepper";
import { PhaseContent } from "@/components/phase-content";
import { ProjectSummary } from "@/components/project-summary";
import { CircularProgress } from "@/components/circular-progress";
import { SettingsDropdown } from "@/components/settings-dropdown";
import { projectsData, Project } from "@/lib/data";
import { LanguageProvider, useLanguage } from "@/lib/i18n";
import { ThemeProvider } from "@/components/theme-provider";

function ProjectDashboard() {
  const [projects, setProjects] = useState<Project[]>(projectsData);
  const [selectedProjectId, setSelectedProjectId] = useState(projects[0].id);
  const [activePhaseIndex, setActivePhaseIndex] = useState(0);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showAboutProject, setShowAboutProject] = useState(false);
  const { t } = useLanguage();

  const selectedProject = projects.find((p) => p.id === selectedProjectId)!;
  const activePhase = selectedProject.phases[activePhaseIndex];

  // Calculate progress for any project
  const getProjectProgress = useCallback((projectId: string) => {
    const project = projects.find((p) => p.id === projectId);
    if (!project) return 0;
    
    let totalTasks = 0;
    let completedTasks = 0;
    
    project.phases.forEach((phase) => {
      phase.items.forEach((item) => {
        if (item.type === "task") {
          totalTasks++;
          if (item.completed) completedTasks++;
        }
      });
    });
    
    return totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;
  }, [projects]);

  // Calculate overall progress for selected project
  const overallProgress = useMemo(() => {
    return getProjectProgress(selectedProjectId);
  }, [getProjectProgress, selectedProjectId]);

  const handleSelectProject = useCallback((projectId: string) => {
    setSelectedProjectId(projectId);
    setActivePhaseIndex(0);
    setShowAboutProject(false);
  }, []);

  const handleSelectPhase = useCallback((index: number) => {
    setActivePhaseIndex(index);
    setShowAboutProject(false);
  }, []);

  const handleToggleAboutProject = useCallback(() => {
    setShowAboutProject(true);
  }, []);

  const handleToggleTask = useCallback(
    (itemId: string) => {
      setProjects((prevProjects) =>
        prevProjects.map((project) => {
          if (project.id !== selectedProjectId) return project;
          return {
            ...project,
            phases: project.phases.map((phase, phaseIndex) => {
              if (phaseIndex !== activePhaseIndex) return phase;
              return {
                ...phase,
                items: phase.items.map((item) => {
                  if (item.id !== itemId || item.type !== "task") return item;
                  return { ...item, completed: !item.completed };
                }),
              };
            }),
          };
        })
      );
    },
    [selectedProjectId, activePhaseIndex]
  );

  return (
    <div className="min-h-screen bg-background">
      <ProjectSidebar
        projects={projects}
        selectedProjectId={selectedProjectId}
        onSelectProject={handleSelectProject}
        isOpen={sidebarOpen}
        onToggle={() => setSidebarOpen(!sidebarOpen)}
        getProjectProgress={getProjectProgress}
      />

      {/* Main content */}
      <main className="lg:pl-64 min-h-screen">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pt-16 lg:pt-8">
          {/* Top bar with settings */}
          <div className="flex items-center justify-end mb-6">
            <SettingsDropdown />
          </div>

          {/* Project header with circular progress */}
          <header className="mb-8">
            <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-6">
              <div className="flex-1">
                <h2 className="text-2xl font-bold text-foreground">{selectedProject.name}</h2>
                <p className="text-muted-foreground mt-1">
                  {t.trackProgress}
                </p>
              </div>
              
              {/* Circular Progress */}
              <div className="flex flex-col items-center gap-2 flex-shrink-0">
                <CircularProgress percentage={overallProgress} size={100} strokeWidth={8} />
                <span className="text-xs text-muted-foreground font-medium">
                  {t.overallProgress}
                </span>
              </div>
            </div>
          </header>

          {/* Phase stepper */}
          <div className="mb-8">
            <PhaseStepper
              phases={selectedProject.phases}
              activePhaseIndex={activePhaseIndex}
              onSelectPhase={handleSelectPhase}
              showAboutProject={showAboutProject}
              onToggleAboutProject={handleToggleAboutProject}
            />
          </div>

          {/* Content - either project summary or phase content */}
          {showAboutProject ? (
            <ProjectSummary project={selectedProject} overallProgress={overallProgress} />
          ) : (
            <PhaseContent phase={activePhase} onToggleTask={handleToggleTask} />
          )}
        </div>
      </main>
    </div>
  );
}

export default function Home() {
  return (
    <ThemeProvider
      attribute="class"
      defaultTheme="light"
      enableSystem
      disableTransitionOnChange
    >
      <LanguageProvider>
        <ProjectDashboard />
      </LanguageProvider>
    </ThemeProvider>
  );
}
