"use client"

import * as React from "react"
import { Plus, RefreshCw } from "lucide-react"
import { toast } from "sonner"

import { Button } from "@/components/ui/button"
import { DataTable } from "@/components/data-table"
import { EditDialog } from "@/components/edit-dialog"
import { AddDialog } from "@/components/add-dialog"
import { DeleteDialog } from "@/components/delete-dialog"
import { useData } from "@/lib/data-context"
import { useAuth } from "@/lib/auth-context"
import type { Broker } from "@/lib/mock-data"

const brokerFields = [
  { key: "name", label: "Nome", type: "text" as const, required: true },
  { key: "email", label: "E-mail", type: "text" as const, required: true },
  { key: "phone", label: "Telefone", type: "text" as const, required: true },
  { key: "region", label: "Região", type: "text" as const, required: true },
  { key: "status", label: "Status", type: "select" as const, options: ["Active", "Inactive"], required: true, defaultValue: "Active" },
  { key: "clientCount", label: "Qtd. Clientes", type: "number" as const, required: true, defaultValue: 0 },
  { key: "commission", label: "Comissão", type: "number" as const, required: true, defaultValue: 0 },
]

export default function BrokersPage() {
  const { brokers, addBroker, updateBroker, deleteBroker, refreshData, isRefreshing, lastRefresh } = useData()
  const { canEdit } = useAuth()
  
  const [editingItem, setEditingItem] = React.useState<Broker | null>(null)
  const [isEditDialogOpen, setIsEditDialogOpen] = React.useState(false)
  const [isAddDialogOpen, setIsAddDialogOpen] = React.useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = React.useState(false)
  const [deletingItem, setDeletingItem] = React.useState<Broker | null>(null)

  const handleEdit = (item: Broker) => {
    if (!canEdit) {
      toast.error("Você não tem permissão para editar")
      return
    }
    setEditingItem(item)
    setIsEditDialogOpen(true)
  }

  const handleDeleteRequest = (item: Broker) => {
    if (!canEdit) {
      toast.error("Você não tem permissão para excluir")
      return
    }
    setDeletingItem(item)
    setIsDeleteDialogOpen(true)
  }

  const handleDeleteConfirm = () => {
    if (deletingItem) {
      deleteBroker(deletingItem.id)
      toast.success("Broker excluído com sucesso")
      setDeletingItem(null)
      setIsDeleteDialogOpen(false)
    }
  }

  const handleSave = (item: Broker) => {
    updateBroker(item)
    toast.success("Broker atualizado com sucesso")
  }

  const handleAdd = (data: Record<string, unknown>) => {
    addBroker(data as Omit<Broker, "id">)
    toast.success("Broker criado com sucesso")
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Brokers</h1>
          <p className="text-muted-foreground">
            Gerencie os brokers cadastrados no sistema
          </p>
          {lastRefresh && (
            <p className="text-xs text-muted-foreground">
              Última atualização: {lastRefresh.toLocaleTimeString("pt-BR")}
            </p>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={refreshData} disabled={isRefreshing}>
            <RefreshCw className={`mr-2 size-4 ${isRefreshing ? "animate-spin" : ""}`} />
            Atualizar
          </Button>
          {canEdit && (
            <Button onClick={() => setIsAddDialogOpen(true)}>
              <Plus className="mr-2 size-4" />
              Novo Broker
            </Button>
          )}
        </div>
      </div>

      <DataTable
        data={brokers}
        onEdit={canEdit ? handleEdit : undefined}
        onDelete={canEdit ? handleDeleteRequest : undefined}
      />

      <EditDialog
        open={isEditDialogOpen}
        onOpenChange={setIsEditDialogOpen}
        item={editingItem}
        onSave={handleSave}
        title="Editar Broker"
      />

      <AddDialog
        open={isAddDialogOpen}
        onOpenChange={setIsAddDialogOpen}
        onSave={handleAdd}
        title="Novo Broker"
        description="Preencha os campos abaixo para cadastrar um novo broker."
        fields={brokerFields}
      />

      <DeleteDialog
        open={isDeleteDialogOpen}
        onOpenChange={setIsDeleteDialogOpen}
        onConfirm={handleDeleteConfirm}
        title="Excluir Broker"
        description={`Tem certeza que deseja excluir o broker "${deletingItem?.name}"? Esta ação não pode ser desfeita.`}
      />
    </div>
  )
}
