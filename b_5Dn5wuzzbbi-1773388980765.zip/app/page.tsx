"use client"

import * as React from "react"
import { Users, UserCheck, UserX, Clock, DollarSign, Briefcase, RefreshCw, Database, Wifi, WifiOff } from "lucide-react"
import {
  Bar,
  BarChart,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
} from "recharts"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { StatCard } from "@/components/stat-card"
import { useData } from "@/lib/data-context"

const COLORS = ["#3b82f6", "#ef4444", "#f59e0b", "#10b981", "#8b5cf6"]

export default function DashboardPage() {
  const { clients, brokers, sessions, mockMode, refreshData, isRefreshing, lastRefresh } = useData()

  // Calculate stats from context data
  const stats = React.useMemo(() => {
    const totalClients = clients.length
    const activeClients = clients.filter(c => c.status === "Active").length
    const inactiveClients = clients.filter(c => c.status === "Inactive").length
    const pendingClients = clients.filter(c => c.status === "Pending").length
    const totalRevenue = clients.reduce((sum, c) => sum + c.revenue, 0)
    const totalBrokers = brokers.filter(b => b.status === "Active").length

    return {
      totalClients,
      activeClients,
      inactiveClients,
      pendingClients,
      totalRevenue,
      totalBrokers,
    }
  }, [clients, brokers])

  // Chart data
  const clientsByStatus = React.useMemo(() => [
    { status: "Active", count: clients.filter(c => c.status === "Active").length, fill: "var(--color-chart-1)" },
    { status: "Inactive", count: clients.filter(c => c.status === "Inactive").length, fill: "var(--color-chart-2)" },
    { status: "Pending", count: clients.filter(c => c.status === "Pending").length, fill: "var(--color-chart-3)" },
  ], [clients])

  const clientsByCountry = React.useMemo(() => {
    const countryCount: Record<string, number> = {}
    clients.forEach(c => {
      countryCount[c.country] = (countryCount[c.country] || 0) + 1
    })
    return Object.entries(countryCount).map(([country, count]) => ({ country, count }))
  }, [clients])

  const clientsBySegment = React.useMemo(() => {
    const segmentCount: Record<string, number> = {}
    clients.forEach(c => {
      segmentCount[c.segment] = (segmentCount[c.segment] || 0) + 1
    })
    return Object.entries(segmentCount).map(([segment, count]) => ({ segment, count }))
  }, [clients])

  const recentActivity = React.useMemo(() => {
    return [...sessions]
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, 5)
  }, [sessions])

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
      minimumFractionDigits: 0,
    }).format(value)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground">
            Visão geral dos dados da planilha DMA
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 rounded-lg border px-3 py-2">
            {mockMode ? (
              <>
                <Database className="size-4 text-amber-500" />
                <span className="text-xs font-medium">Mock Mode</span>
              </>
            ) : (
              <>
                <Wifi className="size-4 text-emerald-500" />
                <span className="text-xs font-medium">Excel Conectado</span>
              </>
            )}
          </div>
          <Button variant="outline" size="sm" onClick={refreshData} disabled={isRefreshing}>
            <RefreshCw className={`mr-2 size-4 ${isRefreshing ? "animate-spin" : ""}`} />
            Atualizar
          </Button>
        </div>
      </div>

      {lastRefresh && (
        <p className="text-xs text-muted-foreground">
          Última atualização: {lastRefresh.toLocaleTimeString("pt-BR")} - Auto-refresh a cada 10 segundos
        </p>
      )}

      {/* Stat Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
        <StatCard
          title="Total de Clientes"
          value={stats.totalClients}
          icon={Users}
          description="Todos os clientes cadastrados"
        />
        <StatCard
          title="Clientes Ativos"
          value={stats.activeClients}
          icon={UserCheck}
          trend={{ value: 12, isPositive: true }}
        />
        <StatCard
          title="Clientes Inativos"
          value={stats.inactiveClients}
          icon={UserX}
        />
        <StatCard
          title="Clientes Pendentes"
          value={stats.pendingClients}
          icon={Clock}
        />
        <StatCard
          title="Receita Total"
          value={formatCurrency(stats.totalRevenue)}
          icon={DollarSign}
          trend={{ value: 8, isPositive: true }}
        />
        <StatCard
          title="Brokers Ativos"
          value={stats.totalBrokers}
          icon={Briefcase}
        />
      </div>

      {/* Charts Row */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {/* Clients by Status */}
        <Card>
          <CardHeader>
            <CardTitle>Clientes por Status</CardTitle>
            <CardDescription>Distribuição de status dos clientes</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={clientsByStatus}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="count"
                  nameKey="status"
                  label={({ status, count }) => `${status}: ${count}`}
                  labelLine={false}
                >
                  {clientsByStatus.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Clients by Country */}
        <Card>
          <CardHeader>
            <CardTitle>Clientes por País</CardTitle>
            <CardDescription>Distribuição geográfica</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={clientsByCountry} layout="vertical">
                <XAxis type="number" hide />
                <YAxis type="category" dataKey="country" width={80} tick={{ fontSize: 12 }} />
                <Tooltip />
                <Bar dataKey="count" fill="#3b82f6" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Clients by Segment */}
        <Card>
          <CardHeader>
            <CardTitle>Clientes por Segmento</CardTitle>
            <CardDescription>Distribuição por tipo de cliente</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={clientsBySegment}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  dataKey="count"
                  nameKey="segment"
                  label={({ segment, count }) => `${segment}: ${count}`}
                  labelLine={false}
                >
                  {clientsBySegment.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle>Atividade Recente</CardTitle>
          <CardDescription>Últimas sessões registradas</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Cliente</TableHead>
                <TableHead>Broker</TableHead>
                <TableHead>Data</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead>Duração</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {recentActivity.map((session) => (
                <TableRow key={session.id}>
                  <TableCell className="font-medium">{session.clientName}</TableCell>
                  <TableCell>{session.broker}</TableCell>
                  <TableCell>{new Date(session.date).toLocaleDateString("pt-BR")}</TableCell>
                  <TableCell>{session.type}</TableCell>
                  <TableCell>{session.duration}</TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        session.status === "Completed"
                          ? "default"
                          : session.status === "Scheduled"
                          ? "secondary"
                          : "outline"
                      }
                    >
                      {session.status === "Completed"
                        ? "Concluído"
                        : session.status === "Scheduled"
                        ? "Agendado"
                        : "Cancelado"}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
