"use client"

import * as React from "react"
import { Plus, RefreshCw } from "lucide-react"
import { toast } from "sonner"

import { Button } from "@/components/ui/button"
import { DataTable } from "@/components/data-table"
import { EditDialog } from "@/components/edit-dialog"
import { AddDialog } from "@/components/add-dialog"
import { DeleteDialog } from "@/components/delete-dialog"
import { useData } from "@/lib/data-context"
import { useAuth } from "@/lib/auth-context"
import type { Client } from "@/lib/mock-data"

const clientFields = [
  { key: "name", label: "Nome", type: "text" as const, required: true },
  { key: "contact", label: "Contato", type: "text" as const, required: true },
  { key: "email", label: "E-mail", type: "text" as const, required: true },
  { key: "country", label: "País", type: "text" as const, required: true },
  { key: "status", label: "Status", type: "select" as const, options: ["Active", "Inactive", "Pending"], required: true, defaultValue: "Active" },
  { key: "broker", label: "Broker", type: "text" as const, required: true },
  { key: "segment", label: "Segmento", type: "select" as const, options: ["Enterprise", "Corporate", "SMB"], required: true },
  { key: "createdAt", label: "Data Criação", type: "date" as const, required: true },
  { key: "revenue", label: "Receita", type: "number" as const, required: true, defaultValue: 0 },
]

export default function ClientsPage() {
  const { clients, addClient, updateClient, deleteClient, refreshData, isRefreshing, lastRefresh } = useData()
  const { canEdit } = useAuth()
  
  const [editingItem, setEditingItem] = React.useState<Client | null>(null)
  const [isEditDialogOpen, setIsEditDialogOpen] = React.useState(false)
  const [isAddDialogOpen, setIsAddDialogOpen] = React.useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = React.useState(false)
  const [deletingItem, setDeletingItem] = React.useState<Client | null>(null)

  const handleEdit = (item: Client) => {
    if (!canEdit) {
      toast.error("Você não tem permissão para editar")
      return
    }
    setEditingItem(item)
    setIsEditDialogOpen(true)
  }

  const handleDeleteRequest = (item: Client) => {
    if (!canEdit) {
      toast.error("Você não tem permissão para excluir")
      return
    }
    setDeletingItem(item)
    setIsDeleteDialogOpen(true)
  }

  const handleDeleteConfirm = () => {
    if (deletingItem) {
      deleteClient(deletingItem.id)
      toast.success("Cliente excluído com sucesso")
      setDeletingItem(null)
      setIsDeleteDialogOpen(false)
    }
  }

  const handleSave = (item: Client) => {
    updateClient(item)
    toast.success("Cliente atualizado com sucesso")
  }

  const handleAdd = (data: Record<string, unknown>) => {
    addClient(data as Omit<Client, "id">)
    toast.success("Cliente criado com sucesso")
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Clients</h1>
          <p className="text-muted-foreground">
            Gerencie os clientes cadastrados no sistema
          </p>
          {lastRefresh && (
            <p className="text-xs text-muted-foreground">
              Última atualização: {lastRefresh.toLocaleTimeString("pt-BR")}
            </p>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={refreshData} disabled={isRefreshing}>
            <RefreshCw className={`mr-2 size-4 ${isRefreshing ? "animate-spin" : ""}`} />
            Atualizar
          </Button>
          {canEdit && (
            <Button onClick={() => setIsAddDialogOpen(true)}>
              <Plus className="mr-2 size-4" />
              Novo Cliente
            </Button>
          )}
        </div>
      </div>

      <DataTable
        data={clients}
        onEdit={canEdit ? handleEdit : undefined}
        onDelete={canEdit ? handleDeleteRequest : undefined}
      />

      <EditDialog
        open={isEditDialogOpen}
        onOpenChange={setIsEditDialogOpen}
        item={editingItem}
        onSave={handleSave}
        title="Editar Cliente"
      />

      <AddDialog
        open={isAddDialogOpen}
        onOpenChange={setIsAddDialogOpen}
        onSave={handleAdd}
        title="Novo Cliente"
        description="Preencha os campos abaixo para cadastrar um novo cliente."
        fields={clientFields}
      />

      <DeleteDialog
        open={isDeleteDialogOpen}
        onOpenChange={setIsDeleteDialogOpen}
        onConfirm={handleDeleteConfirm}
        title="Excluir Cliente"
        description={`Tem certeza que deseja excluir o cliente "${deletingItem?.name}"? Esta ação não pode ser desfeita.`}
      />
    </div>
  )
}
