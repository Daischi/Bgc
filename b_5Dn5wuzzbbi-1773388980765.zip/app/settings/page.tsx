"use client"

import * as React from "react"
import { Plus, Trash2, RotateCcw, Database, FileSpreadsheet } from "lucide-react"
import { toast } from "sonner"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { defaultColorRules, type ColorRule } from "@/lib/mock-data"
import { useData } from "@/lib/data-context"
import { useAuth } from "@/lib/auth-context"

const colorOptions = [
  { value: "bg-emerald-100 dark:bg-emerald-900/30", label: "Verde", preview: "bg-emerald-500" },
  { value: "bg-red-100 dark:bg-red-900/30", label: "Vermelho", preview: "bg-red-500" },
  { value: "bg-amber-100 dark:bg-amber-900/30", label: "Amarelo", preview: "bg-amber-500" },
  { value: "bg-blue-100 dark:bg-blue-900/30", label: "Azul", preview: "bg-blue-500" },
  { value: "bg-purple-100 dark:bg-purple-900/30", label: "Roxo", preview: "bg-purple-500" },
  { value: "bg-gray-100 dark:bg-gray-800", label: "Cinza", preview: "bg-gray-500" },
  { value: "bg-pink-100 dark:bg-pink-900/30", label: "Rosa", preview: "bg-pink-500" },
  { value: "bg-orange-100 dark:bg-orange-900/30", label: "Laranja", preview: "bg-orange-500" },
]

const textColorOptions = [
  { value: "text-emerald-700 dark:text-emerald-400", label: "Verde", preview: "bg-emerald-700" },
  { value: "text-red-700 dark:text-red-400", label: "Vermelho", preview: "bg-red-700" },
  { value: "text-amber-700 dark:text-amber-400", label: "Amarelo", preview: "bg-amber-700" },
  { value: "text-blue-700 dark:text-blue-400", label: "Azul", preview: "bg-blue-700" },
  { value: "text-purple-700 dark:text-purple-400", label: "Roxo", preview: "bg-purple-700" },
  { value: "text-gray-700 dark:text-gray-400", label: "Cinza", preview: "bg-gray-700" },
  { value: "text-pink-700 dark:text-pink-400", label: "Rosa", preview: "bg-pink-700" },
  { value: "text-orange-700 dark:text-orange-400", label: "Laranja", preview: "bg-orange-700" },
]

export default function SettingsPage() {
  const { mockMode, setMockMode, refreshInterval, setRefreshInterval } = useData()
  const { canEdit } = useAuth()
  
  const [colorRules, setColorRules] = React.useState<ColorRule[]>(defaultColorRules)
  const [newRule, setNewRule] = React.useState<Partial<ColorRule>>({
    column: "",
    value: "",
    backgroundColor: colorOptions[0].value,
    textColor: textColorOptions[0].value,
  })

  const handleAddRule = () => {
    if (!newRule.column || !newRule.value) {
      toast.error("Preencha todos os campos")
      return
    }

    const rule: ColorRule = {
      column: newRule.column!,
      value: newRule.value!,
      backgroundColor: newRule.backgroundColor!,
      textColor: newRule.textColor!,
    }

    setColorRules((prev) => [...prev, rule])
    setNewRule({
      column: "",
      value: "",
      backgroundColor: colorOptions[0].value,
      textColor: textColorOptions[0].value,
    })
    toast.success("Regra de cor adicionada")
  }

  const handleDeleteRule = (index: number) => {
    setColorRules((prev) => prev.filter((_, i) => i !== index))
    toast.success("Regra de cor removida")
  }

  const handleResetRules = () => {
    setColorRules(defaultColorRules)
    toast.success("Regras restauradas para o padrão")
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
        <p className="text-muted-foreground">
          Configure o sistema de acordo com suas preferências
        </p>
      </div>

      <Tabs defaultValue="data" className="space-y-4">
        <TabsList>
          <TabsTrigger value="data">Dados</TabsTrigger>
          <TabsTrigger value="colors">Regras de Cores</TabsTrigger>
          <TabsTrigger value="general">Geral</TabsTrigger>
        </TabsList>

        <TabsContent value="data" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="size-5" />
                Modo de Dados
              </CardTitle>
              <CardDescription>
                Configure a fonte de dados do sistema
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between rounded-lg border p-4">
                <div className="space-y-0.5">
                  <Label htmlFor="mock-mode" className="text-base">Mock Mode</Label>
                  <p className="text-sm text-muted-foreground">
                    Quando ativado, o sistema usa dados de demonstração em vez da planilha real.
                  </p>
                </div>
                <Switch
                  id="mock-mode"
                  checked={mockMode}
                  onCheckedChange={setMockMode}
                />
              </div>

              <Separator />

              <div className="space-y-4">
                <div>
                  <Label htmlFor="refresh-interval">Intervalo de Atualização Automática</Label>
                  <p className="text-sm text-muted-foreground">
                    Define com que frequência os dados são recarregados automaticamente.
                  </p>
                </div>
                <Select
                  value={String(refreshInterval)}
                  onValueChange={(value) => setRefreshInterval(Number(value))}
                >
                  <SelectTrigger id="refresh-interval" className="w-[200px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">Desativado</SelectItem>
                    <SelectItem value="5000">5 segundos</SelectItem>
                    <SelectItem value="10000">10 segundos</SelectItem>
                    <SelectItem value="30000">30 segundos</SelectItem>
                    <SelectItem value="60000">1 minuto</SelectItem>
                    <SelectItem value="300000">5 minutos</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileSpreadsheet className="size-5" />
                Conexão com Excel
              </CardTitle>
              <CardDescription>
                Configure a conexão com a planilha DMA
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {mockMode && (
                <div className="rounded-lg border border-amber-200 bg-amber-50 p-4 text-amber-800 dark:border-amber-800 dark:bg-amber-950 dark:text-amber-200">
                  <p className="font-medium">Modo Mock Ativado</p>
                  <p className="mt-1 text-sm">
                    Desative o modo mock para conectar à planilha real.
                  </p>
                </div>
              )}
              <div className="space-y-2">
                <Label htmlFor="excel-path">Caminho do Arquivo Excel</Label>
                <Input
                  id="excel-path"
                  placeholder="C:\CompanyData\DMA.xlsx"
                  disabled={mockMode}
                />
                <p className="text-xs text-muted-foreground">
                  Caminho local ou de rede onde a planilha DMA está armazenada.
                </p>
              </div>
              <Button variant="outline" disabled={mockMode}>
                Testar Conexão
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Abas da Planilha</CardTitle>
              <CardDescription>
                Abas detectadas na planilha DMA {mockMode && "(mock)"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {["Clients", "Brokers", "Sessions", "Reports"].map((tab) => (
                  <div
                    key={tab}
                    className="rounded-md bg-muted px-3 py-1 text-sm font-medium"
                  >
                    {tab}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="colors" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Regras de Cores</CardTitle>
              <CardDescription>
                Configure como os valores devem ser exibidos com cores nas tabelas.
                Por exemplo, status "Active" pode ser exibido com fundo verde.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Add New Rule Form */}
              {canEdit && (
                <div className="space-y-4 rounded-lg border p-4">
                  <h4 className="font-medium">Adicionar Nova Regra</h4>
                  <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
                    <div className="space-y-2">
                      <Label htmlFor="column">Coluna</Label>
                      <Input
                        id="column"
                        placeholder="ex: status"
                        value={newRule.column}
                        onChange={(e) => setNewRule((prev) => ({ ...prev, column: e.target.value }))}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="value">Valor</Label>
                      <Input
                        id="value"
                        placeholder="ex: Active"
                        value={newRule.value}
                        onChange={(e) => setNewRule((prev) => ({ ...prev, value: e.target.value }))}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Cor de Fundo</Label>
                      <Select
                        value={newRule.backgroundColor}
                        onValueChange={(value) => setNewRule((prev) => ({ ...prev, backgroundColor: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {colorOptions.map((option) => (
                            <SelectItem key={option.value} value={option.value}>
                              <div className="flex items-center gap-2">
                                <div className={`size-3 rounded-full ${option.preview}`} />
                                {option.label}
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Cor do Texto</Label>
                      <Select
                        value={newRule.textColor}
                        onValueChange={(value) => setNewRule((prev) => ({ ...prev, textColor: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {textColorOptions.map((option) => (
                            <SelectItem key={option.value} value={option.value}>
                              <div className="flex items-center gap-2">
                                <div className={`size-3 rounded-full ${option.preview}`} />
                                {option.label}
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex items-end">
                      <Button onClick={handleAddRule} className="w-full">
                        <Plus className="mr-2 size-4" />
                        Adicionar
                      </Button>
                    </div>
                  </div>
                </div>
              )}

              <Separator />

              {/* Existing Rules Table */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium">Regras Configuradas</h4>
                  {canEdit && (
                    <Button variant="outline" size="sm" onClick={handleResetRules}>
                      <RotateCcw className="mr-2 size-4" />
                      Restaurar Padrão
                    </Button>
                  )}
                </div>
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Coluna</TableHead>
                        <TableHead>Valor</TableHead>
                        <TableHead>Preview</TableHead>
                        {canEdit && <TableHead className="w-[100px]">Ações</TableHead>}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {colorRules.map((rule, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-medium">{rule.column}</TableCell>
                          <TableCell>{rule.value}</TableCell>
                          <TableCell>
                            <span className={`inline-flex rounded-md px-2 py-1 text-sm font-medium ${rule.backgroundColor} ${rule.textColor}`}>
                              {rule.value}
                            </span>
                          </TableCell>
                          {canEdit && (
                            <TableCell>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleDeleteRule(index)}
                              >
                                <Trash2 className="size-4 text-destructive" />
                              </Button>
                            </TableCell>
                          )}
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="general" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Configurações Gerais</CardTitle>
              <CardDescription>
                Configure as preferências gerais do sistema
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="company-name">Nome da Empresa</Label>
                <Input id="company-name" defaultValue="BGC Liquidez" disabled={!canEdit} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="spreadsheet-name">Nome da Planilha</Label>
                <Input id="spreadsheet-name" defaultValue="DMA" disabled={!canEdit} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="rows-per-page">Linhas por Página (padrão)</Label>
                <Select defaultValue="10" disabled={!canEdit}>
                  <SelectTrigger id="rows-per-page" className="w-[180px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="5">5 linhas</SelectItem>
                    <SelectItem value="10">10 linhas</SelectItem>
                    <SelectItem value="20">20 linhas</SelectItem>
                    <SelectItem value="50">50 linhas</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
