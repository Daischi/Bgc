"use client"

import * as React from "react"
import { Plus, RefreshCw } from "lucide-react"
import { toast } from "sonner"

import { Button } from "@/components/ui/button"
import { DataTable } from "@/components/data-table"
import { EditDialog } from "@/components/edit-dialog"
import { AddDialog } from "@/components/add-dialog"
import { DeleteDialog } from "@/components/delete-dialog"
import { useData } from "@/lib/data-context"
import { useAuth } from "@/lib/auth-context"
import type { Session } from "@/lib/mock-data"

const sessionFields = [
  { key: "clientId", label: "ID Cliente", type: "text" as const, required: true },
  { key: "clientName", label: "Nome Cliente", type: "text" as const, required: true },
  { key: "broker", label: "Broker", type: "text" as const, required: true },
  { key: "date", label: "Data", type: "date" as const, required: true },
  { key: "duration", label: "Duração", type: "text" as const, required: true },
  { key: "type", label: "Tipo", type: "select" as const, options: ["Call", "Meeting", "Email", "Video"], required: true },
  { key: "status", label: "Status", type: "select" as const, options: ["Completed", "Scheduled", "Cancelled"], required: true, defaultValue: "Scheduled" },
  { key: "notes", label: "Notas", type: "text" as const },
]

export default function SessionsPage() {
  const { sessions, addSession, updateSession, deleteSession, refreshData, isRefreshing, lastRefresh } = useData()
  const { canEdit } = useAuth()
  
  const [editingItem, setEditingItem] = React.useState<Session | null>(null)
  const [isEditDialogOpen, setIsEditDialogOpen] = React.useState(false)
  const [isAddDialogOpen, setIsAddDialogOpen] = React.useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = React.useState(false)
  const [deletingItem, setDeletingItem] = React.useState<Session | null>(null)

  const handleEdit = (item: Session) => {
    if (!canEdit) {
      toast.error("Você não tem permissão para editar")
      return
    }
    setEditingItem(item)
    setIsEditDialogOpen(true)
  }

  const handleDeleteRequest = (item: Session) => {
    if (!canEdit) {
      toast.error("Você não tem permissão para excluir")
      return
    }
    setDeletingItem(item)
    setIsDeleteDialogOpen(true)
  }

  const handleDeleteConfirm = () => {
    if (deletingItem) {
      deleteSession(deletingItem.id)
      toast.success("Sessão excluída com sucesso")
      setDeletingItem(null)
      setIsDeleteDialogOpen(false)
    }
  }

  const handleSave = (item: Session) => {
    updateSession(item)
    toast.success("Sessão atualizada com sucesso")
  }

  const handleAdd = (data: Record<string, unknown>) => {
    addSession(data as Omit<Session, "id">)
    toast.success("Sessão criada com sucesso")
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Sessions</h1>
          <p className="text-muted-foreground">
            Gerencie as sessões e reuniões do sistema
          </p>
          {lastRefresh && (
            <p className="text-xs text-muted-foreground">
              Última atualização: {lastRefresh.toLocaleTimeString("pt-BR")}
            </p>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={refreshData} disabled={isRefreshing}>
            <RefreshCw className={`mr-2 size-4 ${isRefreshing ? "animate-spin" : ""}`} />
            Atualizar
          </Button>
          {canEdit && (
            <Button onClick={() => setIsAddDialogOpen(true)}>
              <Plus className="mr-2 size-4" />
              Nova Sessão
            </Button>
          )}
        </div>
      </div>

      <DataTable
        data={sessions}
        onEdit={canEdit ? handleEdit : undefined}
        onDelete={canEdit ? handleDeleteRequest : undefined}
      />

      <EditDialog
        open={isEditDialogOpen}
        onOpenChange={setIsEditDialogOpen}
        item={editingItem}
        onSave={handleSave}
        title="Editar Sessão"
      />

      <AddDialog
        open={isAddDialogOpen}
        onOpenChange={setIsAddDialogOpen}
        onSave={handleAdd}
        title="Nova Sessão"
        description="Preencha os campos abaixo para cadastrar uma nova sessão."
        fields={sessionFields}
      />

      <DeleteDialog
        open={isDeleteDialogOpen}
        onOpenChange={setIsDeleteDialogOpen}
        onConfirm={handleDeleteConfirm}
        title="Excluir Sessão"
        description={`Tem certeza que deseja excluir esta sessão com "${deletingItem?.clientName}"? Esta ação não pode ser desfeita.`}
      />
    </div>
  )
}
