"use client"

import * as React from "react"
import { Plus, RefreshCw } from "lucide-react"
import { toast } from "sonner"

import { Button } from "@/components/ui/button"
import { DataTable } from "@/components/data-table"
import { EditDialog } from "@/components/edit-dialog"
import { AddDialog } from "@/components/add-dialog"
import { DeleteDialog } from "@/components/delete-dialog"
import { useData } from "@/lib/data-context"
import { useAuth } from "@/lib/auth-context"
import type { Report } from "@/lib/mock-data"

const reportFields = [
  { key: "title", label: "Título", type: "text" as const, required: true },
  { key: "type", label: "Tipo", type: "select" as const, options: ["Monthly", "Weekly", "Quarterly", "Annual"], required: true },
  { key: "createdBy", label: "Criado por", type: "text" as const, required: true },
  { key: "createdAt", label: "Data Criação", type: "date" as const, required: true },
  { key: "status", label: "Status", type: "select" as const, options: ["Draft", "Published", "Archived"], required: true, defaultValue: "Draft" },
  { key: "category", label: "Categoria", type: "text" as const, required: true },
]

export default function ReportsPage() {
  const { reports, addReport, updateReport, deleteReport, refreshData, isRefreshing, lastRefresh } = useData()
  const { canEdit } = useAuth()
  
  const [editingItem, setEditingItem] = React.useState<Report | null>(null)
  const [isEditDialogOpen, setIsEditDialogOpen] = React.useState(false)
  const [isAddDialogOpen, setIsAddDialogOpen] = React.useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = React.useState(false)
  const [deletingItem, setDeletingItem] = React.useState<Report | null>(null)

  const handleEdit = (item: Report) => {
    if (!canEdit) {
      toast.error("Você não tem permissão para editar")
      return
    }
    setEditingItem(item)
    setIsEditDialogOpen(true)
  }

  const handleDeleteRequest = (item: Report) => {
    if (!canEdit) {
      toast.error("Você não tem permissão para excluir")
      return
    }
    setDeletingItem(item)
    setIsDeleteDialogOpen(true)
  }

  const handleDeleteConfirm = () => {
    if (deletingItem) {
      deleteReport(deletingItem.id)
      toast.success("Relatório excluído com sucesso")
      setDeletingItem(null)
      setIsDeleteDialogOpen(false)
    }
  }

  const handleSave = (item: Report) => {
    updateReport(item)
    toast.success("Relatório atualizado com sucesso")
  }

  const handleAdd = (data: Record<string, unknown>) => {
    addReport(data as Omit<Report, "id">)
    toast.success("Relatório criado com sucesso")
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Reports</h1>
          <p className="text-muted-foreground">
            Gerencie os relatórios do sistema
          </p>
          {lastRefresh && (
            <p className="text-xs text-muted-foreground">
              Última atualização: {lastRefresh.toLocaleTimeString("pt-BR")}
            </p>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={refreshData} disabled={isRefreshing}>
            <RefreshCw className={`mr-2 size-4 ${isRefreshing ? "animate-spin" : ""}`} />
            Atualizar
          </Button>
          {canEdit && (
            <Button onClick={() => setIsAddDialogOpen(true)}>
              <Plus className="mr-2 size-4" />
              Novo Relatório
            </Button>
          )}
        </div>
      </div>

      <DataTable
        data={reports}
        onEdit={canEdit ? handleEdit : undefined}
        onDelete={canEdit ? handleDeleteRequest : undefined}
      />

      <EditDialog
        open={isEditDialogOpen}
        onOpenChange={setIsEditDialogOpen}
        item={editingItem}
        onSave={handleSave}
        title="Editar Relatório"
      />

      <AddDialog
        open={isAddDialogOpen}
        onOpenChange={setIsAddDialogOpen}
        onSave={handleAdd}
        title="Novo Relatório"
        description="Preencha os campos abaixo para cadastrar um novo relatório."
        fields={reportFields}
      />

      <DeleteDialog
        open={isDeleteDialogOpen}
        onOpenChange={setIsDeleteDialogOpen}
        onConfirm={handleDeleteConfirm}
        title="Excluir Relatório"
        description={`Tem certeza que deseja excluir o relatório "${deletingItem?.title}"? Esta ação não pode ser desfeita.`}
      />
    </div>
  )
}
