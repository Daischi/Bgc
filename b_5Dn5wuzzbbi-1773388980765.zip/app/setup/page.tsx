"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { CheckCircle2, Circle, FileSpreadsheet, Server, Globe, Database, Users } from "lucide-react"

export default function SetupPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Guia de Configuração</h1>
        <p className="text-muted-foreground">
          Tutorial completo para configurar e conectar a planilha DMA
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Overview Card */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileSpreadsheet className="size-5" />
              Visão Geral do Sistema
            </CardTitle>
            <CardDescription>
              Entenda como o DMA Dashboard funciona
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              O DMA Dashboard é uma aplicação web interna que lê e escreve diretamente na planilha Excel <code className="rounded bg-muted px-1 py-0.5">DMA.xlsx</code>. 
              O sistema é executado localmente em um servidor da empresa e acessado pelos funcionários através da rede local.
            </p>
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant="outline">Next.js</Badge>
              <Badge variant="outline">TypeScript</Badge>
              <Badge variant="outline">Tailwind CSS</Badge>
              <Badge variant="outline">shadcn/ui</Badge>
              <Badge variant="outline">SheetJS (xlsx)</Badge>
            </div>
            <Separator />
            <div className="grid gap-4 sm:grid-cols-3">
              <div className="flex items-center gap-3 rounded-lg border p-3">
                <Users className="size-8 text-primary" />
                <div>
                  <p className="text-sm font-medium">Usuários</p>
                  <p className="text-xs text-muted-foreground">Navegador web</p>
                </div>
              </div>
              <div className="flex items-center gap-3 rounded-lg border p-3">
                <Server className="size-8 text-primary" />
                <div>
                  <p className="text-sm font-medium">Servidor</p>
                  <p className="text-xs text-muted-foreground">Next.js API</p>
                </div>
              </div>
              <div className="flex items-center gap-3 rounded-lg border p-3">
                <Database className="size-8 text-primary" />
                <div>
                  <p className="text-sm font-medium">Dados</p>
                  <p className="text-xs text-muted-foreground">DMA.xlsx</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Step 1 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Circle className="size-5 text-primary" />
              Passo 1: Instalar Dependências
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Abra o terminal na pasta do projeto e execute:
            </p>
            <pre className="overflow-x-auto rounded-lg bg-muted p-4 text-sm">
              <code>npm install</code>
            </pre>
            <p className="text-xs text-muted-foreground">
              Isso instalará todas as dependências necessárias, incluindo o SheetJS para leitura de arquivos Excel.
            </p>
          </CardContent>
        </Card>

        {/* Step 2 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Circle className="size-5 text-primary" />
              Passo 2: Configurar Caminho do Excel
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Crie um arquivo <code className="rounded bg-muted px-1 py-0.5">.env.local</code> na raiz do projeto:
            </p>
            <pre className="overflow-x-auto rounded-lg bg-muted p-4 text-sm">
              <code>{`EXCEL_FILE_PATH=C:\\CompanyData\\DMA.xlsx

# Ou para caminho de rede:
EXCEL_FILE_PATH=\\\\server\\share\\DMA.xlsx`}</code>
            </pre>
            <p className="text-xs text-muted-foreground">
              O caminho deve apontar para a planilha DMA no servidor ou na rede compartilhada.
            </p>
          </CardContent>
        </Card>

        {/* Step 3 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Circle className="size-5 text-primary" />
              Passo 3: Iniciar o Servidor
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Execute o servidor de desenvolvimento:
            </p>
            <pre className="overflow-x-auto rounded-lg bg-muted p-4 text-sm">
              <code>npm run dev</code>
            </pre>
            <p className="text-xs text-muted-foreground">
              Para produção, use <code className="rounded bg-muted px-1 py-0.5">npm run build</code> seguido de <code className="rounded bg-muted px-1 py-0.5">npm start</code>.
            </p>
          </CardContent>
        </Card>

        {/* Step 4 */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Globe className="size-5 text-primary" />
              Passo 4: Acessar o Dashboard
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Acesse o dashboard pelo navegador:
            </p>
            <pre className="overflow-x-auto rounded-lg bg-muted p-4 text-sm">
              <code>{`# Localmente:
http://localhost:3000

# Da rede local:
http://192.168.0.10:3000`}</code>
            </pre>
            <p className="text-xs text-muted-foreground">
              Substitua o IP pelo endereço do servidor na rede local.
            </p>
          </CardContent>
        </Card>

        {/* Excel Structure */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileSpreadsheet className="size-5" />
              Estrutura da Planilha
            </CardTitle>
            <CardDescription>
              Como o sistema interpreta as abas da planilha DMA
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Cada aba (sheet) da planilha se torna um dataset no dashboard. As colunas são detectadas dinamicamente.
            </p>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <div className="rounded-lg border p-4">
                <p className="font-medium">Clients</p>
                <p className="text-xs text-muted-foreground">Cadastro de clientes</p>
              </div>
              <div className="rounded-lg border p-4">
                <p className="font-medium">Brokers</p>
                <p className="text-xs text-muted-foreground">Corretores da empresa</p>
              </div>
              <div className="rounded-lg border p-4">
                <p className="font-medium">Sessions</p>
                <p className="text-xs text-muted-foreground">Reuniões e chamadas</p>
              </div>
              <div className="rounded-lg border p-4">
                <p className="font-medium">Reports</p>
                <p className="text-xs text-muted-foreground">Relatórios gerados</p>
              </div>
            </div>
            <Separator />
            <div className="space-y-2">
              <p className="text-sm font-medium">Detecção de Cores</p>
              <p className="text-xs text-muted-foreground">
                O sistema detecta cores de fundo das células no Excel e aplica classificações automáticas:
              </p>
              <div className="flex flex-wrap gap-2">
                <Badge className="bg-amber-100 text-amber-700">Amarelo = Pendente</Badge>
                <Badge className="bg-red-100 text-red-700">Vermelho = Cancelado</Badge>
                <Badge className="bg-gray-100 text-gray-700">Cinza = Inativo</Badge>
                <Badge className="bg-emerald-100 text-emerald-700">Verde = Ativo</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* User Roles */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="size-5" />
              Níveis de Acesso
            </CardTitle>
            <CardDescription>
              Permissões de cada tipo de usuário
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 sm:grid-cols-3">
              <div className="space-y-2 rounded-lg border p-4">
                <div className="flex items-center gap-2">
                  <Badge>Admin</Badge>
                </div>
                <ul className="space-y-1 text-xs text-muted-foreground">
                  <li className="flex items-center gap-1"><CheckCircle2 className="size-3 text-emerald-500" /> Gerenciar usuários</li>
                  <li className="flex items-center gap-1"><CheckCircle2 className="size-3 text-emerald-500" /> Criar registros</li>
                  <li className="flex items-center gap-1"><CheckCircle2 className="size-3 text-emerald-500" /> Editar registros</li>
                  <li className="flex items-center gap-1"><CheckCircle2 className="size-3 text-emerald-500" /> Excluir registros</li>
                </ul>
              </div>
              <div className="space-y-2 rounded-lg border p-4">
                <div className="flex items-center gap-2">
                  <Badge variant="secondary">Editor</Badge>
                </div>
                <ul className="space-y-1 text-xs text-muted-foreground">
                  <li className="flex items-center gap-1"><Circle className="size-3 text-muted-foreground" /> Gerenciar usuários</li>
                  <li className="flex items-center gap-1"><CheckCircle2 className="size-3 text-emerald-500" /> Criar registros</li>
                  <li className="flex items-center gap-1"><CheckCircle2 className="size-3 text-emerald-500" /> Editar registros</li>
                  <li className="flex items-center gap-1"><Circle className="size-3 text-muted-foreground" /> Excluir registros</li>
                </ul>
              </div>
              <div className="space-y-2 rounded-lg border p-4">
                <div className="flex items-center gap-2">
                  <Badge variant="outline">Viewer</Badge>
                </div>
                <ul className="space-y-1 text-xs text-muted-foreground">
                  <li className="flex items-center gap-1"><Circle className="size-3 text-muted-foreground" /> Gerenciar usuários</li>
                  <li className="flex items-center gap-1"><Circle className="size-3 text-muted-foreground" /> Criar registros</li>
                  <li className="flex items-center gap-1"><Circle className="size-3 text-muted-foreground" /> Editar registros</li>
                  <li className="flex items-center gap-1"><Circle className="size-3 text-muted-foreground" /> Excluir registros</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
