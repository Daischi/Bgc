"use client"

import * as React from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

interface EditDialogProps<T extends Record<string, unknown>> {
  open: boolean
  onOpenChange: (open: boolean) => void
  item: T | null
  onSave: (item: T) => void
  title?: string
}

// Helper to format field names
function formatFieldName(key: string): string {
  return key
    .replace(/([A-Z])/g, " $1")
    .replace(/^./, (str) => str.toUpperCase())
    .replace(/Id$/, "ID")
}

// Status options for different fields
const statusOptions: Record<string, string[]> = {
  status: ["Active", "Inactive", "Pending", "Completed", "Scheduled", "Cancelled", "Draft", "Published", "Archived"],
  type: ["Monthly", "Weekly", "Quarterly", "Annual", "Call", "Meeting", "Email", "Video"],
  segment: ["Enterprise", "Corporate", "SMB"],
}

export function EditDialog<T extends Record<string, unknown>>({
  open,
  onOpenChange,
  item,
  onSave,
  title = "Editar Item",
}: EditDialogProps<T>) {
  const [editedItem, setEditedItem] = React.useState<T | null>(null)

  React.useEffect(() => {
    setEditedItem(item)
  }, [item])

  if (!editedItem) return null

  const handleChange = (key: string, value: unknown) => {
    setEditedItem((prev) => (prev ? { ...prev, [key]: value } : null))
  }

  const handleSave = () => {
    if (editedItem) {
      onSave(editedItem)
      onOpenChange(false)
    }
  }

  const fields = Object.entries(editedItem).filter(([key]) => key !== "id")

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[80vh] overflow-y-auto sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>
            Faça as alterações necessárias e clique em salvar.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          {fields.map(([key, value]) => {
            const options = statusOptions[key.toLowerCase()]
            
            if (options && typeof value === "string") {
              return (
                <div key={key} className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor={key} className="text-right">
                    {formatFieldName(key)}
                  </Label>
                  <Select
                    value={value}
                    onValueChange={(newValue) => handleChange(key, newValue)}
                  >
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder={`Selecione ${formatFieldName(key)}`} />
                    </SelectTrigger>
                    <SelectContent>
                      {options.map((option) => (
                        <SelectItem key={option} value={option}>
                          {option}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )
            }

            return (
              <div key={key} className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor={key} className="text-right">
                  {formatFieldName(key)}
                </Label>
                <Input
                  id={key}
                  value={String(value ?? "")}
                  onChange={(e) => {
                    const newValue =
                      typeof value === "number"
                        ? Number(e.target.value) || 0
                        : e.target.value
                    handleChange(key, newValue)
                  }}
                  type={typeof value === "number" ? "number" : "text"}
                  className="col-span-3"
                />
              </div>
            )
          })}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button onClick={handleSave}>Salvar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
