"use client"

import * as React from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

interface FieldConfig {
  key: string
  label: string
  type: "text" | "number" | "select" | "date"
  options?: string[]
  required?: boolean
  defaultValue?: string | number
}

interface AddDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSave: (item: Record<string, unknown>) => void
  title: string
  description?: string
  fields: FieldConfig[]
}

export function AddDialog({
  open,
  onOpenChange,
  onSave,
  title,
  description = "Preencha os campos abaixo para criar um novo registro.",
  fields,
}: AddDialogProps) {
  const [formData, setFormData] = React.useState<Record<string, unknown>>({})

  React.useEffect(() => {
    if (open) {
      // Reset form with default values when dialog opens
      const defaults: Record<string, unknown> = {}
      fields.forEach((field) => {
        if (field.defaultValue !== undefined) {
          defaults[field.key] = field.defaultValue
        } else if (field.type === "number") {
          defaults[field.key] = 0
        } else if (field.type === "date") {
          defaults[field.key] = new Date().toISOString().split("T")[0]
        } else if (field.type === "select" && field.options?.length) {
          defaults[field.key] = field.options[0]
        } else {
          defaults[field.key] = ""
        }
      })
      setFormData(defaults)
    }
  }, [open, fields])

  const handleChange = (key: string, value: unknown) => {
    setFormData((prev) => ({ ...prev, [key]: value }))
  }

  const handleSave = () => {
    onSave(formData)
    onOpenChange(false)
  }

  const isValid = fields
    .filter((f) => f.required)
    .every((f) => {
      const value = formData[f.key]
      return value !== undefined && value !== ""
    })

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[80vh] overflow-y-auto sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          {fields.map((field) => {
            if (field.type === "select" && field.options) {
              return (
                <div key={field.key} className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor={field.key} className="text-right">
                    {field.label}
                    {field.required && <span className="text-destructive">*</span>}
                  </Label>
                  <Select
                    value={String(formData[field.key] ?? "")}
                    onValueChange={(value) => handleChange(field.key, value)}
                  >
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder={`Selecione ${field.label}`} />
                    </SelectTrigger>
                    <SelectContent>
                      {field.options.map((option) => (
                        <SelectItem key={option} value={option}>
                          {option}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )
            }

            return (
              <div key={field.key} className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor={field.key} className="text-right">
                  {field.label}
                  {field.required && <span className="text-destructive">*</span>}
                </Label>
                <Input
                  id={field.key}
                  value={String(formData[field.key] ?? "")}
                  onChange={(e) => {
                    const value =
                      field.type === "number"
                        ? Number(e.target.value) || 0
                        : e.target.value
                    handleChange(field.key, value)
                  }}
                  type={field.type === "number" ? "number" : field.type === "date" ? "date" : "text"}
                  className="col-span-3"
                />
              </div>
            )
          })}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button onClick={handleSave} disabled={!isValid}>
            Salvar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
