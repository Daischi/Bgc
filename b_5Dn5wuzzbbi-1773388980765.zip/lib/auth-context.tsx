"use client"

import * as React from "react"

export type UserRole = "admin" | "editor" | "viewer"

export interface User {
  id: string
  username: string
  name: string
  email: string
  role: UserRole
}

interface AuthContextType {
  user: User | null
  isAuthenticated: boolean
  login: (username: string, password: string) => Promise<boolean>
  logout: () => void
  canEdit: boolean
  canManageUsers: boolean
}

const AuthContext = React.createContext<AuthContextType | undefined>(undefined)

// Mock users - in production, this would be stored in a local JSON file or SQLite
const mockUsers: (User & { password: string })[] = [
  { id: "1", username: "admin", password: "admin123", name: "Administrador", email: "admin@bgc.com", role: "admin" },
  { id: "2", username: "editor", password: "editor123", name: "Editor", email: "editor@bgc.com", role: "editor" },
  { id: "3", username: "viewer", password: "viewer123", name: "Visualizador", email: "viewer@bgc.com", role: "viewer" },
]

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = React.useState<User | null>(null)
  const [isLoading, setIsLoading] = React.useState(true)

  React.useEffect(() => {
    // Check for stored session
    const storedUser = localStorage.getItem("dma_user")
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser))
      } catch {
        localStorage.removeItem("dma_user")
      }
    }
    setIsLoading(false)
  }, [])

  const login = async (username: string, password: string): Promise<boolean> => {
    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 500))
    
    const foundUser = mockUsers.find(
      (u) => u.username === username && u.password === password
    )
    
    if (foundUser) {
      const { password: _, ...userWithoutPassword } = foundUser
      setUser(userWithoutPassword)
      localStorage.setItem("dma_user", JSON.stringify(userWithoutPassword))
      return true
    }
    
    return false
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("dma_user")
  }

  const canEdit = user?.role === "admin" || user?.role === "editor"
  const canManageUsers = user?.role === "admin"

  if (isLoading) {
    return null
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        login,
        logout,
        canEdit,
        canManageUsers,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = React.useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
