"use client"

import * as React from "react"

export interface ThemeColors {
  primary: string
  background: string
  sidebar: string
  card: string
  accent: string
}

interface ThemeContextType {
  colors: ThemeColors
  setColors: (colors: ThemeColors) => void
  resetColors: () => void
}

const defaultColors: ThemeColors = {
  primary: "210 100% 50%", // Blue - BGC inspired
  background: "0 0% 100%",
  sidebar: "210 40% 98%",
  card: "0 0% 100%",
  accent: "210 100% 50%",
}

const ThemeContext = React.createContext<ThemeContextType | null>(null)

export function useThemeColors() {
  const context = React.useContext(ThemeContext)
  if (!context) {
    throw new Error("useThemeColors must be used within a ThemeColorsProvider")
  }
  return context
}

export function ThemeColorsProvider({ children }: { children: React.ReactNode }) {
  const [colors, setColorsState] = React.useState<ThemeColors>(defaultColors)

  // Load colors from localStorage on mount
  React.useEffect(() => {
    const saved = localStorage.getItem("dma-theme-colors")
    if (saved) {
      try {
        setColorsState(JSON.parse(saved))
      } catch {
        // Invalid JSON, use defaults
      }
    }
  }, [])

  const setColors = React.useCallback((newColors: ThemeColors) => {
    setColorsState(newColors)
    localStorage.setItem("dma-theme-colors", JSON.stringify(newColors))
  }, [])

  const resetColors = React.useCallback(() => {
    setColorsState(defaultColors)
    localStorage.removeItem("dma-theme-colors")
  }, [])

  return (
    <ThemeContext.Provider value={{ colors, setColors, resetColors }}>
      {children}
    </ThemeContext.Provider>
  )
}
