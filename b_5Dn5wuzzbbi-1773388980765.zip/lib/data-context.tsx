"use client"

import * as React from "react"
import {
  mockClients,
  mockBrokers,
  mockSessions,
  mockReports,
  type Client,
  type Broker,
  type Session,
  type Report,
} from "./mock-data"

interface DataContextType {
  // Data
  clients: Client[]
  brokers: Broker[]
  sessions: Session[]
  reports: Report[]
  
  // CRUD operations
  addClient: (client: Omit<Client, "id">) => void
  updateClient: (client: Client) => void
  deleteClient: (id: string) => void
  
  addBroker: (broker: Omit<Broker, "id">) => void
  updateBroker: (broker: Broker) => void
  deleteBroker: (id: string) => void
  
  addSession: (session: Omit<Session, "id">) => void
  updateSession: (session: Session) => void
  deleteSession: (id: string) => void
  
  addReport: (report: Omit<Report, "id">) => void
  updateReport: (report: Report) => void
  deleteReport: (id: string) => void
  
  // Config
  mockMode: boolean
  setMockMode: (value: boolean) => void
  refreshInterval: number
  setRefreshInterval: (value: number) => void
  lastRefresh: Date | null
  refreshData: () => void
  isRefreshing: boolean
}

const DataContext = React.createContext<DataContextType | undefined>(undefined)

function generateId(): string {
  return Math.random().toString(36).substring(2, 9)
}

export function DataProvider({ children }: { children: React.ReactNode }) {
  const [clients, setClients] = React.useState<Client[]>(mockClients)
  const [brokers, setBrokers] = React.useState<Broker[]>(mockBrokers)
  const [sessions, setSessions] = React.useState<Session[]>(mockSessions)
  const [reports, setReports] = React.useState<Report[]>(mockReports)
  
  const [mockMode, setMockMode] = React.useState(true)
  const [refreshInterval, setRefreshInterval] = React.useState(10000) // 10 seconds
  const [lastRefresh, setLastRefresh] = React.useState<Date | null>(null)
  const [isRefreshing, setIsRefreshing] = React.useState(false)

  const refreshData = React.useCallback(() => {
    setIsRefreshing(true)
    // In real implementation, this would fetch from the Excel file via API
    // For now, we just simulate a refresh
    setTimeout(() => {
      setLastRefresh(new Date())
      setIsRefreshing(false)
    }, 500)
  }, [])

  // Auto-refresh
  React.useEffect(() => {
    if (refreshInterval > 0) {
      const interval = setInterval(refreshData, refreshInterval)
      return () => clearInterval(interval)
    }
  }, [refreshInterval, refreshData])

  // Initial refresh
  React.useEffect(() => {
    refreshData()
  }, [refreshData])

  // Client CRUD
  const addClient = (client: Omit<Client, "id">) => {
    const newClient: Client = { ...client, id: generateId() }
    setClients((prev) => [...prev, newClient])
  }
  
  const updateClient = (client: Client) => {
    setClients((prev) => prev.map((c) => (c.id === client.id ? client : c)))
  }
  
  const deleteClient = (id: string) => {
    setClients((prev) => prev.filter((c) => c.id !== id))
  }

  // Broker CRUD
  const addBroker = (broker: Omit<Broker, "id">) => {
    const newBroker: Broker = { ...broker, id: generateId() }
    setBrokers((prev) => [...prev, newBroker])
  }
  
  const updateBroker = (broker: Broker) => {
    setBrokers((prev) => prev.map((b) => (b.id === broker.id ? broker : b)))
  }
  
  const deleteBroker = (id: string) => {
    setBrokers((prev) => prev.filter((b) => b.id !== id))
  }

  // Session CRUD
  const addSession = (session: Omit<Session, "id">) => {
    const newSession: Session = { ...session, id: generateId() }
    setSessions((prev) => [...prev, newSession])
  }
  
  const updateSession = (session: Session) => {
    setSessions((prev) => prev.map((s) => (s.id === session.id ? session : s)))
  }
  
  const deleteSession = (id: string) => {
    setSessions((prev) => prev.filter((s) => s.id !== id))
  }

  // Report CRUD
  const addReport = (report: Omit<Report, "id">) => {
    const newReport: Report = { ...report, id: generateId() }
    setReports((prev) => [...prev, newReport])
  }
  
  const updateReport = (report: Report) => {
    setReports((prev) => prev.map((r) => (r.id === report.id ? report : r)))
  }
  
  const deleteReport = (id: string) => {
    setReports((prev) => prev.filter((r) => r.id !== id))
  }

  return (
    <DataContext.Provider
      value={{
        clients,
        brokers,
        sessions,
        reports,
        addClient,
        updateClient,
        deleteClient,
        addBroker,
        updateBroker,
        deleteBroker,
        addSession,
        updateSession,
        deleteSession,
        addReport,
        updateReport,
        deleteReport,
        mockMode,
        setMockMode,
        refreshInterval,
        setRefreshInterval,
        lastRefresh,
        refreshData,
        isRefreshing,
      }}
    >
      {children}
    </DataContext.Provider>
  )
}

export function useData() {
  const context = React.useContext(DataContext)
  if (context === undefined) {
    throw new Error("useData must be used within a DataProvider")
  }
  return context
}
