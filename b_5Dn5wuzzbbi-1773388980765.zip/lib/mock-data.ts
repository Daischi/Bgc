// Mock data simulating spreadsheet data from DMA

export interface Client {
  id: string
  name: string
  contact: string
  email: string
  country: string
  status: "Active" | "Inactive" | "Pending"
  broker: string
  segment: string
  createdAt: string
  revenue: number
}

export interface Broker {
  id: string
  name: string
  email: string
  phone: string
  region: string
  status: "Active" | "Inactive"
  clientCount: number
  commission: number
}

export interface Session {
  id: string
  clientId: string
  clientName: string
  broker: string
  date: string
  duration: string
  type: "Call" | "Meeting" | "Email" | "Video"
  status: "Completed" | "Scheduled" | "Cancelled"
  notes: string
}

export interface Report {
  id: string
  title: string
  type: "Monthly" | "Weekly" | "Quarterly" | "Annual"
  createdBy: string
  createdAt: string
  status: "Draft" | "Published" | "Archived"
  category: string
}

export const mockClients: Client[] = [
  { id: "1", name: "Acme Corporation", contact: "John Smith", email: "john@acme.com", country: "Brasil", status: "Active", broker: "Carlos Silva", segment: "Enterprise", createdAt: "2024-01-15", revenue: 150000 },
  { id: "2", name: "Global Industries", contact: "Maria Santos", email: "maria@global.com", country: "Brasil", status: "Active", broker: "Ana Costa", segment: "Corporate", createdAt: "2024-02-20", revenue: 280000 },
  { id: "3", name: "Tech Solutions", contact: "Pedro Oliveira", email: "pedro@techsol.com", country: "Argentina", status: "Pending", broker: "Carlos Silva", segment: "SMB", createdAt: "2024-03-10", revenue: 45000 },
  { id: "4", name: "Finance Plus", contact: "Laura Lima", email: "laura@finplus.com", country: "Chile", status: "Active", broker: "Roberto Mendes", segment: "Enterprise", createdAt: "2024-01-05", revenue: 320000 },
  { id: "5", name: "Trading Co", contact: "Rafael Costa", email: "rafael@trading.com", country: "Brasil", status: "Inactive", broker: "Ana Costa", segment: "Corporate", createdAt: "2023-11-20", revenue: 95000 },
  { id: "6", name: "Investment Group", contact: "Carolina Pereira", email: "carolina@invest.com", country: "México", status: "Active", broker: "Carlos Silva", segment: "Enterprise", createdAt: "2024-04-01", revenue: 450000 },
  { id: "7", name: "Capital Markets", contact: "Fernando Alves", email: "fernando@capital.com", country: "Brasil", status: "Pending", broker: "Roberto Mendes", segment: "Corporate", createdAt: "2024-03-25", revenue: 180000 },
  { id: "8", name: "Secure Bank", contact: "Juliana Rocha", email: "juliana@secure.com", country: "Colômbia", status: "Active", broker: "Ana Costa", segment: "Enterprise", createdAt: "2024-02-10", revenue: 520000 },
  { id: "9", name: "Quick Finance", contact: "Marcos Dias", email: "marcos@quick.com", country: "Brasil", status: "Inactive", broker: "Carlos Silva", segment: "SMB", createdAt: "2023-10-15", revenue: 35000 },
  { id: "10", name: "Prime Holdings", contact: "Patricia Nunes", email: "patricia@prime.com", country: "Peru", status: "Active", broker: "Roberto Mendes", segment: "Enterprise", createdAt: "2024-01-28", revenue: 290000 },
  { id: "11", name: "Apex Trading", contact: "Bruno Ferreira", email: "bruno@apex.com", country: "Brasil", status: "Active", broker: "Ana Costa", segment: "Corporate", createdAt: "2024-03-15", revenue: 175000 },
  { id: "12", name: "Nova Investments", contact: "Amanda Silva", email: "amanda@nova.com", country: "Uruguai", status: "Pending", broker: "Carlos Silva", segment: "SMB", createdAt: "2024-04-05", revenue: 62000 },
]

export const mockBrokers: Broker[] = [
  { id: "1", name: "Carlos Silva", email: "carlos@bgc.com", phone: "+55 11 99999-1111", region: "São Paulo", status: "Active", clientCount: 4, commission: 125000 },
  { id: "2", name: "Ana Costa", email: "ana@bgc.com", phone: "+55 11 99999-2222", region: "Rio de Janeiro", status: "Active", clientCount: 4, commission: 185000 },
  { id: "3", name: "Roberto Mendes", email: "roberto@bgc.com", phone: "+55 11 99999-3333", region: "São Paulo", status: "Active", clientCount: 3, commission: 95000 },
  { id: "4", name: "Fernanda Lima", email: "fernanda@bgc.com", phone: "+55 21 99999-4444", region: "Minas Gerais", status: "Inactive", clientCount: 0, commission: 0 },
  { id: "5", name: "Gustavo Santos", email: "gustavo@bgc.com", phone: "+55 31 99999-5555", region: "Brasília", status: "Active", clientCount: 2, commission: 67000 },
]

export const mockSessions: Session[] = [
  { id: "1", clientId: "1", clientName: "Acme Corporation", broker: "Carlos Silva", date: "2024-04-10", duration: "45 min", type: "Video", status: "Completed", notes: "Discussão sobre novos produtos" },
  { id: "2", clientId: "2", clientName: "Global Industries", broker: "Ana Costa", date: "2024-04-12", duration: "30 min", type: "Call", status: "Completed", notes: "Follow-up trimestral" },
  { id: "3", clientId: "4", clientName: "Finance Plus", broker: "Roberto Mendes", date: "2024-04-15", duration: "1h", type: "Meeting", status: "Scheduled", notes: "Apresentação de resultados" },
  { id: "4", clientId: "6", clientName: "Investment Group", broker: "Carlos Silva", date: "2024-04-08", duration: "20 min", type: "Email", status: "Completed", notes: "Documentação enviada" },
  { id: "5", clientId: "8", clientName: "Secure Bank", broker: "Ana Costa", date: "2024-04-18", duration: "2h", type: "Meeting", status: "Scheduled", notes: "Reunião de planejamento anual" },
  { id: "6", clientId: "3", clientName: "Tech Solutions", broker: "Carlos Silva", date: "2024-04-05", duration: "15 min", type: "Call", status: "Cancelled", notes: "Cliente reagendou" },
  { id: "7", clientId: "10", clientName: "Prime Holdings", broker: "Roberto Mendes", date: "2024-04-20", duration: "1h 30min", type: "Video", status: "Scheduled", notes: "Demo de plataforma" },
  { id: "8", clientId: "11", clientName: "Apex Trading", broker: "Ana Costa", date: "2024-04-11", duration: "40 min", type: "Call", status: "Completed", notes: "Negociação de contrato" },
]

export const mockReports: Report[] = [
  { id: "1", title: "Relatório Mensal de Vendas - Março 2024", type: "Monthly", createdBy: "Sistema", createdAt: "2024-04-01", status: "Published", category: "Vendas" },
  { id: "2", title: "Análise de Performance Q1 2024", type: "Quarterly", createdBy: "Ana Costa", createdAt: "2024-04-05", status: "Published", category: "Performance" },
  { id: "3", title: "Relatório Semanal - Semana 15", type: "Weekly", createdBy: "Sistema", createdAt: "2024-04-08", status: "Published", category: "Operações" },
  { id: "4", title: "Projeção Anual 2024", type: "Annual", createdBy: "Roberto Mendes", createdAt: "2024-01-15", status: "Published", category: "Planejamento" },
  { id: "5", title: "Relatório de Compliance Q1", type: "Quarterly", createdBy: "Compliance", createdAt: "2024-04-10", status: "Draft", category: "Compliance" },
  { id: "6", title: "Relatório Mensal de Vendas - Abril 2024", type: "Monthly", createdBy: "Sistema", createdAt: "2024-04-15", status: "Draft", category: "Vendas" },
  { id: "7", title: "Análise de Mercado - América Latina", type: "Quarterly", createdBy: "Carlos Silva", createdAt: "2024-03-20", status: "Archived", category: "Mercado" },
]

// Dataset types for dynamic column detection
export type DatasetName = "clients" | "brokers" | "sessions" | "reports"

export const datasets: Record<DatasetName, unknown[]> = {
  clients: mockClients,
  brokers: mockBrokers,
  sessions: mockSessions,
  reports: mockReports,
}

// Color rules for status columns
export interface ColorRule {
  column: string
  value: string
  backgroundColor: string
  textColor: string
}

export const defaultColorRules: ColorRule[] = [
  { column: "status", value: "Active", backgroundColor: "bg-emerald-100 dark:bg-emerald-900/30", textColor: "text-emerald-700 dark:text-emerald-400" },
  { column: "status", value: "Inactive", backgroundColor: "bg-red-100 dark:bg-red-900/30", textColor: "text-red-700 dark:text-red-400" },
  { column: "status", value: "Pending", backgroundColor: "bg-amber-100 dark:bg-amber-900/30", textColor: "text-amber-700 dark:text-amber-400" },
  { column: "status", value: "Completed", backgroundColor: "bg-emerald-100 dark:bg-emerald-900/30", textColor: "text-emerald-700 dark:text-emerald-400" },
  { column: "status", value: "Scheduled", backgroundColor: "bg-blue-100 dark:bg-blue-900/30", textColor: "text-blue-700 dark:text-blue-400" },
  { column: "status", value: "Cancelled", backgroundColor: "bg-gray-100 dark:bg-gray-800", textColor: "text-gray-700 dark:text-gray-400" },
  { column: "status", value: "Draft", backgroundColor: "bg-amber-100 dark:bg-amber-900/30", textColor: "text-amber-700 dark:text-amber-400" },
  { column: "status", value: "Published", backgroundColor: "bg-emerald-100 dark:bg-emerald-900/30", textColor: "text-emerald-700 dark:text-emerald-400" },
  { column: "status", value: "Archived", backgroundColor: "bg-gray-100 dark:bg-gray-800", textColor: "text-gray-700 dark:text-gray-400" },
]

// Dashboard statistics
export function getDashboardStats() {
  const totalClients = mockClients.length
  const activeClients = mockClients.filter(c => c.status === "Active").length
  const inactiveClients = mockClients.filter(c => c.status === "Inactive").length
  const pendingClients = mockClients.filter(c => c.status === "Pending").length
  const totalRevenue = mockClients.reduce((sum, c) => sum + c.revenue, 0)
  const totalBrokers = mockBrokers.filter(b => b.status === "Active").length
  
  return {
    totalClients,
    activeClients,
    inactiveClients,
    pendingClients,
    totalRevenue,
    totalBrokers,
  }
}

// Chart data
export function getClientsByStatus() {
  return [
    { status: "Active", count: mockClients.filter(c => c.status === "Active").length, fill: "var(--color-chart-1)" },
    { status: "Inactive", count: mockClients.filter(c => c.status === "Inactive").length, fill: "var(--color-chart-2)" },
    { status: "Pending", count: mockClients.filter(c => c.status === "Pending").length, fill: "var(--color-chart-3)" },
  ]
}

export function getClientsByCountry() {
  const countryCount: Record<string, number> = {}
  mockClients.forEach(c => {
    countryCount[c.country] = (countryCount[c.country] || 0) + 1
  })
  return Object.entries(countryCount).map(([country, count]) => ({ country, count }))
}

export function getClientsBySegment() {
  const segmentCount: Record<string, number> = {}
  mockClients.forEach(c => {
    segmentCount[c.segment] = (segmentCount[c.segment] || 0) + 1
  })
  return Object.entries(segmentCount).map(([segment, count]) => ({ segment, count }))
}

export function getRecentActivity() {
  return mockSessions
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 5)
}
