export type VendorStatus = "active" | "inactive"

export type ContractStatus = "pending" | "signed" | "expired"

export type SignatureStatus = "pending" | "signed"

export interface Vendor {
  id: string
  name: string
  cnpj: string
  contactPerson: string
  email: string
  phone: string
  status: VendorStatus
  createdAt: string
}

export interface Contract {
  id: string
  vendorId: string
  name: string
  pdfFileName: string
  status: ContractStatus
  dueDate: string
  createdAt: string
  totalSigners: number
}

export interface ContractSignature {
  id: string
  contractId: string
  signerName: string
  signerEmail: string
  signedAt: string | null
  status: SignatureStatus
  ipAddress: string | null
}

export interface DashboardMetrics {
  totalVendors: number
  totalContracts: number
  pendingContracts: number
  expiringIn30Days: number
}
