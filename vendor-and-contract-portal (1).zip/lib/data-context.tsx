"use client"

import * as React from "react"
import useSWR, { mutate as globalMutate } from "swr"
import { fetcher, apiPost, apiPut, apiDelete } from "./api"
import type {
  Vendor,
  Contract,
  ContractSignature,
  DashboardMetrics,
} from "./types"

// ==========================================
// SWR hooks for data fetching
// ==========================================

export function useDashboard() {
  const { data, error, isLoading, mutate } = useSWR<{
    metrics: DashboardMetrics
    contractsByStatus: { status: string; count: number }[]
    vendorsByStatus: { status: string; count: number }[]
    recentContracts: (Contract & { vendorName: string })[]
  }>("/api/dashboard", fetcher)

  return {
    metrics: data?.metrics ?? { totalVendors: 0, totalContracts: 0, pendingContracts: 0, expiringIn30Days: 0 },
    contractsByStatus: data?.contractsByStatus ?? [],
    vendorsByStatus: data?.vendorsByStatus ?? [],
    recentContracts: data?.recentContracts ?? [],
    error,
    isLoading,
    mutate,
  }
}

export function useVendors() {
  const { data, error, isLoading, mutate } = useSWR<Vendor[]>(
    "/api/vendors",
    fetcher
  )

  const addVendor = React.useCallback(
    async (vendor: Omit<Vendor, "id" | "createdAt">) => {
      await apiPost("/api/vendors", vendor)
      mutate()
      globalMutate("/api/dashboard")
    },
    [mutate]
  )

  const updateVendor = React.useCallback(
    async (id: string, updates: Partial<Vendor>) => {
      await apiPut(`/api/vendors/${id}`, updates)
      mutate()
      globalMutate("/api/dashboard")
    },
    [mutate]
  )

  const deleteVendor = React.useCallback(
    async (id: string) => {
      await apiDelete(`/api/vendors/${id}`)
      mutate()
      globalMutate("/api/dashboard")
    },
    [mutate]
  )

  return {
    vendors: data ?? [],
    error,
    isLoading,
    mutate,
    addVendor,
    updateVendor,
    deleteVendor,
  }
}

export function useVendor(id: string) {
  const { data, error, isLoading } = useSWR<Vendor>(
    id ? `/api/vendors/${id}` : null,
    fetcher
  )
  return { vendor: data, error, isLoading }
}

export function useContracts(vendorId: string) {
  const { data, error, isLoading, mutate } = useSWR<Contract[]>(
    vendorId ? `/api/vendors/${vendorId}/contracts` : null,
    fetcher
  )

  const addContract = React.useCallback(
    async (contractData: {
      name: string
      pdfFileName: string
      pdfPath: string
      dueDate: string
      signers: { name: string; email: string }[]
    }) => {
      await apiPost(`/api/vendors/${vendorId}/contracts`, contractData)
      mutate()
      globalMutate("/api/dashboard")
    },
    [vendorId, mutate]
  )

  const deleteContract = React.useCallback(
    async (contractId: string) => {
      await apiDelete(`/api/vendors/${vendorId}/contracts/${contractId}`)
      mutate()
      globalMutate("/api/dashboard")
    },
    [vendorId, mutate]
  )

  return {
    contracts: data ?? [],
    error,
    isLoading,
    mutate,
    addContract,
    deleteContract,
  }
}

export function useContractDetail(vendorId: string, contractId: string) {
  const { data, error, isLoading, mutate } = useSWR<{
    contract: Contract
    signatures: ContractSignature[]
  }>(
    vendorId && contractId
      ? `/api/vendors/${vendorId}/contracts/${contractId}`
      : null,
    fetcher
  )

  const signSignature = React.useCallback(
    async (signatureId: string) => {
      await apiPost(`/api/signatures/${signatureId}/sign`, {})
      mutate()
      globalMutate(`/api/vendors/${vendorId}/contracts`)
      globalMutate("/api/dashboard")
    },
    [vendorId, mutate]
  )

  return {
    contract: data?.contract ?? null,
    signatures: data?.signatures ?? [],
    error,
    isLoading,
    mutate,
    signSignature,
  }
}

// ==========================================
// DataProvider - now just seeds the DB and provides nothing
// Pages use the SWR hooks directly
// ==========================================

export function DataProvider({ children }: { children: React.ReactNode }) {
  const [seeded, setSeeded] = React.useState(false)

  React.useEffect(() => {
    // Auto-seed database on first load
    fetch("/api/seed", { method: "POST" })
      .then(() => setSeeded(true))
      .catch(() => setSeeded(true)) // continue even if seed fails
  }, [])

  if (!seeded) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
          <span className="text-sm text-muted-foreground">
            Inicializando banco de dados...
          </span>
        </div>
      </div>
    )
  }

  return <>{children}</>
}
