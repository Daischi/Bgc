import Database from "better-sqlite3"
import path from "node:path"

const DB_PATH = path.join(process.cwd(), "data", "kys.db")

let db: Database.Database | null = null

export function getDb(): Database.Database {
  if (!db) {
    // Ensure data directory exists
    const fs = require("node:fs")
    const dir = path.dirname(DB_PATH)
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true })
    }

    db = new Database(DB_PATH)
    db.pragma("journal_mode = WAL")
    db.pragma("foreign_keys = ON")

    // Create tables if they don't exist
    db.exec(`
      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'Operador',
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS vendors (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        cnpj TEXT NOT NULL UNIQUE,
        contact_person TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT DEFAULT '',
        status TEXT NOT NULL DEFAULT 'active',
        created_at TEXT NOT NULL DEFAULT (date('now'))
      );

      CREATE TABLE IF NOT EXISTS contracts (
        id TEXT PRIMARY KEY,
        vendor_id TEXT NOT NULL REFERENCES vendors(id) ON DELETE CASCADE,
        name TEXT NOT NULL,
        pdf_file_name TEXT NOT NULL,
        pdf_path TEXT DEFAULT '',
        status TEXT NOT NULL DEFAULT 'pending',
        due_date TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (date('now')),
        total_signers INTEGER NOT NULL DEFAULT 0
      );

      CREATE TABLE IF NOT EXISTS signatures (
        id TEXT PRIMARY KEY,
        contract_id TEXT NOT NULL REFERENCES contracts(id) ON DELETE CASCADE,
        signer_name TEXT NOT NULL,
        signer_email TEXT NOT NULL,
        signed_at TEXT,
        status TEXT NOT NULL DEFAULT 'pending',
        ip_address TEXT
      );
    `)
  }
  return db
}
