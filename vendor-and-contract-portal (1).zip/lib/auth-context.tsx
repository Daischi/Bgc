"use client"

import * as React from "react"
import { useRouter } from "next/navigation"
import useSWR from "swr"
import { fetcher, apiPost } from "./api"

interface User {
  id: string
  name: string
  email: string
  role: string
}

interface AuthContextType {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
  login: (email: string, password: string) => Promise<string | null>
  register: (name: string, email: string, password: string) => Promise<string | null>
  logout: () => void
}

const AuthContext = React.createContext<AuthContextType | null>(null)

export function useAuth() {
  const context = React.useContext(AuthContext)
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const router = useRouter()
  const { data, mutate, isLoading } = useSWR<{ user: User | null }>(
    "/api/auth/me",
    fetcher,
    {
      revalidateOnFocus: false,
      shouldRetryOnError: false,
      onError: () => {
        // Not logged in, that's fine
      },
    }
  )

  const user = data?.user ?? null

  const login = React.useCallback(
    async (email: string, password: string): Promise<string | null> => {
      try {
        const result = await apiPost<{ user: User }>("/api/auth/login", {
          email,
          password,
        })
        await mutate({ user: result.user }, false)
        router.push("/")
        return null
      } catch (err) {
        return err instanceof Error ? err.message : "Erro ao fazer login"
      }
    },
    [mutate, router]
  )

  const register = React.useCallback(
    async (name: string, email: string, password: string): Promise<string | null> => {
      try {
        const result = await apiPost<{ user: User }>("/api/auth/register", {
          name,
          email,
          password,
        })
        await mutate({ user: result.user }, false)
        router.push("/")
        return null
      } catch (err) {
        return err instanceof Error ? err.message : "Erro ao registrar"
      }
    },
    [mutate, router]
  )

  const logout = React.useCallback(async () => {
    await fetch("/api/auth/me", { method: "DELETE" })
    await mutate({ user: null }, false)
    router.push("/login")
  }, [mutate, router])

  const value = React.useMemo(
    () => ({
      user,
      isAuthenticated: !!user,
      isLoading,
      login,
      register,
      logout,
    }),
    [user, isLoading, login, register, logout]
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}
