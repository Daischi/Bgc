"use client"

import * as React from "react"
import { Input } from "@/components/ui/input"
import { cn } from "@/lib/utils"

function formatCNPJ(value: string): string {
  const digits = value.replace(/\D/g, "").slice(0, 14)
  let formatted = digits
  if (digits.length > 2) formatted = `${digits.slice(0, 2)}.${digits.slice(2)}`
  if (digits.length > 5) formatted = `${digits.slice(0, 2)}.${digits.slice(2, 5)}.${digits.slice(5)}`
  if (digits.length > 8)
    formatted = `${digits.slice(0, 2)}.${digits.slice(2, 5)}.${digits.slice(5, 8)}/${digits.slice(8)}`
  if (digits.length > 12)
    formatted = `${digits.slice(0, 2)}.${digits.slice(2, 5)}.${digits.slice(5, 8)}/${digits.slice(8, 12)}-${digits.slice(12)}`
  return formatted
}

export function validateCNPJ(cnpj: string): boolean {
  const digits = cnpj.replace(/\D/g, "")
  return digits.length === 14
}

interface CNPJInputProps extends Omit<React.ComponentProps<typeof Input>, "onChange" | "value"> {
  value: string
  onChange: (value: string) => void
  className?: string
}

export function CNPJInput({ value, onChange, className, ...props }: CNPJInputProps) {
  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    const formatted = formatCNPJ(e.target.value)
    onChange(formatted)
  }

  return (
    <Input
      {...props}
      value={value}
      onChange={handleChange}
      placeholder="00.000.000/0000-00"
      maxLength={18}
      className={cn(className)}
    />
  )
}
