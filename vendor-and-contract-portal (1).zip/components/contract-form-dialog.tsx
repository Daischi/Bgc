"use client"

import * as React from "react"
import { Upload, Plus, X, CalendarIcon, Loader2 } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Calendar } from "@/components/ui/calendar"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"
import { cn } from "@/lib/utils"

interface Signer {
  name: string
  email: string
}

interface ContractFormData {
  name: string
  pdfFileName: string
  pdfPath: string
  dueDate: string
  signers: Signer[]
}

interface ContractFormDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSubmit: (data: ContractFormData) => void
  vendorName: string
}

export function ContractFormDialog({
  open,
  onOpenChange,
  onSubmit,
  vendorName,
}: ContractFormDialogProps) {
  const [name, setName] = React.useState("")
  const [file, setFile] = React.useState<File | null>(null)
  const [uploadedPath, setUploadedPath] = React.useState("")
  const [uploading, setUploading] = React.useState(false)
  const [dueDate, setDueDate] = React.useState<Date | undefined>(undefined)
  const [signers, setSigners] = React.useState<Signer[]>([
    { name: "", email: "" },
  ])
  const [errors, setErrors] = React.useState<Record<string, string>>({})
  const [isDragging, setIsDragging] = React.useState(false)

  React.useEffect(() => {
    if (open) {
      setName("")
      setFile(null)
      setUploadedPath("")
      setUploading(false)
      setDueDate(undefined)
      setSigners([{ name: "", email: "" }])
      setErrors({})
    }
  }, [open])

  function addSigner() {
    setSigners((prev) => [...prev, { name: "", email: "" }])
  }

  function removeSigner(index: number) {
    if (signers.length > 1) {
      setSigners((prev) => prev.filter((_, i) => i !== index))
    }
  }

  function updateSigner(index: number, field: keyof Signer, value: string) {
    setSigners((prev) =>
      prev.map((s, i) => (i === index ? { ...s, [field]: value } : s)),
    )
  }

  function handleFileSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const selected = e.target.files?.[0]
    if (selected && selected.type === "application/pdf") {
      setFile(selected)
      setUploadedPath("")
      setErrors((prev) => {
        const next = { ...prev }
        delete next.file
        return next
      })
    }
  }

  function handleDrop(e: React.DragEvent) {
    e.preventDefault()
    setIsDragging(false)
    const dropped = e.dataTransfer.files?.[0]
    if (dropped && dropped.type === "application/pdf") {
      setFile(dropped)
      setUploadedPath("")
      setErrors((prev) => {
        const next = { ...prev }
        delete next.file
        return next
      })
    }
  }

  async function uploadFile(): Promise<string | null> {
    if (!file) return null
    if (uploadedPath) return uploadedPath

    setUploading(true)
    try {
      const formData = new FormData()
      formData.append("file", file)

      const res = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      })

      if (!res.ok) {
        throw new Error("Upload failed")
      }

      const data = await res.json()
      setUploadedPath(data.path)
      return data.path
    } catch {
      return null
    } finally {
      setUploading(false)
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    const newErrors: Record<string, string> = {}

    if (!name.trim()) newErrors.name = "Nome do contrato obrigatorio"
    if (!file) newErrors.file = "Selecione um arquivo PDF"
    if (!dueDate) newErrors.dueDate = "Data de vencimento obrigatoria"

    const validSigners = signers.filter(
      (s) => s.name.trim() && s.email.trim(),
    )
    if (validSigners.length === 0)
      newErrors.signers = "Adicione pelo menos um signatario"

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors)
      return
    }

    // Upload the real file first
    const path = await uploadFile()
    if (!path) {
      setErrors({ file: "Erro ao fazer upload do arquivo. Tente novamente." })
      return
    }

    onSubmit({
      name: name.trim(),
      pdfFileName: file!.name,
      pdfPath: path,
      dueDate: dueDate!.toISOString().split("T")[0],
      signers: validSigners,
    })
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Novo Contrato</DialogTitle>
          <DialogDescription>
            Cadastre um novo contrato para {vendorName}.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          {/* Contract Name */}
          <div className="flex flex-col gap-2">
            <Label htmlFor="contract-name">Nome do Contrato</Label>
            <Input
              id="contract-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ex: Contrato de Prestacao de Servicos"
            />
            {errors.name && (
              <span className="text-xs text-destructive">{errors.name}</span>
            )}
          </div>

          {/* PDF Upload Zone */}
          <div className="flex flex-col gap-2">
            <Label>Arquivo PDF</Label>
            <div
              className={cn(
                "flex flex-col items-center justify-center gap-2 rounded-lg border-2 border-dashed p-6 transition-colors cursor-pointer",
                isDragging
                  ? "border-primary bg-primary/5"
                  : "border-border hover:border-primary/50",
              )}
              onDragOver={(e) => {
                e.preventDefault()
                setIsDragging(true)
              }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleDrop}
              onClick={() =>
                document.getElementById("pdf-upload")?.click()
              }
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") {
                  document.getElementById("pdf-upload")?.click()
                }
              }}
              role="button"
              tabIndex={0}
            >
              {uploading ? (
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              ) : (
                <Upload className="h-8 w-8 text-muted-foreground" />
              )}
              {file ? (
                <span className="text-sm font-medium">{file.name}</span>
              ) : (
                <>
                  <span className="text-sm font-medium">
                    Arraste um PDF ou clique para selecionar
                  </span>
                  <span className="text-xs text-muted-foreground">
                    Somente arquivos .pdf
                  </span>
                </>
              )}
              <input
                id="pdf-upload"
                type="file"
                accept=".pdf"
                className="hidden"
                onChange={handleFileSelect}
              />
            </div>
            {errors.file && (
              <span className="text-xs text-destructive">{errors.file}</span>
            )}
          </div>

          {/* Due Date */}
          <div className="flex flex-col gap-2">
            <Label>Data de Vencimento</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "justify-start text-left font-normal",
                    !dueDate && "text-muted-foreground",
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {dueDate
                    ? dueDate.toLocaleDateString("pt-BR")
                    : "Selecione uma data"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={dueDate}
                  onSelect={setDueDate}
                  disabled={(date) => date < new Date()}
                />
              </PopoverContent>
            </Popover>
            {errors.dueDate && (
              <span className="text-xs text-destructive">{errors.dueDate}</span>
            )}
          </div>

          {/* Signers */}
          <div className="flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <Label>Signatarios</Label>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={addSigner}
                className="h-7 text-xs"
              >
                <Plus className="mr-1 h-3 w-3" />
                Adicionar
              </Button>
            </div>
            {errors.signers && (
              <span className="text-xs text-destructive">{errors.signers}</span>
            )}
            <div className="flex flex-col gap-3">
              {signers.map((signer, index) => (
                <div
                  key={index}
                  className="flex items-start gap-2"
                >
                  <div className="flex flex-1 flex-col gap-2 sm:flex-row">
                    <Input
                      placeholder="Nome"
                      value={signer.name}
                      onChange={(e) =>
                        updateSigner(index, "name", e.target.value)
                      }
                      className="flex-1"
                    />
                    <Input
                      placeholder="Email"
                      type="email"
                      value={signer.email}
                      onChange={(e) =>
                        updateSigner(index, "email", e.target.value)
                      }
                      className="flex-1"
                    />
                  </div>
                  {signers.length > 1 && (
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="h-9 w-9 shrink-0 text-muted-foreground hover:text-destructive"
                      onClick={() => removeSigner(index)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </div>

          <DialogFooter className="mt-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              Cancelar
            </Button>
            <Button type="submit" disabled={uploading}>
              {uploading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Enviando...
                </>
              ) : (
                "Cadastrar Contrato"
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
