"use client"

import { Check, Clock, PenLine } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import type { ContractSignature } from "@/lib/types"
import { cn } from "@/lib/utils"

interface SignaturePanelProps {
  signatures: ContractSignature[]
  onSign: (signatureId: string) => void
  contractStatus: string
}

export function SignaturePanel({
  signatures,
  onSign,
  contractStatus,
}: SignaturePanelProps) {
  const signedCount = signatures.filter((s) => s.status === "signed").length
  const totalCount = signatures.length

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold">Assinaturas</h3>
        <span className="text-xs text-muted-foreground">
          {signedCount} de {totalCount}
        </span>
      </div>

      {/* Progress bar */}
      <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
        <div
          className={cn(
            "h-full rounded-full transition-all duration-500",
            signedCount === totalCount
              ? "bg-emerald-500"
              : "bg-primary",
          )}
          style={{
            width: `${totalCount > 0 ? (signedCount / totalCount) * 100 : 0}%`,
          }}
        />
      </div>

      <Separator />

      <div className="flex flex-col gap-3">
        {signatures.map((sig) => (
          <div
            key={sig.id}
            className={cn(
              "flex items-center gap-3 rounded-lg border p-3 transition-colors",
              sig.status === "signed"
                ? "bg-emerald-500/5 border-emerald-500/20"
                : "bg-background",
            )}
          >
            <div
              className={cn(
                "flex h-8 w-8 shrink-0 items-center justify-center rounded-full",
                sig.status === "signed"
                  ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
                  : "bg-amber-500/10 text-amber-600 dark:text-amber-400",
              )}
            >
              {sig.status === "signed" ? (
                <Check className="h-4 w-4" />
              ) : (
                <Clock className="h-4 w-4" />
              )}
            </div>
            <div className="flex flex-1 flex-col gap-0.5 min-w-0">
              <span className="text-sm font-medium truncate">
                {sig.signerName}
              </span>
              <span className="text-xs text-muted-foreground truncate">
                {sig.signerEmail}
              </span>
              {sig.status === "signed" && sig.signedAt && (
                <span className="text-[10px] text-emerald-600 dark:text-emerald-400">
                  Assinado em{" "}
                  {new Date(sig.signedAt).toLocaleDateString("pt-BR", {
                    day: "2-digit",
                    month: "2-digit",
                    year: "numeric",
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                  {sig.ipAddress && ` - IP: ${sig.ipAddress}`}
                </span>
              )}
            </div>
            {sig.status === "pending" && contractStatus !== "expired" && (
              <Button
                size="sm"
                variant="outline"
                className="shrink-0 h-8 text-xs bg-transparent"
                onClick={() => onSign(sig.id)}
              >
                <PenLine className="mr-1 h-3 w-3" />
                Assinar
              </Button>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}
