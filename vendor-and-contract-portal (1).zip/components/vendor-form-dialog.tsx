"use client"

import * as React from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { CNPJInput, validateCNPJ } from "@/components/cnpj-input"
import type { Vendor } from "@/lib/types"

interface VendorFormDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSubmit: (data: Omit<Vendor, "id" | "createdAt">) => void
  initialData?: Vendor | null
}

export function VendorFormDialog({
  open,
  onOpenChange,
  onSubmit,
  initialData,
}: VendorFormDialogProps) {
  const [name, setName] = React.useState("")
  const [cnpj, setCnpj] = React.useState("")
  const [contactPerson, setContactPerson] = React.useState("")
  const [email, setEmail] = React.useState("")
  const [phone, setPhone] = React.useState("")
  const [active, setActive] = React.useState(true)
  const [errors, setErrors] = React.useState<Record<string, string>>({})

  React.useEffect(() => {
    if (initialData) {
      setName(initialData.name)
      setCnpj(initialData.cnpj)
      setContactPerson(initialData.contactPerson)
      setEmail(initialData.email)
      setPhone(initialData.phone)
      setActive(initialData.status === "active")
    } else {
      setName("")
      setCnpj("")
      setContactPerson("")
      setEmail("")
      setPhone("")
      setActive(true)
    }
    setErrors({})
  }, [initialData, open])

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    const newErrors: Record<string, string> = {}

    if (!name.trim()) newErrors.name = "Nome obrigatorio"
    if (!cnpj || !validateCNPJ(cnpj)) newErrors.cnpj = "CNPJ invalido"
    if (!contactPerson.trim()) newErrors.contactPerson = "Contato obrigatorio"
    if (!email.trim() || !email.includes("@"))
      newErrors.email = "Email invalido"

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors)
      return
    }

    onSubmit({
      name: name.trim(),
      cnpj,
      contactPerson: contactPerson.trim(),
      email: email.trim(),
      phone: phone.trim(),
      status: active ? "active" : "inactive",
    })
    onOpenChange(false)
  }

  const isEditing = !!initialData

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>
            {isEditing ? "Editar Fornecedor" : "Novo Fornecedor"}
          </DialogTitle>
          <DialogDescription>
            {isEditing
              ? "Atualize as informacoes do fornecedor."
              : "Preencha os dados para cadastrar um novo fornecedor."}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div className="flex flex-col gap-2">
            <Label htmlFor="vendor-name">Razao Social</Label>
            <Input
              id="vendor-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Nome da empresa"
            />
            {errors.name && (
              <span className="text-xs text-destructive">{errors.name}</span>
            )}
          </div>
          <div className="flex flex-col gap-2">
            <Label htmlFor="vendor-cnpj">CNPJ</Label>
            <CNPJInput
              id="vendor-cnpj"
              value={cnpj}
              onChange={setCnpj}
            />
            {errors.cnpj && (
              <span className="text-xs text-destructive">{errors.cnpj}</span>
            )}
          </div>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="flex flex-col gap-2">
              <Label htmlFor="vendor-contact">Pessoa de Contato</Label>
              <Input
                id="vendor-contact"
                value={contactPerson}
                onChange={(e) => setContactPerson(e.target.value)}
                placeholder="Nome do contato"
              />
              {errors.contactPerson && (
                <span className="text-xs text-destructive">
                  {errors.contactPerson}
                </span>
              )}
            </div>
            <div className="flex flex-col gap-2">
              <Label htmlFor="vendor-phone">Telefone</Label>
              <Input
                id="vendor-phone"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="(00) 00000-0000"
              />
            </div>
          </div>
          <div className="flex flex-col gap-2">
            <Label htmlFor="vendor-email">Email</Label>
            <Input
              id="vendor-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="contato@empresa.com"
            />
            {errors.email && (
              <span className="text-xs text-destructive">{errors.email}</span>
            )}
          </div>
          <div className="flex items-center gap-3">
            <Switch
              id="vendor-status"
              checked={active}
              onCheckedChange={setActive}
            />
            <Label htmlFor="vendor-status" className="text-sm">
              {active ? "Ativo" : "Inativo"}
            </Label>
          </div>
          <DialogFooter className="mt-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              Cancelar
            </Button>
            <Button type="submit">
              {isEditing ? "Salvar" : "Cadastrar"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
