"use client"

import * as React from "react"
import { ZoomIn, ZoomOut, Download, Loader2, FileWarning } from "lucide-react"
import { Button } from "@/components/ui/button"

interface PdfPreviewProps {
  fileName: string
  contractId: string
}

export function PdfPreview({ fileName, contractId }: PdfPreviewProps) {
  const [zoom, setZoom] = React.useState(100)
  const [loading, setLoading] = React.useState(true)
  const [hasError, setHasError] = React.useState(false)

  const pdfUrl = `/api/contracts/${contractId}/file`

  // Check if the file actually exists on the server
  React.useEffect(() => {
    setLoading(true)
    setHasError(false)
    fetch(pdfUrl, { method: "HEAD" })
      .then((res) => {
        if (!res.ok) {
          setHasError(true)
          setLoading(false)
        }
      })
      .catch(() => {
        setHasError(true)
        setLoading(false)
      })
  }, [pdfUrl])

  function handleZoomIn() {
    setZoom((prev) => Math.min(prev + 25, 200))
  }

  function handleZoomOut() {
    setZoom((prev) => Math.max(prev - 25, 50))
  }

  function handleDownload() {
    const link = document.createElement("a")
    link.href = `${pdfUrl}?download=true`
    link.download = fileName || "contrato.pdf"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  return (
    <div className="flex flex-col gap-3">
      {/* Toolbar */}
      <div className="flex items-center justify-between rounded-lg border bg-muted/50 px-3 py-2">
        <span className="text-sm font-medium truncate">{fileName}</span>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={handleZoomOut}
            disabled={zoom <= 50 || hasError}
          >
            <ZoomOut className="h-4 w-4" />
          </Button>
          <span className="text-xs text-muted-foreground px-1 min-w-[40px] text-center">
            {zoom}%
          </span>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={handleZoomIn}
            disabled={zoom >= 200 || hasError}
          >
            <ZoomIn className="h-4 w-4" />
          </Button>
          <div className="mx-1 h-4 w-px bg-border" />
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={handleDownload}
            title="Baixar PDF"
            disabled={hasError}
          >
            <Download className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* PDF Viewer */}
      <div
        className="relative overflow-auto rounded-lg border bg-muted/20"
        style={{ height: "520px" }}
      >
        {hasError ? (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="flex flex-col items-center gap-4 text-center px-6">
              <div className="flex h-14 w-14 items-center justify-center rounded-full bg-muted">
                <FileWarning className="h-7 w-7 text-muted-foreground" />
              </div>
              <div className="flex flex-col gap-1">
                <span className="text-sm font-medium">
                  Arquivo PDF nao disponivel
                </span>
                <span className="text-xs text-muted-foreground max-w-sm">
                  Este contrato ainda nao possui um PDF enviado. Para
                  visualizar e baixar, crie um novo contrato com upload de
                  arquivo PDF.
                </span>
              </div>
            </div>
          </div>
        ) : (
          <>
            {loading && (
              <div className="absolute inset-0 z-10 flex items-center justify-center bg-background/80">
                <div className="flex flex-col items-center gap-3">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  <span className="text-sm text-muted-foreground">
                    Carregando documento...
                  </span>
                </div>
              </div>
            )}
            <iframe
              src={pdfUrl}
              title={`Visualizacao: ${fileName}`}
              className="h-full w-full border-0"
              style={{
                transform: `scale(${zoom / 100})`,
                transformOrigin: "top left",
                width: `${(100 / zoom) * 100}%`,
                height: `${(100 / zoom) * 100}%`,
              }}
              onLoad={() => setLoading(false)}
            />
          </>
        )}
      </div>
    </div>
  )
}
