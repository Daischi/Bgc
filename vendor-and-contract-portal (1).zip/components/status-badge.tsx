import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import type { ContractStatus, VendorStatus, SignatureStatus } from "@/lib/types"

type StatusType = ContractStatus | VendorStatus | SignatureStatus

const STATUS_CONFIG: Record<StatusType, { label: string; className: string }> = {
  active: {
    label: "Ativo",
    className: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20",
  },
  inactive: {
    label: "Inativo",
    className: "bg-muted text-muted-foreground border-border",
  },
  pending: {
    label: "Pendente",
    className: "bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20",
  },
  signed: {
    label: "Assinado",
    className: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20",
  },
  expired: {
    label: "Expirado",
    className: "bg-destructive/10 text-destructive border-destructive/20",
  },
}

interface StatusBadgeProps {
  status: StatusType
  className?: string
}

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const config = STATUS_CONFIG[status]
  return (
    <Badge
      variant="outline"
      className={cn("text-xs font-medium", config.className, className)}
    >
      {config.label}
    </Badge>
  )
}
