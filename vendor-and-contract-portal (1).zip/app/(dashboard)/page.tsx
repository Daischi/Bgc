"use client"

import { Building2, FileText, Clock, AlertTriangle } from "lucide-react"
import { AppHeader } from "@/components/app-header"
import { MetricCard } from "@/components/metric-card"
import { StatusBadge } from "@/components/status-badge"
import { useDashboard } from "@/lib/data-context"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "@/components/ui/chart"
import { Bar, BarChart, XAxis, YAxis, Cell, PieChart, Pie } from "recharts"
import { Skeleton } from "@/components/ui/skeleton"

const statusLabelMap: Record<string, string> = {
  pending: "Pendente",
  signed: "Assinado",
  expired: "Expirado",
}
const statusColorMap: Record<string, string> = {
  pending: "hsl(45, 93%, 47%)",
  signed: "hsl(142, 71%, 45%)",
  expired: "hsl(0, 72%, 51%)",
}
const vendorStatusLabelMap: Record<string, string> = {
  active: "Ativos",
  inactive: "Inativos",
}
const vendorStatusColorMap: Record<string, string> = {
  active: "hsl(142, 71%, 45%)",
  inactive: "hsl(0, 0%, 60%)",
}

const barChartConfig: ChartConfig = {
  count: { label: "Contratos" },
  pending: { label: "Pendente", color: "hsl(45, 93%, 47%)" },
  signed: { label: "Assinado", color: "hsl(142, 71%, 45%)" },
  expired: { label: "Expirado", color: "hsl(0, 72%, 51%)" },
}

const pieChartConfig: ChartConfig = {
  vendors: { label: "Fornecedores" },
  active: { label: "Ativos", color: "hsl(142, 71%, 45%)" },
  inactive: { label: "Inativos", color: "hsl(0, 0%, 60%)" },
}

export default function DashboardPage() {
  const {
    metrics,
    contractsByStatus,
    vendorsByStatus,
    recentContracts,
    isLoading,
  } = useDashboard()

  const contractStatusData = contractsByStatus.map((c) => ({
    status: statusLabelMap[c.status] || c.status,
    count: c.count,
    fill: statusColorMap[c.status] || "hsl(0,0%,60%)",
  }))

  const vendorStatusData = vendorsByStatus.map((v) => ({
    name: vendorStatusLabelMap[v.status] || v.status,
    value: v.count,
    fill: vendorStatusColorMap[v.status] || "hsl(0,0%,60%)",
  }))

  if (isLoading) {
    return (
      <>
        <AppHeader breadcrumbs={[{ label: "Dashboard" }]} />
        <div className="flex flex-col gap-6 p-6">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-28 rounded-lg" />
            ))}
          </div>
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
            <Skeleton className="h-80 rounded-lg" />
            <Skeleton className="h-80 rounded-lg" />
          </div>
          <Skeleton className="h-64 rounded-lg" />
        </div>
      </>
    )
  }

  return (
    <>
      <AppHeader breadcrumbs={[{ label: "Dashboard" }]} />
      <div className="flex flex-col gap-6 p-6">
        {/* Metric Cards */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <MetricCard
            title="Total Fornecedores"
            value={metrics.totalVendors}
            icon={Building2}
          />
          <MetricCard
            title="Total Contratos"
            value={metrics.totalContracts}
            icon={FileText}
          />
          <MetricCard
            title="Contratos Pendentes"
            value={metrics.pendingContracts}
            icon={Clock}
            variant="warning"
          />
          <MetricCard
            title="Expirando em 30 dias"
            value={metrics.expiringIn30Days}
            icon={AlertTriangle}
            variant="danger"
          />
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-base font-semibold">
                Contratos por Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={barChartConfig}
                className="h-[260px] w-full"
              >
                <BarChart
                  data={contractStatusData}
                  margin={{ top: 8, right: 8, bottom: 8, left: 8 }}
                >
                  <XAxis
                    dataKey="status"
                    tickLine={false}
                    axisLine={false}
                    fontSize={12}
                  />
                  <YAxis
                    tickLine={false}
                    axisLine={false}
                    fontSize={12}
                    allowDecimals={false}
                  />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                    {contractStatusData.map((entry) => (
                      <Cell key={entry.status} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ChartContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base font-semibold">
                Fornecedores por Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={pieChartConfig}
                className="h-[260px] w-full"
              >
                <PieChart>
                  <ChartTooltip content={<ChartTooltipContent nameKey="name" />} />
                  <Pie
                    data={vendorStatusData}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    strokeWidth={2}
                    stroke="hsl(var(--background))"
                  >
                    {vendorStatusData.map((entry) => (
                      <Cell key={entry.name} fill={entry.fill} />
                    ))}
                  </Pie>
                </PieChart>
              </ChartContainer>
              <div className="flex items-center justify-center gap-6 mt-2">
                {vendorStatusData.map((entry) => (
                  <div key={entry.name} className="flex items-center gap-2">
                    <div
                      className="h-3 w-3 rounded-full"
                      style={{ backgroundColor: entry.fill }}
                    />
                    <span className="text-sm text-muted-foreground">
                      {entry.name}: {entry.value}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Contracts Table */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-semibold">
              Contratos Recentes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Contrato</TableHead>
                  <TableHead>Fornecedor</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Vencimento</TableHead>
                  <TableHead className="text-right">Criado em</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {recentContracts.map((contract) => (
                  <TableRow key={contract.id}>
                    <TableCell className="font-medium">
                      {contract.name}
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {contract.vendorName ?? "-"}
                    </TableCell>
                    <TableCell>
                      <StatusBadge status={contract.status} />
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {new Date(contract.dueDate).toLocaleDateString("pt-BR")}
                    </TableCell>
                    <TableCell className="text-right text-muted-foreground">
                      {new Date(contract.createdAt).toLocaleDateString("pt-BR")}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </>
  )
}
