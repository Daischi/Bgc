import { NextResponse } from "next/server"
import { hashSync } from "bcryptjs"
import { getDb } from "@/lib/db"

export async function POST() {
  try {
    const db = getDb()

    // Check if data already exists
    const count = (
      db.prepare("SELECT COUNT(*) as c FROM vendors").get() as { c: number }
    ).c
    if (count > 0) {
      return NextResponse.json({ message: "Database already seeded", count })
    }

    // Seed admin user
    const adminHash = hashSync("admin123", 10)
    db.prepare(
      "INSERT OR IGNORE INTO users (id, name, email, password_hash, role) VALUES (?, ?, ?, ?, ?)"
    ).run("u1", "Admin BGC", "admin@bgcliquidez.com.br", adminHash, "Administrador")

    // Seed vendors
    const insertVendor = db.prepare(
      "INSERT INTO vendors (id, name, cnpj, contact_person, email, phone, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
    )
    const vendors = [
      ["v1", "Tecnologia Alpha Ltda", "12.345.678/0001-90", "Carlos Silva", "carlos@alpha.com.br", "(11) 98765-4321", "active", "2025-08-15"],
      ["v2", "Consultoria Beta S.A.", "23.456.789/0001-01", "Ana Oliveira", "ana@betaconsult.com.br", "(21) 99876-5432", "active", "2025-09-02"],
      ["v3", "Servicos Gamma Eireli", "34.567.890/0001-12", "Roberto Santos", "roberto@gamma.com.br", "(31) 91234-5678", "inactive", "2025-06-20"],
      ["v4", "Logistica Delta Ltda", "45.678.901/0001-23", "Mariana Costa", "mariana@deltalog.com.br", "(41) 92345-6789", "active", "2025-10-10"],
      ["v5", "Financeira Epsilon S.A.", "56.789.012/0001-34", "Pedro Almeida", "pedro@epsilon.com.br", "(51) 93456-7890", "active", "2025-11-01"],
      ["v6", "Seguranca Zeta Ltda", "67.890.123/0001-45", "Lucia Ferreira", "lucia@zetaseg.com.br", "(61) 94567-8901", "active", "2025-07-18"],
      ["v7", "Infraestrutura Eta S.A.", "78.901.234/0001-56", "Fernando Lima", "fernando@etainfra.com.br", "(71) 95678-9012", "inactive", "2025-05-05"],
      ["v8", "Marketing Theta Digital", "89.012.345/0001-67", "Juliana Souza", "juliana@thetamkt.com.br", "(81) 96789-0123", "active", "2025-12-01"],
    ]
    for (const v of vendors) insertVendor.run(...v)

    // Seed contracts (pdf_path is empty for seed data - real uploads will populate it)
    const insertContract = db.prepare(
      "INSERT INTO contracts (id, vendor_id, name, pdf_file_name, pdf_path, status, due_date, created_at, total_signers) VALUES (?, ?, ?, ?, '', ?, ?, ?, ?)"
    )
    const contracts = [
      ["c1", "v1", "Contrato de Licenciamento de Software", "licenciamento-software-alpha.pdf", "signed", "2026-08-15", "2025-08-20", 2],
      ["c2", "v1", "Acordo de Suporte Tecnico", "suporte-tecnico-alpha.pdf", "pending", "2026-03-10", "2025-12-01", 3],
      ["c3", "v2", "Contrato de Consultoria Estrategica", "consultoria-beta.pdf", "signed", "2026-09-02", "2025-09-10", 2],
      ["c4", "v2", "Termo de Confidencialidade (NDA)", "nda-beta.pdf", "pending", "2026-02-28", "2026-01-05", 2],
      ["c5", "v3", "Contrato de Prestacao de Servicos", "servicos-gamma.pdf", "expired", "2025-12-31", "2025-06-25", 2],
      ["c6", "v4", "Contrato de Transporte e Logistica", "logistica-delta.pdf", "signed", "2026-10-10", "2025-10-15", 2],
      ["c7", "v4", "Acordo de Nivel de Servico (SLA)", "sla-delta.pdf", "pending", "2026-03-15", "2026-01-10", 4],
      ["c8", "v5", "Contrato de Servicos Financeiros", "financeiro-epsilon.pdf", "signed", "2026-11-01", "2025-11-05", 3],
      ["c9", "v6", "Contrato de Seguranca Patrimonial", "seguranca-zeta.pdf", "pending", "2026-02-18", "2025-12-20", 2],
      ["c10", "v7", "Contrato de Manutencao Predial", "manutencao-eta.pdf", "expired", "2025-11-30", "2025-05-10", 2],
      ["c11", "v8", "Contrato de Campanha Digital", "campanha-theta.pdf", "pending", "2026-03-01", "2026-01-15", 2],
      ["c12", "v5", "Aditivo Contratual - Compliance", "compliance-epsilon.pdf", "pending", "2026-02-15", "2026-01-20", 3],
    ]
    for (const c of contracts) insertContract.run(...c)

    // Seed signatures
    const insertSig = db.prepare(
      "INSERT INTO signatures (id, contract_id, signer_name, signer_email, signed_at, status, ip_address) VALUES (?, ?, ?, ?, ?, ?, ?)"
    )
    const sigs = [
      ["s1", "c1", "Carlos Silva", "carlos@alpha.com.br", "2025-08-22T14:30:00Z", "signed", "189.28.100.42"],
      ["s2", "c1", "Diretor Financeiro BGC", "financeiro@bgcliquidez.com.br", "2025-08-23T10:15:00Z", "signed", "200.158.50.10"],
      ["s3", "c2", "Carlos Silva", "carlos@alpha.com.br", "2025-12-05T09:00:00Z", "signed", "189.28.100.42"],
      ["s4", "c2", "Gerente TI BGC", "ti@bgcliquidez.com.br", null, "pending", null],
      ["s5", "c2", "Diretor Operacional BGC", "operacional@bgcliquidez.com.br", null, "pending", null],
      ["s6", "c3", "Ana Oliveira", "ana@betaconsult.com.br", "2025-09-15T11:45:00Z", "signed", "177.70.22.88"],
      ["s7", "c3", "Diretor Financeiro BGC", "financeiro@bgcliquidez.com.br", "2025-09-16T16:20:00Z", "signed", "200.158.50.10"],
      ["s8", "c4", "Ana Oliveira", "ana@betaconsult.com.br", null, "pending", null],
      ["s9", "c4", "Compliance BGC", "compliance@bgcliquidez.com.br", null, "pending", null],
      ["s10", "c5", "Roberto Santos", "roberto@gamma.com.br", "2025-07-01T08:30:00Z", "signed", "201.12.44.55"],
      ["s11", "c5", "Diretor Financeiro BGC", "financeiro@bgcliquidez.com.br", null, "pending", null],
      ["s12", "c6", "Mariana Costa", "mariana@deltalog.com.br", "2025-10-18T13:00:00Z", "signed", "179.210.55.33"],
      ["s13", "c6", "Diretor Operacional BGC", "operacional@bgcliquidez.com.br", "2025-10-19T09:30:00Z", "signed", "200.158.50.10"],
      ["s14", "c7", "Mariana Costa", "mariana@deltalog.com.br", "2026-01-12T10:00:00Z", "signed", "179.210.55.33"],
      ["s15", "c7", "Gerente Logistica BGC", "logistica@bgcliquidez.com.br", null, "pending", null],
      ["s16", "c7", "Diretor Operacional BGC", "operacional@bgcliquidez.com.br", null, "pending", null],
      ["s17", "c7", "Compliance BGC", "compliance@bgcliquidez.com.br", null, "pending", null],
      ["s18", "c8", "Pedro Almeida", "pedro@epsilon.com.br", "2025-11-10T14:15:00Z", "signed", "187.45.78.90"],
      ["s19", "c8", "Diretor Financeiro BGC", "financeiro@bgcliquidez.com.br", "2025-11-11T11:00:00Z", "signed", "200.158.50.10"],
      ["s20", "c8", "Compliance BGC", "compliance@bgcliquidez.com.br", "2025-11-12T09:45:00Z", "signed", "200.158.50.11"],
      ["s21", "c9", "Lucia Ferreira", "lucia@zetaseg.com.br", null, "pending", null],
      ["s22", "c9", "Diretor Operacional BGC", "operacional@bgcliquidez.com.br", null, "pending", null],
      ["s23", "c10", "Fernando Lima", "fernando@etainfra.com.br", "2025-05-15T10:00:00Z", "signed", "200.100.33.22"],
      ["s24", "c10", "Diretor Financeiro BGC", "financeiro@bgcliquidez.com.br", null, "pending", null],
      ["s25", "c11", "Juliana Souza", "juliana@thetamkt.com.br", null, "pending", null],
      ["s26", "c11", "Gerente Marketing BGC", "marketing@bgcliquidez.com.br", null, "pending", null],
      ["s27", "c12", "Pedro Almeida", "pedro@epsilon.com.br", "2026-01-22T15:30:00Z", "signed", "187.45.78.90"],
      ["s28", "c12", "Compliance BGC", "compliance@bgcliquidez.com.br", null, "pending", null],
      ["s29", "c12", "Diretor Financeiro BGC", "financeiro@bgcliquidez.com.br", null, "pending", null],
    ]
    for (const s of sigs) insertSig.run(...s)

    return NextResponse.json({ message: "Database seeded successfully" })
  } catch (error) {
    console.error("Seed error:", error)
    return NextResponse.json({ error: "Erro ao fazer seed" }, { status: 500 })
  }
}
