import { NextResponse } from "next/server"
import { getDb } from "@/lib/db"

export async function GET() {
  try {
    const db = getDb()

    const totalVendors = (
      db.prepare("SELECT COUNT(*) as c FROM vendors").get() as { c: number }
    ).c
    const totalContracts = (
      db.prepare("SELECT COUNT(*) as c FROM contracts").get() as { c: number }
    ).c
    const pendingContracts = (
      db
        .prepare("SELECT COUNT(*) as c FROM contracts WHERE status = 'pending'")
        .get() as { c: number }
    ).c

    const now = new Date().toISOString().split("T")[0]
    const in30 = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
      .toISOString()
      .split("T")[0]
    const expiringIn30Days = (
      db
        .prepare(
          "SELECT COUNT(*) as c FROM contracts WHERE due_date >= ? AND due_date <= ? AND status != 'expired'"
        )
        .get(now, in30) as { c: number }
    ).c

    const contractsByStatus = db
      .prepare(
        "SELECT status, COUNT(*) as count FROM contracts GROUP BY status"
      )
      .all() as { status: string; count: number }[]

    const vendorsByStatus = db
      .prepare(
        "SELECT status, COUNT(*) as count FROM vendors GROUP BY status"
      )
      .all() as { status: string; count: number }[]

    const recentContracts = db
      .prepare(
        `SELECT c.*, v.name as vendor_name 
         FROM contracts c 
         JOIN vendors v ON c.vendor_id = v.id 
         ORDER BY c.created_at DESC 
         LIMIT 5`
      )
      .all() as Array<{
      id: string
      vendor_id: string
      name: string
      pdf_file_name: string
      status: string
      due_date: string
      created_at: string
      total_signers: number
      vendor_name: string
    }>

    return NextResponse.json({
      metrics: {
        totalVendors,
        totalContracts,
        pendingContracts,
        expiringIn30Days,
      },
      contractsByStatus,
      vendorsByStatus,
      recentContracts: recentContracts.map((c) => ({
        id: c.id,
        vendorId: c.vendor_id,
        name: c.name,
        pdfFileName: c.pdf_file_name,
        status: c.status,
        dueDate: c.due_date,
        createdAt: c.created_at,
        totalSigners: c.total_signers,
        vendorName: c.vendor_name,
      })),
    })
  } catch (error) {
    console.error("Dashboard error:", error)
    return NextResponse.json(
      { error: "Erro interno do servidor" },
      { status: 500 }
    )
  }
}
