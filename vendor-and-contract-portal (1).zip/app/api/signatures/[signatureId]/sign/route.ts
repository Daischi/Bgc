import { NextResponse } from "next/server"
import { getDb } from "@/lib/db"

export async function POST(
  request: Request,
  { params }: { params: Promise<{ signatureId: string }> }
) {
  try {
    const { signatureId } = await params
    const db = getDb()

    const sig = db
      .prepare("SELECT * FROM signatures WHERE id = ?")
      .get(signatureId) as Record<string, unknown> | undefined
    if (!sig) {
      return NextResponse.json(
        { error: "Assinatura nao encontrada" },
        { status: 404 }
      )
    }
    if (sig.status === "signed") {
      return NextResponse.json(
        { error: "Ja assinado" },
        { status: 400 }
      )
    }

    // Get IP from request headers
    const forwarded = request.headers.get("x-forwarded-for")
    const ip = forwarded?.split(",")[0] || "127.0.0.1"
    const signedAt = new Date().toISOString()

    db.prepare(
      "UPDATE signatures SET status = 'signed', signed_at = ?, ip_address = ? WHERE id = ?"
    ).run(signedAt, ip, signatureId)

    // Check if all signatures for the contract are now signed
    const contractId = sig.contract_id as string
    const pendingCount = (
      db
        .prepare(
          "SELECT COUNT(*) as c FROM signatures WHERE contract_id = ? AND status = 'pending'"
        )
        .get(contractId) as { c: number }
    ).c

    if (pendingCount === 0) {
      db.prepare(
        "UPDATE contracts SET status = 'signed' WHERE id = ?"
      ).run(contractId)
    }

    return NextResponse.json({
      id: signatureId,
      contractId,
      signerName: sig.signer_name,
      signerEmail: sig.signer_email,
      signedAt,
      status: "signed",
      ipAddress: ip,
    })
  } catch (error) {
    console.error("Sign error:", error)
    return NextResponse.json({ error: "Erro interno" }, { status: 500 })
  }
}
