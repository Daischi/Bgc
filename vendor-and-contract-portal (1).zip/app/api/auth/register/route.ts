import { NextResponse } from "next/server"
import { hashSync } from "bcryptjs"
import { getDb } from "@/lib/db"
import { signToken, getTokenCookieOptions } from "@/lib/jwt"

export async function POST(request: Request) {
  try {
    const { name, email, password } = await request.json()
    if (!name || !email || !password) {
      return NextResponse.json(
        { error: "Todos os campos sao obrigatorios" },
        { status: 400 }
      )
    }
    if (password.length < 6) {
      return NextResponse.json(
        { error: "Senha deve ter no minimo 6 caracteres" },
        { status: 400 }
      )
    }

    const db = getDb()
    const existing = db
      .prepare("SELECT id FROM users WHERE email = ?")
      .get(email)
    if (existing) {
      return NextResponse.json(
        { error: "Email ja cadastrado" },
        { status: 409 }
      )
    }

    const id = `u${Date.now()}`
    const passwordHash = hashSync(password, 10)
    db.prepare(
      "INSERT INTO users (id, name, email, password_hash, role) VALUES (?, ?, ?, ?, ?)"
    ).run(id, name, email, passwordHash, "Operador")

    const token = await signToken({ id, name, email, role: "Operador" })
    const response = NextResponse.json({
      user: { id, name, email, role: "Operador" },
    })
    response.cookies.set(getTokenCookieOptions(token))
    return response
  } catch (error) {
    console.error("Register error:", error)
    return NextResponse.json(
      { error: "Erro interno do servidor" },
      { status: 500 }
    )
  }
}
