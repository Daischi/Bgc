import { NextResponse } from "next/server"
import { compareSync } from "bcryptjs"
import { getDb } from "@/lib/db"
import { signToken, getTokenCookieOptions } from "@/lib/jwt"

export async function POST(request: Request) {
  try {
    const { email, password } = await request.json()
    if (!email || !password) {
      return NextResponse.json(
        { error: "Email e senha obrigatorios" },
        { status: 400 }
      )
    }

    const db = getDb()
    const user = db
      .prepare("SELECT * FROM users WHERE email = ?")
      .get(email) as {
      id: string
      name: string
      email: string
      password_hash: string
      role: string
    } | undefined

    if (!user || !compareSync(password, user.password_hash)) {
      return NextResponse.json(
        { error: "Email ou senha incorretos" },
        { status: 401 }
      )
    }

    const token = await signToken({
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
    })

    const response = NextResponse.json({
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
      },
    })

    response.cookies.set(getTokenCookieOptions(token))
    return response
  } catch (error) {
    console.error("Login error:", error)
    return NextResponse.json(
      { error: "Erro interno do servidor" },
      { status: 500 }
    )
  }
}
