import { NextResponse } from "next/server"
import { verifyToken, getDeleteCookieOptions } from "@/lib/jwt"

export async function GET() {
  const user = await verifyToken()
  if (!user) {
    return NextResponse.json({ user: null }, { status: 401 })
  }
  return NextResponse.json({ user })
}

export async function DELETE() {
  const response = NextResponse.json({ ok: true })
  response.cookies.set(getDeleteCookieOptions())
  return response
}
