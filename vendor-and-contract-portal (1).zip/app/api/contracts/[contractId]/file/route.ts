import { NextResponse } from "next/server"
import { getDb } from "@/lib/db"
import { readFile } from "node:fs/promises"
import { existsSync } from "node:fs"

export async function GET(
  request: Request,
  { params }: { params: Promise<{ contractId: string }> }
) {
  try {
    const { contractId } = await params
    const db = getDb()

    const contract = db
      .prepare("SELECT * FROM contracts WHERE id = ?")
      .get(contractId) as Record<string, unknown> | undefined

    if (!contract) {
      return NextResponse.json(
        { error: "Contrato nao encontrado" },
        { status: 404 }
      )
    }

    const pdfPath = String(contract.pdf_path || "")

    if (!pdfPath || !existsSync(pdfPath)) {
      return NextResponse.json(
        { error: "Arquivo PDF nao encontrado no servidor" },
        { status: 404 }
      )
    }

    const fileBuffer = await readFile(pdfPath)
    const fileName = String(contract.pdf_file_name || "contrato.pdf")

    // Check if download is requested via query param
    const url = new URL(request.url)
    const download = url.searchParams.get("download") === "true"

    const disposition = download
      ? `attachment; filename="${fileName}"`
      : `inline; filename="${fileName}"`

    return new Response(fileBuffer, {
      status: 200,
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": disposition,
        "Content-Length": String(fileBuffer.length),
        "Cache-Control": "private, max-age=3600",
      },
    })
  } catch (error) {
    console.error("File serve error:", error)
    return NextResponse.json(
      { error: "Erro ao servir arquivo" },
      { status: 500 }
    )
  }
}
