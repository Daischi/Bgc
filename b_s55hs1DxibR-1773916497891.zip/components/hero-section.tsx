"use client"

import { useEffect, useState } from "react"
import { ChevronDown, Play, Instagram, Youtube, Music } from "lucide-react"
import { Button } from "@/components/ui/button"

export function HeroSection() {
  const [isVisible, setIsVisible] = useState(false)
  const [glitchText, setGlitchText] = useState("KPO")

  useEffect(() => {
    setIsVisible(true)
    
    const glitchChars = "!@#$%^&*()_+-=[]{}|;':\",./<>?"
    const originalText = "KPO"
    
    const interval = setInterval(() => {
      const shouldGlitch = Math.random() > 0.7
      if (shouldGlitch) {
        let glitched = ""
        for (let i = 0; i < originalText.length; i++) {
          if (Math.random() > 0.5) {
            glitched += glitchChars[Math.floor(Math.random() * glitchChars.length)]
          } else {
            glitched += originalText[i]
          }
        }
        setGlitchText(glitched)
        setTimeout(() => setGlitchText(originalText), 100)
      }
    }, 2000)

    return () => clearInterval(interval)
  }, [])

  const scrollToAbout = () => {
    document.getElementById("about")?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Video/Image */}
      <div className="absolute inset-0 z-0">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url(https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-17%20at%2010.42.20-Yhsr4w5W2DLIrRQzUjCSDswRGqhY0U.jpeg)`,
          }}
        />
        <div className="absolute inset-0 bg-black/70" />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/50 to-black" />
      </div>

      {/* Animated Scanlines */}
      <div className="absolute inset-0 z-10 pointer-events-none opacity-20">
        <div className="w-full h-full" style={{
          background: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,255,0,0.03) 2px, rgba(0,255,0,0.03) 4px)'
        }} />
      </div>

      {/* Floating particles */}
      <div className="absolute inset-0 z-10 overflow-hidden pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-primary rounded-full animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${2 + Math.random() * 3}s`,
            }}
          />
        ))}
      </div>

      {/* Content */}
      <div className={`relative z-20 text-center px-4 transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
        <div className="mb-4">
          <span className="text-primary font-mono text-sm md:text-base tracking-[0.3em] uppercase animate-pulse">
            Frequency Control
          </span>
        </div>

        <h1 className="text-6xl sm:text-7xl md:text-8xl lg:text-9xl font-black mb-6 relative">
          <span className="font-[var(--font-orbitron)] tracking-wider text-foreground relative inline-block">
            DJ <span className="text-primary relative">
              {glitchText}
              <span className="absolute -inset-1 blur-xl bg-primary/30 -z-10" />
            </span>
          </span>
        </h1>

        <p className="text-xl md:text-2xl text-muted-foreground mb-2 tracking-widest font-light">
          TECHNO / INDUSTRIAL / UNDERGROUND
        </p>

        <div className="flex items-center justify-center gap-2 text-primary mb-8">
          <div className="h-px w-16 bg-gradient-to-r from-transparent to-primary" />
          <Music className="w-5 h-5" />
          <div className="h-px w-16 bg-gradient-to-l from-transparent to-primary" />
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
          <Button 
            size="lg" 
            className="group relative overflow-hidden bg-primary text-primary-foreground hover:bg-primary/90 px-8 py-6 text-lg font-bold tracking-wider"
            onClick={() => document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })}
          >
            <span className="relative z-10 flex items-center gap-2">
              CONTRATAR AGORA
              <Play className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </span>
            <div className="absolute inset-0 bg-gradient-to-r from-primary via-neon-green to-primary bg-[length:200%_100%] animate-shimmer" />
          </Button>

          <Button 
            variant="outline" 
            size="lg"
            className="border-primary/50 text-primary hover:bg-primary/10 px-8 py-6 text-lg tracking-wider"
            onClick={() => document.getElementById("videos")?.scrollIntoView({ behavior: "smooth" })}
          >
            VER PERFORMANCES
          </Button>
        </div>

        {/* Social Links */}
        <div className="flex items-center justify-center gap-6">
          <a 
            href="https://instagram.com/djkpo.official" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-muted-foreground hover:text-primary transition-colors hover:scale-110 transform duration-200"
          >
            <Instagram className="w-6 h-6" />
          </a>
          <a 
            href="https://youtube.com/@djkpo" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-muted-foreground hover:text-primary transition-colors hover:scale-110 transform duration-200"
          >
            <Youtube className="w-6 h-6" />
          </a>
        </div>
      </div>

      {/* Scroll Indicator */}
      <button 
        onClick={scrollToAbout}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20 text-primary animate-bounce cursor-pointer"
        aria-label="Rolar para baixo"
      >
        <ChevronDown className="w-8 h-8" />
      </button>

      {/* Corner Decorations */}
      <div className="absolute top-8 left-8 w-16 h-16 border-l-2 border-t-2 border-primary/50 z-20" />
      <div className="absolute top-8 right-8 w-16 h-16 border-r-2 border-t-2 border-primary/50 z-20" />
      <div className="absolute bottom-8 left-8 w-16 h-16 border-l-2 border-b-2 border-primary/50 z-20" />
      <div className="absolute bottom-8 right-8 w-16 h-16 border-r-2 border-b-2 border-primary/50 z-20" />
    </section>
  )
}
