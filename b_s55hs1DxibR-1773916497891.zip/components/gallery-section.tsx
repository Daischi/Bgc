"use client"

import { useEffect, useRef, useState } from "react"

const galleryImages = [
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-17%20at%2010.42.20-Yhsr4w5W2DLIrRQzUjCSDswRGqhY0U.jpeg",
    alt: "KPO Live Performance",
    title: "Live Performance",
    span: "col-span-2 row-span-2",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-17%20at%2010.36.37-N81QKPyXtORNjPLGdpPEqGpXNDREJE.jpeg",
    alt: "DJ KPO Underground Set",
    title: "Underground Set",
    span: "col-span-1 row-span-1",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-17%20at%2010.32.20-uKcsBQt7p4S16ATQ6xA9qvbxRb01ae.jpeg",
    alt: "DJ KPO Frequency Control",
    title: "Frequency Control",
    span: "col-span-1 row-span-1",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202026-03-17%20at%2010.32.37-5syZ9VHwdB9k7q5RH18ZpvUpzqpDf6.jpeg",
    alt: "DJ KPO Sessions",
    title: "Sessions",
    span: "col-span-2 row-span-1",
  },
]

export function GallerySection() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section 
      id="gallery" 
      ref={sectionRef}
      className="relative py-24 md:py-32 bg-card/30"
    >
      {/* Background Glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-primary/5 rounded-full blur-3xl" />

      <div className="container mx-auto px-4 relative z-10">
        {/* Section Header */}
        <div className={`text-center mb-16 transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <span className="text-primary font-mono text-sm tracking-[0.3em] uppercase">
            Galeria
          </span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-black mt-4">
            <span className="text-foreground">Momentos </span>
            <span className="text-primary">Épicos</span>
          </h2>
          <p className="text-muted-foreground mt-4 max-w-2xl mx-auto">
            Registros das performances mais marcantes e da energia que só o DJ KPO consegue criar
          </p>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 auto-rows-[200px] md:auto-rows-[250px]">
          {galleryImages.map((image, index) => (
            <div 
              key={index}
              className={`relative group overflow-hidden rounded-lg cursor-pointer ${image.span} transition-all duration-700 ${
                isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
              }`}
              style={{ transitionDelay: `${index * 150}ms` }}
            >
              <img 
                src={image.src}
                alt={image.alt}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              
              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent opacity-60 group-hover:opacity-80 transition-opacity duration-300" />
              
              {/* Content */}
              <div className="absolute inset-0 flex items-end p-6">
                <div className="transform translate-y-4 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all duration-300">
                  <h3 className="text-lg font-bold text-foreground">{image.title}</h3>
                  <div className="h-0.5 w-12 bg-primary mt-2" />
                </div>
              </div>

              {/* Border Glow */}
              <div className="absolute inset-0 border border-primary/0 group-hover:border-primary/50 transition-colors duration-300 rounded-lg" />
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
