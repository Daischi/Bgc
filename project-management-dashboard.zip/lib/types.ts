export interface Task {
  id: string
  title: string
  completed: boolean
}

export interface Phase {
  id: string
  title: string
  description: string
  order: number
  tasks: Task[]
  cost: number
}

export interface Project {
  id: string
  name: string
  description: string
  phases: Phase[]
  createdAt: string
}
