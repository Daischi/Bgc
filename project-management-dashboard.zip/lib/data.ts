import { Project } from "./types"

export const mockProjects: Project[] = [
  {
    id: "1",
    name: "Projeto 1",
    description: "Integrated management system to optimize internal processes at BGC Liquidez, including workflow automation, legacy system integration and real-time monitoring dashboard.",
    phases: [
      {
        id: "1-1",
        title: "Planning and Initial Analysis",
        description: "In this initial phase, we focus on fully understanding the project scope, gathering all functional and non-functional requirements from stakeholders. We conduct detailed analyses of the current environment and define the solution architecture.",
        order: 1,
        cost: 15000,
        tasks: [
          { id: "t1-1", title: "Requirements gathering with stakeholders", completed: false },
          { id: "t1-2", title: "Current environment analysis", completed: false },
          { id: "t1-3", title: "Solution architecture definition", completed: false },
        ]
      },
      {
        id: "1-2",
        title: "Development",
        description: "Core development phase where we build the main features of the system.",
        order: 2,
        cost: 45000,
        tasks: [
          { id: "t2-1", title: "Backend API development", completed: false },
          { id: "t2-2", title: "Frontend interface development", completed: false },
          { id: "t2-3", title: "Database schema implementation", completed: false },
          { id: "t2-4", title: "Integration with legacy systems", completed: false },
          { id: "t2-5", title: "Real-time monitoring features", completed: false },
        ]
      },
      {
        id: "1-3",
        title: "Testing",
        description: "Comprehensive testing phase to ensure quality and reliability.",
        order: 3,
        cost: 20000,
        tasks: [
          { id: "t3-1", title: "Unit testing", completed: false },
          { id: "t3-2", title: "Integration testing", completed: false },
          { id: "t3-3", title: "User acceptance testing", completed: false },
          { id: "t3-4", title: "Performance testing", completed: false },
        ]
      },
      {
        id: "1-4",
        title: "Deployment",
        description: "Final deployment and go-live phase.",
        order: 4,
        cost: 10000,
        tasks: [
          { id: "t4-1", title: "Production environment setup", completed: false },
          { id: "t4-2", title: "Data migration", completed: false },
          { id: "t4-3", title: "Go-live execution", completed: false },
          { id: "t4-4", title: "Post-deployment monitoring", completed: false },
          { id: "t4-5", title: "Documentation handover", completed: false },
          { id: "t4-6", title: "Team training", completed: false },
        ]
      },
    ],
    createdAt: "2024-01-15"
  },
  {
    id: "2",
    name: "Projeto 2",
    description: "Customer portal redesign with improved UX and new self-service features.",
    phases: [
      {
        id: "2-1",
        title: "UX Research",
        description: "User research and experience mapping phase.",
        order: 1,
        cost: 12000,
        tasks: [
          { id: "t2-1-1", title: "User interviews", completed: true },
          { id: "t2-1-2", title: "Competitor analysis", completed: true },
          { id: "t2-1-3", title: "Journey mapping", completed: true },
        ]
      },
      {
        id: "2-2",
        title: "Design",
        description: "Visual design and prototyping phase.",
        order: 2,
        cost: 18000,
        tasks: [
          { id: "t2-2-1", title: "Wireframes creation", completed: true },
          { id: "t2-2-2", title: "UI design system", completed: true },
          { id: "t2-2-3", title: "Interactive prototypes", completed: true },
          { id: "t2-2-4", title: "Design review and approval", completed: true },
        ]
      },
      {
        id: "2-3",
        title: "Development",
        description: "Frontend and backend development phase.",
        order: 3,
        cost: 35000,
        tasks: [
          { id: "t2-3-1", title: "Component library development", completed: true },
          { id: "t2-3-2", title: "Page implementations", completed: true },
          { id: "t2-3-3", title: "API integrations", completed: true },
          { id: "t2-3-4", title: "Self-service features", completed: true },
          { id: "t2-3-5", title: "Authentication system", completed: true },
        ]
      },
      {
        id: "2-4",
        title: "Launch",
        description: "Final launch and monitoring phase.",
        order: 4,
        cost: 8000,
        tasks: [
          { id: "t2-4-1", title: "Staging deployment", completed: true },
          { id: "t2-4-2", title: "QA testing", completed: true },
          { id: "t2-4-3", title: "Production deployment", completed: true },
          { id: "t2-4-4", title: "Launch monitoring", completed: false },
          { id: "t2-4-5", title: "User feedback collection", completed: false },
          { id: "t2-4-6", title: "Performance optimization", completed: false },
        ]
      },
    ],
    createdAt: "2024-02-01"
  },
  {
    id: "3",
    name: "Projeto 3",
    description: "Mobile app development for field operations team.",
    phases: [
      {
        id: "3-1",
        title: "Planning",
        description: "Initial planning and requirements phase.",
        order: 1,
        cost: 10000,
        tasks: [
          { id: "t3-1-1", title: "Requirements analysis", completed: true },
          { id: "t3-1-2", title: "Technical specification", completed: true },
          { id: "t3-1-3", title: "Project timeline", completed: true },
        ]
      },
      {
        id: "3-2",
        title: "Design",
        description: "Mobile app design phase.",
        order: 2,
        cost: 15000,
        tasks: [
          { id: "t3-2-1", title: "App wireframes", completed: true },
          { id: "t3-2-2", title: "Visual design", completed: true },
          { id: "t3-2-3", title: "Prototype testing", completed: true },
        ]
      },
      {
        id: "3-3",
        title: "Development",
        description: "Mobile app development phase.",
        order: 3,
        cost: 40000,
        tasks: [
          { id: "t3-3-1", title: "Core app development", completed: true },
          { id: "t3-3-2", title: "Offline functionality", completed: true },
          { id: "t3-3-3", title: "GPS integration", completed: true },
          { id: "t3-3-4", title: "Camera features", completed: true },
          { id: "t3-3-5", title: "Sync mechanism", completed: true },
        ]
      },
      {
        id: "3-4",
        title: "Testing & Launch",
        description: "Testing and app store submission phase.",
        order: 4,
        cost: 12000,
        tasks: [
          { id: "t3-4-1", title: "Beta testing", completed: true },
          { id: "t3-4-2", title: "Bug fixes", completed: true },
          { id: "t3-4-3", title: "App store submission", completed: true },
          { id: "t3-4-4", title: "Launch support", completed: false },
          { id: "t3-4-5", title: "User training", completed: false },
          { id: "t3-4-6", title: "Feedback iteration", completed: false },
        ]
      },
    ],
    createdAt: "2024-03-10"
  }
]

export function getProjectProgress(project: Project): number {
  const totalTasks = project.phases.reduce((acc, phase) => acc + phase.tasks.length, 0)
  const completedTasks = project.phases.reduce(
    (acc, phase) => acc + phase.tasks.filter((t) => t.completed).length,
    0
  )
  if (totalTasks === 0) return 0
  return Math.round((completedTasks / totalTasks) * 100)
}

export function getPhaseProgress(phase: { tasks: { completed: boolean }[] }): number {
  const totalTasks = phase.tasks.length
  const completedTasks = phase.tasks.filter((t) => t.completed).length
  if (totalTasks === 0) return 0
  return Math.round((completedTasks / totalTasks) * 100)
}

export function getTotalTasks(project: Project): number {
  return project.phases.reduce((acc, phase) => acc + phase.tasks.length, 0)
}

export function getCompletedTasks(project: Project): number {
  return project.phases.reduce(
    (acc, phase) => acc + phase.tasks.filter((t) => t.completed).length,
    0
  )
}
