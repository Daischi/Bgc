import Database from "better-sqlite3"
import path from "path"
import fs from "fs"

// Ensure data directory exists
const dataDir = path.join(process.cwd(), "data")
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true })
}

const dbPath = path.join(dataDir, "projects.db")
const db = new Database(dbPath)

// Enable foreign keys
db.pragma("foreign_keys = ON")

// Initialize database schema
db.exec(`
  CREATE TABLE IF NOT EXISTS projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS phases (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    phase_order INTEGER NOT NULL,
    cost REAL DEFAULT 0,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    phase_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    completed INTEGER DEFAULT 0,
    FOREIGN KEY (phase_id) REFERENCES phases(id) ON DELETE CASCADE
  );
`)

// Types
export interface Task {
  id: string
  title: string
  completed: boolean
}

export interface Phase {
  id: string
  title: string
  description: string
  order: number
  tasks: Task[]
  cost: number
}

export interface Project {
  id: string
  name: string
  description: string
  phases: Phase[]
  createdAt: string
}

// Helper function to build project with phases and tasks
function buildProject(projectRow: { id: number; name: string; description: string; created_at: string }): Project {
  const phases = db.prepare(`
    SELECT id, title, description, phase_order as 'order', cost 
    FROM phases 
    WHERE project_id = ? 
    ORDER BY phase_order
  `).all(projectRow.id) as { id: number; title: string; description: string; order: number; cost: number }[]

  const phasesWithTasks: Phase[] = phases.map((phase) => {
    const tasks = db.prepare(`
      SELECT id, title, completed 
      FROM tasks 
      WHERE phase_id = ?
    `).all(phase.id) as { id: number; title: string; completed: number }[]

    return {
      id: phase.id.toString(),
      title: phase.title,
      description: phase.description || "",
      order: phase.order,
      cost: phase.cost,
      tasks: tasks.map((task) => ({
        id: task.id.toString(),
        title: task.title,
        completed: Boolean(task.completed)
      }))
    }
  })

  return {
    id: projectRow.id.toString(),
    name: projectRow.name,
    description: projectRow.description || "",
    phases: phasesWithTasks,
    createdAt: projectRow.created_at.split("T")[0]
  }
}

// Database operations
export const database = {
  getProjects: (): Project[] => {
    const rows = db.prepare("SELECT * FROM projects ORDER BY created_at DESC").all() as { id: number; name: string; description: string; created_at: string }[]
    return rows.map(buildProject)
  },

  getProject: (id: string): Project | null => {
    const row = db.prepare("SELECT * FROM projects WHERE id = ?").get(parseInt(id)) as { id: number; name: string; description: string; created_at: string } | undefined
    if (!row) return null
    return buildProject(row)
  },

  createProject: (data: { name: string; description: string; phases: Omit<Phase, "id">[] }): Project => {
    const insertProject = db.prepare("INSERT INTO projects (name, description) VALUES (?, ?)")
    const result = insertProject.run(data.name, data.description)
    const projectId = result.lastInsertRowid as number

    const insertPhase = db.prepare("INSERT INTO phases (project_id, title, description, phase_order, cost) VALUES (?, ?, ?, ?, ?)")
    const insertTask = db.prepare("INSERT INTO tasks (phase_id, title, completed) VALUES (?, ?, ?)")

    for (const phase of data.phases) {
      const phaseResult = insertPhase.run(projectId, phase.title, phase.description, phase.order, phase.cost)
      const phaseId = phaseResult.lastInsertRowid as number

      for (const task of phase.tasks) {
        insertTask.run(phaseId, task.title, task.completed ? 1 : 0)
      }
    }

    return database.getProject(projectId.toString())!
  },

  updateProject: (id: string, data: { name?: string; description?: string; phases?: Omit<Phase, "id">[] }): Project | null => {
    const projectId = parseInt(id)
    const existing = db.prepare("SELECT id FROM projects WHERE id = ?").get(projectId)
    if (!existing) return null

    // Update project info
    if (data.name !== undefined || data.description !== undefined) {
      const updates: string[] = []
      const values: (string | number)[] = []
      
      if (data.name !== undefined) {
        updates.push("name = ?")
        values.push(data.name)
      }
      if (data.description !== undefined) {
        updates.push("description = ?")
        values.push(data.description)
      }
      
      values.push(projectId)
      db.prepare(`UPDATE projects SET ${updates.join(", ")} WHERE id = ?`).run(...values)
    }

    // Replace phases if provided
    if (data.phases) {
      // Delete existing phases (cascades to tasks)
      db.prepare("DELETE FROM phases WHERE project_id = ?").run(projectId)

      // Insert new phases
      const insertPhase = db.prepare("INSERT INTO phases (project_id, title, description, phase_order, cost) VALUES (?, ?, ?, ?, ?)")
      const insertTask = db.prepare("INSERT INTO tasks (phase_id, title, completed) VALUES (?, ?, ?)")

      for (const phase of data.phases) {
        const phaseResult = insertPhase.run(projectId, phase.title, phase.description, phase.order, phase.cost)
        const phaseId = phaseResult.lastInsertRowid as number

        for (const task of phase.tasks) {
          insertTask.run(phaseId, task.title, task.completed ? 1 : 0)
        }
      }
    }

    return database.getProject(id)
  },

  deleteProject: (id: string): boolean => {
    const result = db.prepare("DELETE FROM projects WHERE id = ?").run(parseInt(id))
    return result.changes > 0
  },

  toggleTask: (projectId: string, phaseId: string, taskId: string): Project | null => {
    // Verify task belongs to the project/phase
    const task = db.prepare(`
      SELECT t.id, t.completed 
      FROM tasks t 
      JOIN phases p ON t.phase_id = p.id 
      WHERE t.id = ? AND p.id = ? AND p.project_id = ?
    `).get(parseInt(taskId), parseInt(phaseId), parseInt(projectId)) as { id: number; completed: number } | undefined

    if (!task) return null

    db.prepare("UPDATE tasks SET completed = ? WHERE id = ?").run(task.completed ? 0 : 1, task.id)
    return database.getProject(projectId)
  },

  // Seed initial data if database is empty
  seedIfEmpty: () => {
    const count = db.prepare("SELECT COUNT(*) as count FROM projects").get() as { count: number }
    if (count.count > 0) return

    const initialProjects = [
      {
        name: "Projeto 1",
        description: "Integrated management system to optimize internal processes at BGC Liquidez, including workflow automation, legacy system integration and real-time monitoring dashboard.",
        phases: [
          {
            title: "Planning and Initial Analysis",
            description: "In this initial phase, we focus on fully understanding the project scope, gathering all functional and non-functional requirements from stakeholders.",
            order: 1,
            cost: 15000,
            tasks: [
              { title: "Requirements gathering with stakeholders", completed: false },
              { title: "Current environment analysis", completed: false },
              { title: "Solution architecture definition", completed: false },
            ]
          },
          {
            title: "Development",
            description: "Core development phase where we build the main features of the system.",
            order: 2,
            cost: 45000,
            tasks: [
              { title: "Backend API development", completed: false },
              { title: "Frontend interface development", completed: false },
              { title: "Database schema implementation", completed: false },
              { title: "Integration with legacy systems", completed: false },
            ]
          },
          {
            title: "Testing",
            description: "Comprehensive testing phase to ensure quality and reliability.",
            order: 3,
            cost: 20000,
            tasks: [
              { title: "Unit testing", completed: false },
              { title: "Integration testing", completed: false },
              { title: "User acceptance testing", completed: false },
            ]
          },
          {
            title: "Deployment",
            description: "Final deployment and go-live phase.",
            order: 4,
            cost: 10000,
            tasks: [
              { title: "Production environment setup", completed: false },
              { title: "Data migration", completed: false },
              { title: "Go-live execution", completed: false },
            ]
          },
        ]
      },
      {
        name: "Projeto 2",
        description: "Customer portal redesign with improved UX and new self-service features.",
        phases: [
          {
            title: "UX Research",
            description: "User research and experience mapping phase.",
            order: 1,
            cost: 12000,
            tasks: [
              { title: "User interviews", completed: true },
              { title: "Competitor analysis", completed: true },
              { title: "Journey mapping", completed: true },
            ]
          },
          {
            title: "Design",
            description: "Visual design and prototyping phase.",
            order: 2,
            cost: 18000,
            tasks: [
              { title: "Wireframes creation", completed: true },
              { title: "UI design system", completed: true },
              { title: "Interactive prototypes", completed: true },
            ]
          },
          {
            title: "Development",
            description: "Frontend and backend development.",
            order: 3,
            cost: 35000,
            tasks: [
              { title: "Component library development", completed: true },
              { title: "Page implementations", completed: true },
              { title: "API integrations", completed: true },
              { title: "Self-service features", completed: true },
            ]
          },
          {
            title: "Launch",
            description: "Final launch and monitoring phase.",
            order: 4,
            cost: 8000,
            tasks: [
              { title: "Staging deployment", completed: true },
              { title: "QA testing", completed: false },
              { title: "Production deployment", completed: false },
            ]
          },
        ]
      },
      {
        name: "Projeto 3",
        description: "Mobile app development for field operations team.",
        phases: [
          {
            title: "Planning",
            description: "Initial planning and requirements phase.",
            order: 1,
            cost: 10000,
            tasks: [
              { title: "Requirements analysis", completed: true },
              { title: "Technical specification", completed: true },
              { title: "Project timeline", completed: true },
            ]
          },
          {
            title: "Design",
            description: "Mobile app design phase.",
            order: 2,
            cost: 15000,
            tasks: [
              { title: "App wireframes", completed: true },
              { title: "Visual design", completed: true },
              { title: "Prototype testing", completed: true },
            ]
          },
          {
            title: "Development",
            description: "Mobile app development phase.",
            order: 3,
            cost: 40000,
            tasks: [
              { title: "Core app development", completed: true },
              { title: "Offline functionality", completed: true },
              { title: "GPS integration", completed: true },
              { title: "Sync mechanism", completed: true },
            ]
          },
          {
            title: "Testing & Launch",
            description: "Testing and app store submission phase.",
            order: 4,
            cost: 12000,
            tasks: [
              { title: "Beta testing", completed: true },
              { title: "Bug fixes", completed: true },
              { title: "App store submission", completed: false },
            ]
          },
        ]
      }
    ]

    for (const project of initialProjects) {
      database.createProject(project as { name: string; description: string; phases: Omit<Phase, "id">[] })
    }
  }
}

// Seed the database with initial data
database.seedIfEmpty()

export default database
