"use client"

import { createContext, useContext, useEffect, useState, type ReactNode } from "react"

type Theme = "light" | "dark"
type Language = "pt" | "en"

interface AppContextType {
  theme: Theme
  setTheme: (theme: Theme) => void
  language: Language
  setLanguage: (language: Language) => void
  t: (key: string) => string
}

const translations: Record<Language, Record<string, string>> = {
  pt: {
    // Dashboard - keep "Dashboard" in both languages
    "dashboard": "Dashboard",
    "projects_overview": "Visao Geral dos Projetos",
    "total_projects": "Total de Projetos",
    "completed": "Concluidos",
    "in_progress": "Em Andamento",
    "average_progress": "Progresso Medio",
    "projects": "Projetos",
    "tasks_completed": "tarefas concluidas",
    "phase_cost": "Custo da Fase",
    "total_cost": "Custo Total",
    
    // Sidebar
    "project_management": "Gestao de Projetos",
    "no_completed_projects": "Nenhum projeto",
    "settings": "Configuracoes",
    
    // Project
    "track_progress": "Acompanhe o progresso das fases do projeto",
    "about_project": "Sobre o Projeto",
    "overall_progress": "Progresso Geral",
    "phases": "Fases",
    "project_phases": "Fases do Projeto",
    "about_this_phase": "Sobre Esta Fase",
    "activities": "Atividades",
    "of": "de",
    
    // Settings
    "appearance": "Aparencia",
    "language": "Idioma",
    "theme": "Tema",
    "light": "Claro",
    "dark": "Escuro",
    "portuguese": "Portugues",
    "english": "Ingles",
    "settings_description": "Personalize a aparencia e idioma do sistema",
    
    // Forms
    "new_project": "Novo Projeto",
    "edit_project": "Editar Projeto",
    "project_name": "Nome do Projeto",
    "description": "Descricao",
    "add_phase": "Adicionar Fase",
    "phase_title": "Titulo da Fase",
    "phase_description": "Descricao da Fase",
    "cost": "Custo (R$)",
    "tasks": "Tarefas",
    "add_task": "Adicionar Tarefa",
    "task_title": "Titulo da Tarefa",
    "save": "Salvar",
    "cancel": "Cancelar",
    "delete": "Excluir",
    "confirm_delete": "Tem certeza que deseja excluir este projeto?",
    "remove_phase": "Remover Fase",
    "remove_task": "Remover Tarefa",
    "create_project": "Criar Projeto",
    "update_project": "Atualizar Projeto",
    "phase": "Fase",
    "project_details": "Informacoes do Projeto",
    "phase_details": "Detalhes da Fase",
  },
  en: {
    // Dashboard - keep "Dashboard" in both languages
    "dashboard": "Dashboard",
    "projects_overview": "Projects Overview",
    "total_projects": "Total Projects",
    "completed": "Completed",
    "in_progress": "In Progress",
    "average_progress": "Average Progress",
    "projects": "Projects",
    "tasks_completed": "tasks completed",
    "phase_cost": "Phase Cost",
    "total_cost": "Total Cost",
    
    // Sidebar
    "project_management": "Project Management",
    "no_completed_projects": "No projects",
    "settings": "Settings",
    
    // Project
    "track_progress": "Track the progress of project phases",
    "about_project": "About Project",
    "overall_progress": "Overall Progress",
    "phases": "Phases",
    "project_phases": "Project Phases",
    "about_this_phase": "About This Phase",
    "activities": "Activities",
    "of": "of",
    
    // Settings
    "appearance": "Appearance",
    "language": "Language",
    "theme": "Theme",
    "light": "Light",
    "dark": "Dark",
    "portuguese": "Portuguese",
    "english": "English",
    "settings_description": "Customize the appearance and language",
    
    // Forms
    "new_project": "New Project",
    "edit_project": "Edit Project",
    "project_name": "Project Name",
    "description": "Description",
    "add_phase": "Add Phase",
    "phase_title": "Phase Title",
    "phase_description": "Phase Description",
    "cost": "Cost ($)",
    "tasks": "Tasks",
    "add_task": "Add Task",
    "task_title": "Task Title",
    "save": "Save",
    "cancel": "Cancel",
    "delete": "Delete",
    "confirm_delete": "Are you sure you want to delete this project?",
    "remove_phase": "Remove Phase",
    "remove_task": "Remove Task",
    "create_project": "Create Project",
    "update_project": "Update Project",
    "phase": "Phase",
    "project_details": "Project Details",
    "phase_details": "Phase Details",
  }
}

const AppContext = createContext<AppContextType | undefined>(undefined)

export function AppProvider({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<Theme>("light")
  const [language, setLanguageState] = useState<Language>("en")
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    const savedTheme = localStorage.getItem("theme") as Theme
    const savedLanguage = localStorage.getItem("language") as Language
    
    if (savedTheme) {
      setThemeState(savedTheme)
      document.documentElement.classList.toggle("dark", savedTheme === "dark")
    }
    if (savedLanguage) {
      setLanguageState(savedLanguage)
    }
  }, [])

  const setTheme = (newTheme: Theme) => {
    setThemeState(newTheme)
    localStorage.setItem("theme", newTheme)
    document.documentElement.classList.toggle("dark", newTheme === "dark")
  }

  const setLanguage = (newLanguage: Language) => {
    setLanguageState(newLanguage)
    localStorage.setItem("language", newLanguage)
  }

  const t = (key: string): string => {
    return translations[language][key] || key
  }

  return (
    <AppContext.Provider value={{ theme, setTheme, language, setLanguage, t }}>
      <div style={{ visibility: mounted ? "visible" : "hidden" }}>
        {children}
      </div>
    </AppContext.Provider>
  )
}

export function useApp() {
  const context = useContext(AppContext)
  if (!context) {
    throw new Error("useApp must be used within AppProvider")
  }
  return context
}
