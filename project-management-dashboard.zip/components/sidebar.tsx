"use client"

import { LayoutDashboard, CheckCircle, Settings, FolderOpen, Plus } from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Project } from "@/lib/types"
import { useApp } from "./providers"

interface SidebarProps {
  projects: Project[]
  onNewProject?: () => void
  onOpenSettings?: () => void
}

function getProjectProgress(project: Project): number {
  const totalTasks = project.phases.reduce((acc, phase) => acc + phase.tasks.length, 0)
  const completedTasks = project.phases.reduce(
    (acc, phase) => acc + phase.tasks.filter((t) => t.completed).length,
    0
  )
  if (totalTasks === 0) return 0
  return Math.round((completedTasks / totalTasks) * 100)
}

function CircularProgress({ progress, size = 32 }: { progress: number; size?: number }) {
  const radius = (size - 4) / 2
  const circumference = 2 * Math.PI * radius
  const strokeDashoffset = circumference - (progress / 100) * circumference

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="rotate-[-90deg]">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          className="text-neutral-700"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="#dc2626"
          strokeWidth="2"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
        />
      </svg>
      <span className="absolute inset-0 flex items-center justify-center text-[9px] font-semibold text-white">
        {progress}%
      </span>
    </div>
  )
}

export function Sidebar({ projects, onNewProject, onOpenSettings }: SidebarProps) {
  const pathname = usePathname()
  const { t } = useApp()
  const inProgressProjects = projects.filter((p) => getProjectProgress(p) < 100)
  const completedProjects = projects.filter((p) => getProjectProgress(p) === 100)

  return (
    <aside className="fixed left-0 top-0 h-screen w-72 bg-gradient-to-b from-neutral-900 via-neutral-900 to-neutral-800 text-white flex flex-col z-50">
      {/* Header */}
      <div className="p-6 border-b border-neutral-700/50">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 bg-gradient-to-br from-red-500 to-red-600 rounded-xl flex items-center justify-center font-bold text-lg shadow-lg shadow-red-500/20">
            B
          </div>
          <div>
            <h1 className="font-semibold text-white text-lg">BGC Liquidez</h1>
            <p className="text-xs text-neutral-400">{t("project_management")}</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto p-4">
        {/* Dashboard */}
        <Link
          href="/"
          className={cn(
            "flex items-center gap-3 px-4 py-3.5 rounded-xl mb-3 transition-all duration-200",
            pathname === "/" 
              ? "bg-gradient-to-r from-red-600 to-red-500 text-white shadow-lg shadow-red-500/30" 
              : "text-neutral-300 hover:bg-neutral-800/70 hover:text-white"
          )}
        >
          <LayoutDashboard size={20} />
          <span className="font-medium">Dashboard</span>
        </Link>

        {/* In Progress Section */}
        <div className="mt-8 mb-3">
          <div className="flex items-center justify-between px-2">
            <div className="flex items-center gap-2 text-xs text-neutral-500 uppercase tracking-wider font-semibold">
              <FolderOpen size={14} />
              <span>{t("in_progress")}</span>
            </div>
            <button
              onClick={onNewProject}
              className="p-1.5 rounded-lg hover:bg-neutral-700/50 transition-all duration-200 text-neutral-400 hover:text-white group"
              title={t("new_project")}
            >
              <Plus size={16} className="group-hover:scale-110 transition-transform" />
            </button>
          </div>
        </div>

        <div className="space-y-1">
          {inProgressProjects.map((project) => {
            const progress = getProjectProgress(project)
            const isActive = pathname === `/project/${project.id}`
            return (
              <Link
                key={project.id}
                href={`/project/${project.id}`}
                className={cn(
                  "flex items-center justify-between px-4 py-3 rounded-xl transition-all duration-200",
                  isActive 
                    ? "bg-red-500/15 text-white border border-red-500/30" 
                    : "text-neutral-300 hover:bg-neutral-800/50 hover:text-white"
                )}
              >
                <div className="flex items-center gap-3">
                  <div className={cn(
                    "w-2 h-2 rounded-full",
                    isActive ? "bg-red-500" : "bg-red-500/70"
                  )} />
                  <span className="font-medium truncate max-w-[140px]">{project.name}</span>
                </div>
                <CircularProgress progress={progress} />
              </Link>
            )
          })}

          {inProgressProjects.length === 0 && (
            <p className="px-4 py-3 text-sm text-neutral-500 italic">{t("no_completed_projects")}</p>
          )}
        </div>

        {/* Completed Section */}
        <div className="mt-8 mb-3">
          <div className="flex items-center gap-2 px-2 text-xs text-neutral-500 uppercase tracking-wider font-semibold">
            <CheckCircle size={14} />
            <span>{t("completed")}</span>
          </div>
        </div>

        <div className="space-y-1">
          {completedProjects.length === 0 && (
            <p className="px-4 py-3 text-sm text-neutral-500 italic">{t("no_completed_projects")}</p>
          )}

          {completedProjects.map((project) => (
            <Link
              key={project.id}
              href={`/project/${project.id}`}
              className={cn(
                "flex items-center justify-between px-4 py-3 rounded-xl transition-all duration-200",
                pathname === `/project/${project.id}`
                  ? "bg-green-500/15 text-white border border-green-500/30"
                  : "text-neutral-300 hover:bg-neutral-800/50 hover:text-white"
              )}
            >
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 bg-green-500 rounded-full" />
                <span className="font-medium truncate max-w-[140px]">{project.name}</span>
              </div>
              <span className="text-xs text-green-400 font-semibold">100%</span>
            </Link>
          ))}
        </div>
      </nav>

      {/* Settings */}
      <div className="p-4 border-t border-neutral-700/50">
        <button
          onClick={onOpenSettings}
          className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl text-neutral-300 hover:bg-neutral-800/70 hover:text-white transition-all duration-200"
        >
          <div className="w-9 h-9 bg-neutral-700/80 rounded-xl flex items-center justify-center">
            <Settings size={18} />
          </div>
          <span className="font-medium">{t("settings")}</span>
        </button>
      </div>
    </aside>
  )
}
