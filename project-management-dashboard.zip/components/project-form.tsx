"use client"

import { useState, useEffect } from "react"
import { X, Plus, Trash2, FolderPlus, DollarSign } from "lucide-react"
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useApp } from "./providers"
import { Project, Phase } from "@/lib/types"

interface ProjectFormProps {
  project?: Project | null
  open: boolean
  onClose: () => void
  onSave: (project: Omit<Project, "id" | "createdAt">) => Promise<void>
  onDelete?: () => Promise<void>
}

export function ProjectForm({ project, open, onClose, onSave, onDelete }: ProjectFormProps) {
  const { t } = useApp()
  const [loading, setLoading] = useState(false)
  const [name, setName] = useState("")
  const [description, setDescription] = useState("")
  const [phases, setPhases] = useState<Phase[]>([])

  useEffect(() => {
    if (open) {
      setName(project?.name || "")
      setDescription(project?.description || "")
      setPhases(
        project?.phases || [
          {
            id: `phase-${Date.now()}`,
            title: "",
            description: "",
            order: 1,
            cost: 0,
            tasks: [{ id: `task-${Date.now()}`, title: "", completed: false }]
          }
        ]
      )
    }
  }, [open, project])

  const handleAddPhase = () => {
    setPhases([
      ...phases,
      {
        id: `phase-${Date.now()}`,
        title: "",
        description: "",
        order: phases.length + 1,
        cost: 0,
        tasks: [{ id: `task-${Date.now()}`, title: "", completed: false }]
      }
    ])
  }

  const handleRemovePhase = (phaseId: string) => {
    if (phases.length <= 1) return
    const newPhases = phases.filter(p => p.id !== phaseId)
    setPhases(newPhases.map((p, i) => ({ ...p, order: i + 1 })))
  }

  const handlePhaseChange = (phaseId: string, field: keyof Phase, value: string | number) => {
    setPhases(phases.map(p => 
      p.id === phaseId ? { ...p, [field]: value } : p
    ))
  }

  const handleAddTask = (phaseId: string) => {
    setPhases(phases.map(p => 
      p.id === phaseId 
        ? { ...p, tasks: [...p.tasks, { id: `task-${Date.now()}`, title: "", completed: false }] }
        : p
    ))
  }

  const handleRemoveTask = (phaseId: string, taskId: string) => {
    setPhases(phases.map(p => {
      if (p.id !== phaseId) return p
      if (p.tasks.length <= 1) return p
      return { ...p, tasks: p.tasks.filter(t => t.id !== taskId) }
    }))
  }

  const handleTaskChange = (phaseId: string, taskId: string, value: string) => {
    setPhases(phases.map(p => 
      p.id === phaseId 
        ? { ...p, tasks: p.tasks.map(t => t.id === taskId ? { ...t, title: value } : t) }
        : p
    ))
  }

  const handleSubmit = async () => {
    if (!name.trim()) return
    
    setLoading(true)
    try {
      await onSave({
        name,
        description,
        phases: phases.map(p => ({
          ...p,
          tasks: p.tasks.filter(t => t.title.trim())
        })).filter(p => p.title.trim())
      })
      onClose()
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = async () => {
    if (!onDelete) return
    if (!confirm(t("confirm_delete"))) return
    
    setLoading(true)
    try {
      await onDelete()
      onClose()
    } finally {
      setLoading(false)
    }
  }

  const totalCost = phases.reduce((acc, p) => acc + (p.cost || 0), 0)

  return (
    <Sheet open={open} onOpenChange={onClose}>
      <SheetContent className="w-full sm:w-[540px] bg-gradient-to-b from-white to-neutral-50 dark:from-neutral-900 dark:to-neutral-950 border-neutral-200 dark:border-neutral-800 p-0 overflow-hidden">
        <div className="h-full flex flex-col">
          {/* Header */}
          <div className="p-8 pb-6 border-b border-neutral-200 dark:border-neutral-800">
            <SheetHeader>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-red-600 rounded-2xl flex items-center justify-center shadow-lg shadow-red-500/20">
                  <FolderPlus className="w-6 h-6 text-white" />
                </div>
                <div>
                  <SheetTitle className="text-xl font-bold text-neutral-900 dark:text-white">
                    {project ? t("edit_project") : t("new_project")}
                  </SheetTitle>
                  <SheetDescription className="text-neutral-500 dark:text-neutral-400 mt-1">
                    {t("project_details")}
                  </SheetDescription>
                </div>
              </div>
            </SheetHeader>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto p-8 space-y-8">
            {/* Project Info */}
            <div className="bg-white dark:bg-neutral-800/50 rounded-2xl p-6 border border-neutral-200 dark:border-neutral-700/50 shadow-sm space-y-5">
              <div>
                <label className="block text-sm font-semibold text-neutral-700 dark:text-neutral-300 mb-2.5">
                  {t("project_name")}
                </label>
                <Input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder={t("project_name")}
                  className="h-12 bg-neutral-50 dark:bg-neutral-900 border-neutral-200 dark:border-neutral-700 rounded-xl text-base"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-neutral-700 dark:text-neutral-300 mb-2.5">
                  {t("description")}
                </label>
                <Textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder={t("description")}
                  rows={3}
                  className="bg-neutral-50 dark:bg-neutral-900 border-neutral-200 dark:border-neutral-700 rounded-xl resize-none"
                />
              </div>
            </div>

            {/* Phases */}
            <div>
              <div className="flex items-center justify-between mb-5">
                <div className="flex items-center gap-3">
                  <h3 className="font-semibold text-neutral-900 dark:text-white text-lg">{t("phases")}</h3>
                  <span className="px-2.5 py-1 bg-neutral-100 dark:bg-neutral-800 rounded-lg text-xs font-semibold text-neutral-500 dark:text-neutral-400">
                    {phases.length}
                  </span>
                </div>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={handleAddPhase}
                  className="gap-2 bg-transparent rounded-xl h-10 px-4 border-neutral-200 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800"
                >
                  <Plus className="w-4 h-4" />
                  {t("add_phase")}
                </Button>
              </div>

              <div className="space-y-5">
                {phases.map((phase, phaseIndex) => (
                  <div 
                    key={phase.id} 
                    className="bg-white dark:bg-neutral-800/50 border border-neutral-200 dark:border-neutral-700/50 rounded-2xl p-6 shadow-sm"
                  >
                    <div className="flex items-center justify-between mb-5">
                      <div className="flex items-center gap-3">
                        <span className="w-8 h-8 bg-red-100 dark:bg-red-900/30 rounded-lg flex items-center justify-center text-sm font-bold text-red-600">
                          {phaseIndex + 1}
                        </span>
                        <span className="font-semibold text-neutral-700 dark:text-neutral-300">
                          {t("phase")} {phaseIndex + 1}
                        </span>
                      </div>
                      {phases.length > 1 && (
                        <button
                          type="button"
                          onClick={() => handleRemovePhase(phase.id)}
                          className="p-2 text-neutral-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-all"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>

                    <div className="space-y-4">
                      <Input
                        value={phase.title}
                        onChange={(e) => handlePhaseChange(phase.id, "title", e.target.value)}
                        placeholder={t("phase_title")}
                        className="h-11 bg-neutral-50 dark:bg-neutral-900 border-neutral-200 dark:border-neutral-700 rounded-xl"
                      />
                      <Textarea
                        value={phase.description}
                        onChange={(e) => handlePhaseChange(phase.id, "description", e.target.value)}
                        placeholder={t("phase_description")}
                        rows={2}
                        className="bg-neutral-50 dark:bg-neutral-900 border-neutral-200 dark:border-neutral-700 rounded-xl resize-none"
                      />
                      <div className="relative">
                        <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
                        <Input
                          type="number"
                          value={phase.cost || ""}
                          onChange={(e) => handlePhaseChange(phase.id, "cost", Number(e.target.value))}
                          placeholder={t("cost")}
                          className="h-11 pl-9 bg-neutral-50 dark:bg-neutral-900 border-neutral-200 dark:border-neutral-700 rounded-xl"
                        />
                      </div>

                      {/* Tasks */}
                      <div className="mt-5 pt-5 border-t border-neutral-200 dark:border-neutral-700">
                        <div className="flex items-center justify-between mb-4">
                          <span className="text-sm font-semibold text-neutral-600 dark:text-neutral-400 uppercase tracking-wide">
                            {t("tasks")}
                          </span>
                          <button
                            type="button"
                            onClick={() => handleAddTask(phase.id)}
                            className="text-sm text-red-500 hover:text-red-600 flex items-center gap-1.5 font-medium"
                          >
                            <Plus className="w-4 h-4" />
                            {t("add_task")}
                          </button>
                        </div>
                        <div className="space-y-3">
                          {phase.tasks.map((task) => (
                            <div key={task.id} className="flex items-center gap-3">
                              <Input
                                value={task.title}
                                onChange={(e) => handleTaskChange(phase.id, task.id, e.target.value)}
                                placeholder={t("task_title")}
                                className="flex-1 h-10 bg-neutral-50 dark:bg-neutral-900 border-neutral-200 dark:border-neutral-700 rounded-xl text-sm"
                              />
                              {phase.tasks.length > 1 && (
                                <button
                                  type="button"
                                  onClick={() => handleRemoveTask(phase.id, task.id)}
                                  className="p-2 text-neutral-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-all"
                                >
                                  <X className="w-4 h-4" />
                                </button>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Total Cost */}
            {totalCost > 0 && (
              <div className="bg-gradient-to-r from-red-500 to-red-600 rounded-2xl p-5 shadow-lg shadow-red-500/20">
                <div className="flex items-center justify-between text-white">
                  <span className="font-medium opacity-90">{t("total_cost")}</span>
                  <span className="text-2xl font-bold">
                    R$ {totalCost.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="p-8 pt-6 border-t border-neutral-200 dark:border-neutral-800 bg-white/80 dark:bg-neutral-900/80 backdrop-blur-sm">
            <div className="flex items-center gap-4">
              {project && onDelete && (
                <Button
                  type="button"
                  variant="destructive"
                  onClick={handleDelete}
                  disabled={loading}
                  className="rounded-xl h-12 px-5"
                >
                  {t("delete")}
                </Button>
              )}
              <div className="flex-1" />
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                disabled={loading}
                className="rounded-xl h-12 px-6 bg-transparent border-neutral-200 dark:border-neutral-700"
              >
                {t("cancel")}
              </Button>
              <Button
                type="button"
                onClick={handleSubmit}
                disabled={loading || !name.trim()}
                className="bg-gradient-to-r from-red-600 to-red-500 hover:from-red-700 hover:to-red-600 text-white rounded-xl h-12 px-6 shadow-lg shadow-red-500/20"
              >
                {project ? t("update_project") : t("create_project")}
              </Button>
            </div>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  )
}
