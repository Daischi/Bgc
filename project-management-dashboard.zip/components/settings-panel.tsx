"use client"

import { Settings, Sun, Moon, Globe, X } from "lucide-react"
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet"
import { useApp } from "./providers"
import { cn } from "@/lib/utils"

interface SettingsPanelProps {
  open?: boolean
  onOpenChange?: (open: boolean) => void
  triggerButton?: boolean
}

export function SettingsPanel({ open, onOpenChange, triggerButton = true }: SettingsPanelProps) {
  const { theme, setTheme, language, setLanguage, t } = useApp()

  const content = (
    <SheetContent className="w-full sm:w-[420px] bg-gradient-to-b from-white to-neutral-50 dark:from-neutral-900 dark:to-neutral-950 border-neutral-200 dark:border-neutral-800 p-0 overflow-hidden">
      <div className="p-8">
        <SheetHeader className="mb-8">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-red-600 rounded-2xl flex items-center justify-center shadow-lg shadow-red-500/20">
              <Settings className="w-6 h-6 text-white" />
            </div>
            <div>
              <SheetTitle className="text-xl font-bold text-neutral-900 dark:text-white">
                {t("settings")}
              </SheetTitle>
              <SheetDescription className="text-neutral-500 dark:text-neutral-400 mt-1">
                {t("settings_description")}
              </SheetDescription>
            </div>
          </div>
        </SheetHeader>
        
        <div className="space-y-8">
          {/* Theme */}
          <div className="bg-white dark:bg-neutral-800/50 rounded-2xl p-6 border border-neutral-200 dark:border-neutral-700/50 shadow-sm">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 bg-amber-100 dark:bg-amber-900/30 rounded-xl flex items-center justify-center">
                <Sun className="w-5 h-5 text-amber-600 dark:text-amber-400" />
              </div>
              <div>
                <h3 className="font-semibold text-neutral-900 dark:text-white">
                  {t("theme")}
                </h3>
                <p className="text-sm text-neutral-500 dark:text-neutral-400">{t("appearance")}</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={() => setTheme("light")}
                className={cn(
                  "flex flex-col items-center gap-3 p-5 rounded-xl border-2 transition-all duration-200",
                  theme === "light"
                    ? "border-red-500 bg-red-50 dark:bg-red-900/20 shadow-lg shadow-red-500/10"
                    : "border-neutral-200 dark:border-neutral-700 hover:border-neutral-300 dark:hover:border-neutral-600 hover:bg-neutral-50 dark:hover:bg-neutral-800"
                )}
              >
                <div className={cn(
                  "w-12 h-12 rounded-xl flex items-center justify-center",
                  theme === "light" ? "bg-red-100 dark:bg-red-900/30" : "bg-neutral-100 dark:bg-neutral-700"
                )}>
                  <Sun className={cn(
                    "w-6 h-6",
                    theme === "light" ? "text-red-600" : "text-neutral-500 dark:text-neutral-400"
                  )} />
                </div>
                <span className={cn(
                  "font-semibold",
                  theme === "light" ? "text-red-600" : "text-neutral-600 dark:text-neutral-300"
                )}>{t("light")}</span>
              </button>
              <button
                onClick={() => setTheme("dark")}
                className={cn(
                  "flex flex-col items-center gap-3 p-5 rounded-xl border-2 transition-all duration-200",
                  theme === "dark"
                    ? "border-red-500 bg-red-50 dark:bg-red-900/20 shadow-lg shadow-red-500/10"
                    : "border-neutral-200 dark:border-neutral-700 hover:border-neutral-300 dark:hover:border-neutral-600 hover:bg-neutral-50 dark:hover:bg-neutral-800"
                )}
              >
                <div className={cn(
                  "w-12 h-12 rounded-xl flex items-center justify-center",
                  theme === "dark" ? "bg-red-100 dark:bg-red-900/30" : "bg-neutral-100 dark:bg-neutral-700"
                )}>
                  <Moon className={cn(
                    "w-6 h-6",
                    theme === "dark" ? "text-red-600" : "text-neutral-500 dark:text-neutral-400"
                  )} />
                </div>
                <span className={cn(
                  "font-semibold",
                  theme === "dark" ? "text-red-600" : "text-neutral-600 dark:text-neutral-300"
                )}>{t("dark")}</span>
              </button>
            </div>
          </div>

          {/* Language */}
          <div className="bg-white dark:bg-neutral-800/50 rounded-2xl p-6 border border-neutral-200 dark:border-neutral-700/50 shadow-sm">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/30 rounded-xl flex items-center justify-center">
                <Globe className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <h3 className="font-semibold text-neutral-900 dark:text-white">
                  {t("language")}
                </h3>
                <p className="text-sm text-neutral-500 dark:text-neutral-400">Interface language</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={() => setLanguage("pt")}
                className={cn(
                  "flex flex-col items-center gap-3 p-5 rounded-xl border-2 transition-all duration-200",
                  language === "pt"
                    ? "border-red-500 bg-red-50 dark:bg-red-900/20 shadow-lg shadow-red-500/10"
                    : "border-neutral-200 dark:border-neutral-700 hover:border-neutral-300 dark:hover:border-neutral-600 hover:bg-neutral-50 dark:hover:bg-neutral-800"
                )}
              >
                <span className="text-3xl">BR</span>
                <span className={cn(
                  "font-semibold",
                  language === "pt" ? "text-red-600" : "text-neutral-600 dark:text-neutral-300"
                )}>{t("portuguese")}</span>
              </button>
              <button
                onClick={() => setLanguage("en")}
                className={cn(
                  "flex flex-col items-center gap-3 p-5 rounded-xl border-2 transition-all duration-200",
                  language === "en"
                    ? "border-red-500 bg-red-50 dark:bg-red-900/20 shadow-lg shadow-red-500/10"
                    : "border-neutral-200 dark:border-neutral-700 hover:border-neutral-300 dark:hover:border-neutral-600 hover:bg-neutral-50 dark:hover:bg-neutral-800"
                )}
              >
                <span className="text-3xl">EN</span>
                <span className={cn(
                  "font-semibold",
                  language === "en" ? "text-red-600" : "text-neutral-600 dark:text-neutral-300"
                )}>{t("english")}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </SheetContent>
  )

  if (triggerButton) {
    return (
      <Sheet>
        <button className="p-2.5 rounded-xl hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-all duration-200 group">
          <Settings className="w-6 h-6 text-neutral-500 dark:text-neutral-400 group-hover:text-neutral-700 dark:group-hover:text-neutral-200 transition-colors" />
        </button>
        {content}
      </Sheet>
    )
  }

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      {content}
    </Sheet>
  )
}
