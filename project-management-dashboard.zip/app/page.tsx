"use client"

import { useState } from "react"
import useSWR from "swr"
import { Sidebar } from "@/components/sidebar"
import { CircularProgress } from "@/components/circular-progress"
import { SettingsPanel } from "@/components/settings-panel"
import { ProjectForm } from "@/components/project-form"
import { useApp } from "@/components/providers"
import { Project } from "@/lib/types"
import { FolderOpen, CheckCircle, TrendingUp, Layers, Plus, DollarSign } from "lucide-react"
import Link from "next/link"

const fetcher = (url: string) => fetch(url).then(res => res.json())

function getProjectProgress(project: Project): number {
  const totalTasks = project.phases.reduce((acc, phase) => acc + phase.tasks.length, 0)
  const completedTasks = project.phases.reduce(
    (acc, phase) => acc + phase.tasks.filter((t) => t.completed).length,
    0
  )
  if (totalTasks === 0) return 0
  return Math.round((completedTasks / totalTasks) * 100)
}

function getPhaseProgress(phase: { tasks: { completed: boolean }[] }): number {
  const totalTasks = phase.tasks.length
  const completedTasks = phase.tasks.filter((t) => t.completed).length
  if (totalTasks === 0) return 0
  return Math.round((completedTasks / totalTasks) * 100)
}

function getTotalTasks(project: Project): number {
  return project.phases.reduce((acc, phase) => acc + phase.tasks.length, 0)
}

function getCompletedTasks(project: Project): number {
  return project.phases.reduce(
    (acc, phase) => acc + phase.tasks.filter((t) => t.completed).length,
    0
  )
}

function getProjectTotalCost(project: Project): number {
  return project.phases.reduce((acc, phase) => acc + (phase.cost || 0), 0)
}

export default function DashboardPage() {
  const { t } = useApp()
  const { data: projects = [], mutate } = useSWR<Project[]>("/api/projects", fetcher)
  const [showNewProject, setShowNewProject] = useState(false)
  const [showSettings, setShowSettings] = useState(false)

  const totalProjects = projects.length
  const completedProjects = projects.filter((p) => getProjectProgress(p) === 100).length
  const inProgressProjects = projects.filter((p) => getProjectProgress(p) < 100).length
  const averageProgress = projects.length > 0
    ? Math.round(projects.reduce((acc, p) => acc + getProjectProgress(p), 0) / projects.length)
    : 0

  const handleCreateProject = async (projectData: Omit<Project, "id" | "createdAt">) => {
    await fetch("/api/projects", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(projectData)
    })
    mutate()
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-neutral-100 via-neutral-50 to-neutral-100 dark:from-neutral-950 dark:via-neutral-900 dark:to-neutral-950">
      <Sidebar 
        projects={projects} 
        onNewProject={() => setShowNewProject(true)} 
        onOpenSettings={() => setShowSettings(true)}
      />

      <main className="ml-72 p-10">
        {/* Header */}
        <div className="flex items-center justify-between mb-10">
          <div>
            <h1 className="text-3xl font-bold text-neutral-900 dark:text-white">Dashboard</h1>
            <p className="text-neutral-500 dark:text-neutral-400 mt-1">{t("projects_overview")}</p>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowNewProject(true)}
              className="flex items-center gap-2 px-5 py-3 bg-gradient-to-r from-red-600 to-red-500 hover:from-red-700 hover:to-red-600 text-white rounded-xl transition-all duration-200 shadow-lg shadow-red-500/20 font-medium"
            >
              <Plus className="w-5 h-5" />
              {t("new_project")}
            </button>
            <SettingsPanel />
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-4 gap-5 mb-10">
          <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200 dark:border-neutral-800 p-6 flex items-center gap-5 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-14 h-14 bg-gradient-to-br from-red-100 to-red-50 dark:from-red-900/30 dark:to-red-900/10 rounded-2xl flex items-center justify-center">
              <FolderOpen className="w-7 h-7 text-red-500" />
            </div>
            <div>
              <p className="text-3xl font-bold text-neutral-900 dark:text-white">{totalProjects}</p>
              <p className="text-sm text-neutral-500 dark:text-neutral-400">{t("total_projects")}</p>
            </div>
          </div>

          <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200 dark:border-neutral-800 p-6 flex items-center gap-5 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-14 h-14 bg-gradient-to-br from-green-100 to-green-50 dark:from-green-900/30 dark:to-green-900/10 rounded-2xl flex items-center justify-center">
              <CheckCircle className="w-7 h-7 text-green-500" />
            </div>
            <div>
              <p className="text-3xl font-bold text-neutral-900 dark:text-white">{completedProjects}</p>
              <p className="text-sm text-neutral-500 dark:text-neutral-400">{t("completed")}</p>
            </div>
          </div>

          <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200 dark:border-neutral-800 p-6 flex items-center gap-5 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-14 h-14 bg-gradient-to-br from-blue-100 to-blue-50 dark:from-blue-900/30 dark:to-blue-900/10 rounded-2xl flex items-center justify-center">
              <TrendingUp className="w-7 h-7 text-blue-500" />
            </div>
            <div>
              <p className="text-3xl font-bold text-neutral-900 dark:text-white">{inProgressProjects}</p>
              <p className="text-sm text-neutral-500 dark:text-neutral-400">{t("in_progress")}</p>
            </div>
          </div>

          <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200 dark:border-neutral-800 p-6 flex items-center gap-5 shadow-sm hover:shadow-md transition-shadow">
            <div className="w-14 h-14 bg-gradient-to-br from-amber-100 to-amber-50 dark:from-amber-900/30 dark:to-amber-900/10 rounded-2xl flex items-center justify-center">
              <Layers className="w-7 h-7 text-amber-500" />
            </div>
            <div>
              <p className="text-3xl font-bold text-neutral-900 dark:text-white">{averageProgress}%</p>
              <p className="text-sm text-neutral-500 dark:text-neutral-400">{t("average_progress")}</p>
            </div>
          </div>
        </div>

        {/* Projects List */}
        <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200 dark:border-neutral-800 p-8 shadow-sm">
          <h2 className="text-xl font-bold text-neutral-900 dark:text-white mb-8">{t("projects")}</h2>

          <div className="space-y-5">
            {projects.map((project) => {
              const progress = getProjectProgress(project)
              const totalTasks = getTotalTasks(project)
              const completedTasks = getCompletedTasks(project)
              const totalCost = getProjectTotalCost(project)

              return (
                <Link
                  key={project.id}
                  href={`/project/${project.id}`}
                  className="block border border-neutral-200 dark:border-neutral-700 rounded-2xl p-6 hover:border-red-300 dark:hover:border-red-800 hover:shadow-lg transition-all duration-200 group"
                >
                  <div className="flex items-start justify-between mb-5">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-gradient-to-br from-red-100 to-red-50 dark:from-red-900/30 dark:to-red-900/10 rounded-2xl flex items-center justify-center group-hover:from-red-200 group-hover:to-red-100 dark:group-hover:from-red-900/40 dark:group-hover:to-red-900/20 transition-colors">
                        <FolderOpen className="w-6 h-6 text-red-500" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-lg text-neutral-900 dark:text-white group-hover:text-red-600 dark:group-hover:text-red-400 transition-colors">{project.name}</h3>
                        <p className="text-sm text-neutral-500 dark:text-neutral-400">
                          {completedTasks}/{totalTasks} {t("tasks_completed")}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-6">
                      {totalCost > 0 && (
                        <div className="flex items-center gap-2 px-4 py-2 bg-neutral-100 dark:bg-neutral-800 rounded-xl">
                          <DollarSign className="w-4 h-4 text-green-500" />
                          <span className="text-sm font-semibold text-neutral-700 dark:text-neutral-300">
                            R$ {totalCost.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                          </span>
                        </div>
                      )}
                      <CircularProgress progress={progress} size={56} strokeWidth={4} />
                    </div>
                  </div>

                  <div className="space-y-3">
                    {project.phases.map((phase) => {
                      const phaseProgress = getPhaseProgress(phase)
                      return (
                        <div key={phase.id} className="flex items-center gap-4">
                          <span className="text-sm text-neutral-600 dark:text-neutral-400 w-24 truncate">{phase.title || `${t("phase")} ${phase.order}`}</span>
                          <div className="flex-1 h-2.5 bg-neutral-100 dark:bg-neutral-800 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-gradient-to-r from-red-500 to-red-400 rounded-full transition-all duration-500"
                              style={{ width: `${phaseProgress}%` }}
                            />
                          </div>
                          <span className="text-sm font-medium text-neutral-500 dark:text-neutral-400 w-12 text-right">
                            {phaseProgress}%
                          </span>
                          {(phase.cost || 0) > 0 && (
                            <span className="text-xs text-green-600 dark:text-green-400 w-28 text-right font-medium">
                              R$ {phase.cost?.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                            </span>
                          )}
                        </div>
                      )
                    })}
                  </div>
                </Link>
              )
            })}

            {projects.length === 0 && (
              <div className="text-center py-16">
                <div className="w-20 h-20 bg-neutral-100 dark:bg-neutral-800 rounded-3xl flex items-center justify-center mx-auto mb-6">
                  <FolderOpen className="w-10 h-10 text-neutral-300 dark:text-neutral-600" />
                </div>
                <p className="text-neutral-500 dark:text-neutral-400 mb-6">{t("no_completed_projects")}</p>
                <button
                  onClick={() => setShowNewProject(true)}
                  className="px-6 py-3 bg-gradient-to-r from-red-600 to-red-500 hover:from-red-700 hover:to-red-600 text-white rounded-xl transition-all duration-200 shadow-lg shadow-red-500/20 font-medium"
                >
                  {t("new_project")}
                </button>
              </div>
            )}
          </div>
        </div>
      </main>

      <ProjectForm
        open={showNewProject}
        onClose={() => setShowNewProject(false)}
        onSave={handleCreateProject}
      />

      <SettingsPanel 
        open={showSettings} 
        onOpenChange={setShowSettings} 
        triggerButton={false} 
      />
    </div>
  )
}
