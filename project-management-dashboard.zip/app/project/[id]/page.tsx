"use client"

import { use, useState } from "react"
import useSWR from "swr"
import { useRouter } from "next/navigation"
import { Sidebar } from "@/components/sidebar"
import { CircularProgress } from "@/components/circular-progress"
import { SettingsPanel } from "@/components/settings-panel"
import { ProjectForm } from "@/components/project-form"
import { useApp } from "@/components/providers"
import { Project } from "@/lib/types"
import { Target, Layers, CheckCircle2, Info, Square, CheckSquare, Edit, DollarSign } from "lucide-react"
import { cn } from "@/lib/utils"

const fetcher = (url: string) => fetch(url).then(res => res.json())

function getProjectProgress(project: Project): number {
  const totalTasks = project.phases.reduce((acc, phase) => acc + phase.tasks.length, 0)
  const completedTasks = project.phases.reduce(
    (acc, phase) => acc + phase.tasks.filter((t) => t.completed).length,
    0
  )
  if (totalTasks === 0) return 0
  return Math.round((completedTasks / totalTasks) * 100)
}

function getPhaseProgress(phase: { tasks: { completed: boolean }[] }): number {
  const totalTasks = phase.tasks.length
  const completedTasks = phase.tasks.filter((t) => t.completed).length
  if (totalTasks === 0) return 0
  return Math.round((completedTasks / totalTasks) * 100)
}

function getTotalTasks(project: Project): number {
  return project.phases.reduce((acc, phase) => acc + phase.tasks.length, 0)
}

function getCompletedTasks(project: Project): number {
  return project.phases.reduce(
    (acc, phase) => acc + phase.tasks.filter((t) => t.completed).length,
    0
  )
}

function getProjectTotalCost(project: Project): number {
  return project.phases.reduce((acc, phase) => acc + (phase.cost || 0), 0)
}

export default function ProjectPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const router = useRouter()
  const { t } = useApp()
  const { data: projects = [] } = useSWR<Project[]>("/api/projects", fetcher)
  const { data: project, mutate } = useSWR<Project>(`/api/projects/${id}`, fetcher)
  const [activeTab, setActiveTab] = useState<string>("about")
  const [showEditProject, setShowEditProject] = useState(false)
  const [showSettings, setShowSettings] = useState(false)

  if (!project) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-neutral-100 via-neutral-50 to-neutral-100 dark:from-neutral-950 dark:via-neutral-900 dark:to-neutral-950">
        <Sidebar projects={projects} onOpenSettings={() => setShowSettings(true)} />
        <main className="ml-72 p-10">
          <div className="animate-pulse">
            <div className="h-10 bg-neutral-200 dark:bg-neutral-800 rounded-xl w-56 mb-4" />
            <div className="h-5 bg-neutral-200 dark:bg-neutral-800 rounded-lg w-72" />
          </div>
        </main>
        <SettingsPanel open={showSettings} onOpenChange={setShowSettings} triggerButton={false} />
      </div>
    )
  }

  const progress = getProjectProgress(project)
  const totalTasks = getTotalTasks(project)
  const completedTasks = getCompletedTasks(project)
  const totalPhases = project.phases.length
  const totalCost = getProjectTotalCost(project)

  const tabs = [
    { id: "about", label: t("about_project"), icon: Info },
    ...project.phases.map((phase) => ({
      id: phase.id,
      label: phase.title || `${t("phase")} ${phase.order}`,
      number: phase.order,
    })),
  ]

  const activePhase = project.phases.find((p) => p.id === activeTab)

  const handleToggleTask = async (phaseId: string, taskId: string) => {
    await fetch(`/api/projects/${id}/tasks`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ phaseId, taskId })
    })
    mutate()
  }

  const handleUpdateProject = async (projectData: Omit<Project, "id" | "createdAt">) => {
    await fetch(`/api/projects/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(projectData)
    })
    mutate()
  }

  const handleDeleteProject = async () => {
    await fetch(`/api/projects/${id}`, { method: "DELETE" })
    router.push("/")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-neutral-100 via-neutral-50 to-neutral-100 dark:from-neutral-950 dark:via-neutral-900 dark:to-neutral-950">
      <Sidebar 
        projects={projects} 
        onNewProject={() => {}} 
        onOpenSettings={() => setShowSettings(true)} 
      />

      <main className="ml-72 p-10">
        {/* Header */}
        <div className="flex items-start justify-between mb-10">
          <div>
            <h1 className="text-3xl font-bold text-neutral-900 dark:text-white">{project.name}</h1>
            <p className="text-neutral-500 dark:text-neutral-400 mt-1">{t("track_progress")}</p>
          </div>
          <div className="flex items-center gap-5">
            <div className="text-right">
              <CircularProgress progress={progress} size={80} strokeWidth={5} />
              <p className="text-sm text-neutral-500 dark:text-neutral-400 mt-2">{t("overall_progress")}</p>
            </div>
            <button
              onClick={() => setShowEditProject(true)}
              className="p-3 rounded-xl hover:bg-neutral-200 dark:hover:bg-neutral-800 transition-all duration-200 group"
              title={t("edit_project")}
            >
              <Edit className="w-6 h-6 text-neutral-500 group-hover:text-neutral-700 dark:text-neutral-400 dark:group-hover:text-neutral-200 transition-colors" />
            </button>
            <SettingsPanel />
          </div>
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-3 mb-8 flex-wrap">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id
            const isAbout = tab.id === "about"
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  "flex items-center gap-2.5 px-5 py-3 rounded-xl border-2 transition-all duration-200 font-medium",
                  isActive
                    ? "bg-gradient-to-r from-red-600 to-red-500 text-white border-transparent shadow-lg shadow-red-500/20"
                    : "bg-white dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 border-neutral-200 dark:border-neutral-700 hover:border-neutral-300 dark:hover:border-neutral-600 hover:shadow-md"
                )}
              >
                {isAbout ? (
                  <>
                    <Info size={18} />
                    <span>{tab.label}</span>
                  </>
                ) : (
                  <>
                    <span
                      className={cn(
                        "w-7 h-7 rounded-lg flex items-center justify-center text-sm font-bold",
                        isActive ? "bg-white/20" : "bg-neutral-100 dark:bg-neutral-700"
                      )}
                    >
                      {(tab as { number: number }).number}
                    </span>
                    <span>{tab.label}</span>
                  </>
                )}
              </button>
            )
          })}
        </div>

        {/* About Tab Content */}
        {activeTab === "about" && (
          <>
            {/* About Project Card */}
            <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200 dark:border-neutral-800 p-8 mb-6 shadow-sm">
              <h2 className="text-xl font-bold text-neutral-900 dark:text-white mb-4">{t("about_project")}</h2>
              <p className="text-neutral-600 dark:text-neutral-400 leading-relaxed text-lg">{project.description}</p>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-4 gap-5 mb-6">
              <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200 dark:border-neutral-800 p-6 flex items-center gap-5 shadow-sm hover:shadow-md transition-shadow">
                <div className="w-14 h-14 bg-gradient-to-br from-red-100 to-red-50 dark:from-red-900/30 dark:to-red-900/10 rounded-2xl flex items-center justify-center">
                  <Target className="w-7 h-7 text-red-500" />
                </div>
                <div>
                  <p className="text-3xl font-bold text-neutral-900 dark:text-white">{progress}%</p>
                  <p className="text-sm text-neutral-500 dark:text-neutral-400">{t("overall_progress")}</p>
                </div>
              </div>

              <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200 dark:border-neutral-800 p-6 flex items-center gap-5 shadow-sm hover:shadow-md transition-shadow">
                <div className="w-14 h-14 bg-gradient-to-br from-amber-100 to-amber-50 dark:from-amber-900/30 dark:to-amber-900/10 rounded-2xl flex items-center justify-center">
                  <Layers className="w-7 h-7 text-amber-500" />
                </div>
                <div>
                  <p className="text-3xl font-bold text-neutral-900 dark:text-white">{totalPhases}</p>
                  <p className="text-sm text-neutral-500 dark:text-neutral-400">{t("phases")}</p>
                </div>
              </div>

              <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200 dark:border-neutral-800 p-6 flex items-center gap-5 shadow-sm hover:shadow-md transition-shadow">
                <div className="w-14 h-14 bg-gradient-to-br from-green-100 to-green-50 dark:from-green-900/30 dark:to-green-900/10 rounded-2xl flex items-center justify-center">
                  <CheckCircle2 className="w-7 h-7 text-green-500" />
                </div>
                <div>
                  <p className="text-3xl font-bold text-neutral-900 dark:text-white">
                    {completedTasks}/{totalTasks}
                  </p>
                  <p className="text-sm text-neutral-500 dark:text-neutral-400">{t("tasks_completed")}</p>
                </div>
              </div>

              {totalCost > 0 && (
                <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200 dark:border-neutral-800 p-6 flex items-center gap-5 shadow-sm hover:shadow-md transition-shadow">
                  <div className="w-14 h-14 bg-gradient-to-br from-emerald-100 to-emerald-50 dark:from-emerald-900/30 dark:to-emerald-900/10 rounded-2xl flex items-center justify-center">
                    <DollarSign className="w-7 h-7 text-emerald-500" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-neutral-900 dark:text-white">
                      R$ {totalCost.toLocaleString("pt-BR", { minimumFractionDigits: 0 })}
                    </p>
                    <p className="text-sm text-neutral-500 dark:text-neutral-400">{t("total_cost")}</p>
                  </div>
                </div>
              )}
            </div>

            {/* Project Phases */}
            <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200 dark:border-neutral-800 p-8 shadow-sm">
              <h3 className="text-sm font-semibold text-neutral-500 dark:text-neutral-400 uppercase tracking-wider mb-6">
                {t("project_phases")}
              </h3>
              <div className="space-y-3">
                {project.phases.map((phase) => {
                  const phaseProgress = getPhaseProgress(phase)
                  return (
                    <button
                      key={phase.id}
                      onClick={() => setActiveTab(phase.id)}
                      className="w-full flex items-center justify-between p-4 rounded-xl hover:bg-neutral-50 dark:hover:bg-neutral-800 transition-all duration-200 text-left group"
                    >
                      <div className="flex items-center gap-4">
                        <span className="w-8 h-8 bg-red-100 dark:bg-red-900/30 text-red-600 rounded-lg flex items-center justify-center text-sm font-bold group-hover:bg-red-200 dark:group-hover:bg-red-900/50 transition-colors">
                          {phase.order}
                        </span>
                        <div>
                          <span className="font-semibold text-neutral-800 dark:text-neutral-200 group-hover:text-red-600 dark:group-hover:text-red-400 transition-colors">{phase.title}</span>
                          {(phase.cost || 0) > 0 && (
                            <p className="text-sm text-green-600 dark:text-green-400 font-medium">
                              R$ {phase.cost?.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                            </p>
                          )}
                        </div>
                      </div>
                      <span className="text-sm font-semibold text-neutral-500 dark:text-neutral-400">{phaseProgress}%</span>
                    </button>
                  )
                })}
              </div>
            </div>
          </>
        )}

        {/* Phase Tab Content */}
        {activePhase && (
          <>
            {/* Phase Header Card */}
            <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200 dark:border-neutral-800 p-8 mb-6 shadow-sm">
              <div className="flex items-start justify-between mb-5">
                <div>
                  <h2 className="text-xl font-bold text-neutral-900 dark:text-white mb-2">{activePhase.title}</h2>
                  <p className="text-neutral-500 dark:text-neutral-400">
                    {activePhase.tasks.filter((t) => t.completed).length} {t("of")}{" "}
                    {activePhase.tasks.length} {t("tasks_completed")}
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-3xl font-bold text-neutral-900 dark:text-white">
                    {getPhaseProgress(activePhase)}%
                  </span>
                  {(activePhase.cost || 0) > 0 && (
                    <p className="text-sm text-green-600 dark:text-green-400 font-semibold mt-1">
                      R$ {activePhase.cost?.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
                    </p>
                  )}
                </div>
              </div>
              <div className="h-3 bg-neutral-100 dark:bg-neutral-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-red-500 to-red-400 rounded-full transition-all duration-500"
                  style={{ width: `${getPhaseProgress(activePhase)}%` }}
                />
              </div>
            </div>

            {/* About This Phase */}
            <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200 dark:border-neutral-800 p-8 mb-6 shadow-sm">
              <h3 className="text-sm font-semibold text-neutral-500 dark:text-neutral-400 uppercase tracking-wider mb-4">
                {t("about_this_phase")}
              </h3>
              <p className="text-neutral-600 dark:text-neutral-400 leading-relaxed text-lg">{activePhase.description}</p>
            </div>

            {/* Activities */}
            <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-200 dark:border-neutral-800 p-8 shadow-sm">
              <h3 className="text-sm font-semibold text-neutral-500 dark:text-neutral-400 uppercase tracking-wider mb-6">
                {t("activities")}
              </h3>
              <div className="space-y-3">
                {activePhase.tasks.map((task) => (
                  <button
                    key={task.id}
                    onClick={() => handleToggleTask(activePhase.id, task.id)}
                    className={cn(
                      "w-full flex items-center gap-4 p-4 rounded-xl border-2 transition-all duration-200 text-left group",
                      task.completed
                        ? "bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800"
                        : "bg-white dark:bg-neutral-800 border-neutral-200 dark:border-neutral-700 hover:border-neutral-300 dark:hover:border-neutral-600 hover:shadow-md"
                    )}
                  >
                    {task.completed ? (
                      <CheckSquare className="w-6 h-6 text-green-600" />
                    ) : (
                      <Square className="w-6 h-6 text-neutral-400 group-hover:text-neutral-500 transition-colors" />
                    )}
                    <span
                      className={cn(
                        "font-medium text-base",
                        task.completed ? "text-green-700 dark:text-green-400 line-through" : "text-neutral-800 dark:text-neutral-200"
                      )}
                    >
                      {task.title}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </>
        )}
      </main>

      <ProjectForm
        project={project}
        open={showEditProject}
        onClose={() => setShowEditProject(false)}
        onSave={handleUpdateProject}
        onDelete={handleDeleteProject}
      />

      <SettingsPanel 
        open={showSettings} 
        onOpenChange={setShowSettings} 
        triggerButton={false} 
      />
    </div>
  )
}
