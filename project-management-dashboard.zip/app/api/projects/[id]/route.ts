import { NextResponse } from "next/server"
import database from "@/lib/database"

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  const project = database.getProject(id)
  
  if (!project) {
    return NextResponse.json({ error: "Project not found" }, { status: 404 })
  }
  
  return NextResponse.json(project)
}

export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  
  try {
    const body = await request.json()
    const project = database.updateProject(id, body)
    
    if (!project) {
      return NextResponse.json({ error: "Project not found" }, { status: 404 })
    }
    
    return NextResponse.json(project)
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 })
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  const deleted = database.deleteProject(id)
  
  if (!deleted) {
    return NextResponse.json({ error: "Project not found" }, { status: 404 })
  }
  
  return NextResponse.json({ success: true })
}
