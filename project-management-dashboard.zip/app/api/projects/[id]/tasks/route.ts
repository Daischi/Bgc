import { NextResponse } from "next/server"
import database from "@/lib/database"

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  
  try {
    const { phaseId, taskId } = await request.json()
    const project = database.toggleTask(id, phaseId, taskId)
    
    if (!project) {
      return NextResponse.json({ error: "Project, phase, or task not found" }, { status: 404 })
    }
    
    return NextResponse.json(project)
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 })
  }
}
