import { NextResponse } from "next/server"
import database from "@/lib/database"

export async function GET() {
  const projects = database.getProjects()
  return NextResponse.json(projects)
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const project = database.createProject(body)
    return NextResponse.json(project, { status: 201 })
  } catch {
    return NextResponse.json({ error: "Invalid request body" }, { status: 400 })
  }
}
