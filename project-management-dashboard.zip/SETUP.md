# BGC Liquidez - Guia de Instalacao

## Pre-requisitos

- **Node.js** versao 18 ou superior
- **npm** (vem junto com Node.js)
- **VS Code** (recomendado)

## Passo a Passo para Rodar o Projeto

### 1. Extraia o ZIP

Extraia o arquivo ZIP em uma pasta de sua preferencia, por exemplo:
```
C:\Projetos\bgc-liquidez
```

### 2. Abra o VS Code

Abra o VS Code e va em **File > Open Folder** e selecione a pasta do projeto.

### 3. Abra o Terminal

No VS Code, abra o terminal integrado:
- Windows/Linux: `Ctrl + `` (crase)
- Mac: `Cmd + `` (crase)

Ou va em **View > Terminal**

### 4. Instale as Dependencias

Execute no terminal:
```bash
npm install
```

Aguarde a instalacao terminar. Isso pode levar alguns minutos.

### 5. Instale o better-sqlite3

O projeto usa SQLite para o banco de dados. Execute:
```bash
npm install better-sqlite3
npm install -D @types/better-sqlite3
```

### 6. Inicie o Servidor

Execute:
```bash
npm run dev
```

### 7. Acesse o Sistema

Abra seu navegador e acesse:
```
http://localhost:3000
```

## Estrutura do Projeto

```
/
├── app/                    # Paginas e rotas da aplicacao
│   ├── api/               # API REST (backend)
│   │   └── projects/      # Endpoints de projetos
│   ├── project/[id]/      # Pagina de detalhes do projeto
│   └── page.tsx           # Dashboard principal
├── components/            # Componentes React reutilizaveis
├── lib/                   # Utilitarios e configuracoes
│   ├── database.ts        # Conexao e operacoes SQLite
│   └── types.ts           # Tipos TypeScript
├── data/                  # Pasta do banco de dados (criada automaticamente)
│   └── projects.db        # Arquivo SQLite (criado automaticamente)
└── public/                # Arquivos estaticos
```

## Banco de Dados

O banco de dados SQLite e criado automaticamente na primeira execucao.
- **Localizacao**: `/data/projects.db`
- **Dados iniciais**: 3 projetos de exemplo sao criados automaticamente

### Para resetar o banco de dados:
1. Pare o servidor (Ctrl+C no terminal)
2. Delete a pasta `/data`
3. Inicie o servidor novamente (`npm run dev`)

## APIs Disponiveis

| Metodo | Endpoint | Descricao |
|--------|----------|-----------|
| GET | `/api/projects` | Lista todos os projetos |
| POST | `/api/projects` | Cria um novo projeto |
| GET | `/api/projects/[id]` | Obtem um projeto |
| PUT | `/api/projects/[id]` | Atualiza um projeto |
| DELETE | `/api/projects/[id]` | Deleta um projeto |
| PATCH | `/api/projects/[id]/tasks` | Alterna status de tarefa |

### Exemplo de Teste via cURL

Listar projetos:
```bash
curl http://localhost:3000/api/projects
```

Criar projeto:
```bash
curl -X POST http://localhost:3000/api/projects \
  -H "Content-Type: application/json" \
  -d '{"name":"Novo Projeto","description":"Descricao","phases":[]}'
```

## Solucao de Problemas

### Erro: "Cannot find module 'better-sqlite3'"
Execute:
```bash
npm install better-sqlite3 @types/better-sqlite3
```

### Erro: "EACCES permission denied"
No Linux/Mac, pode ser necessario dar permissao:
```bash
sudo chown -R $USER:$USER .
```

### Erro: "Port 3000 is already in use"
Outra aplicacao esta usando a porta. Pare-a ou use outra porta:
```bash
npm run dev -- -p 3001
```

### Banco de dados corrompido
Delete a pasta `/data` e reinicie o servidor.

## Funcionalidades

- **Dashboard**: Visao geral de todos os projetos
- **Criar Projeto**: Clique no botao "+" na sidebar ou "Novo Projeto"
- **Editar Projeto**: Abra um projeto e clique no icone de lapis
- **Excluir Projeto**: No formulario de edicao, clique em "Excluir Projeto"
- **Marcar Tarefas**: Clique nas tarefas para marcar como concluidas
- **Configuracoes**: Clique na engrenagem para mudar tema e idioma
