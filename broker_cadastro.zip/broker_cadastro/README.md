# Broker Cadastro — Sistema de Automação de Planilha

Sistema offline para automatizar o cadastro de usuários em planilha Excel a partir de mensagens de brokers.  
**100% gratuito. Sem internet. Sem APIs pagas.**

---

## Instalação rápida (Windows)

1. Instale o [Python 3.10+](https://www.python.org/downloads/) (marque "Add to PATH")
2. Dê dois cliques em **`instalar.bat`**
3. Dê dois cliques em **`iniciar.bat`** para abrir o sistema

---

## Como usar

### 1. Selecionar planilha
Na primeira execução, uma janela pedirá para você escolher ou criar sua planilha Excel.

### 2. Configurar referências (primeira vez)
Abra a planilha Excel criada e preencha a aba **"Referências"**:

| Broker | Mesa | | Instituição | Conta |
|--------|------|---|-------------|-------|
| XP     | Mesa A | | BTG       | 1234  |
| BTG    | Mesa B | | Itaú      | 9999  |
| Safra  | Mesa C | | Bradesco  | 5678  |

O sistema lerá essas tabelas automaticamente. **Não deixe nada hardcoded no código.**

### 3. Colar mensagem e cadastrar
1. Copie a mensagem do WhatsApp/Teams/Outlook
2. Cole no campo "Nova Mensagem"
3. Clique em **⚡ Interpretar Mensagem**
4. Revise os campos preenchidos automaticamente
5. Edite se necessário
6. Clique em **💾 Salvar no Excel**

---

## Exemplos de mensagens suportadas

```
# Formatada
Boa tarde, cadastrar usuário João Silva.
Broker: XP
Instituição: BTG
Email: joao@email.com

# Informal
Consegue cadastrar o João Silva da XP? Instituição BTG. UUID 3213812. Email: joao@email.com

# Conversa real
Olá, preciso cadastrar Maria Torres. Ela é da corretora BTG, a instituição é Itaú.
UUID: 9988123. Email: maria@btg.com
```

---

## Campos suportados

| Campo | Obrigatório | Preenchimento |
|-------|-------------|---------------|
| Nome | Sim | Extraído da mensagem |
| Email | Sim | Extraído da mensagem |
| Broker Associado | Sim | Extraído da mensagem |
| Mesa | Não | **Automático** via tabela de referência |
| Instituição | Recomendado | Extraído da mensagem |
| Conta | Não | **Automático** via tabela de referência |
| UUID | Sim | Extraído da mensagem (número inteiro) |

---

## Estrutura do projeto

```
broker_cadastro/
├── main.py                    # Ponto de entrada
├── requirements.txt           # Dependências Python
├── instalar.bat               # Instalação Windows
├── iniciar.bat                # Atalho de execução
│
├── parser/
│   └── message_parser.py      # Parser inteligente offline (regex + fuzzy)
│
├── excel/
│   └── excel_handler.py       # Leitura/escrita da planilha
│
├── validations/
│   └── validator.py           # Validações de campos
│
├── services/
│   └── orchestrator.py        # Orquestra todo o fluxo
│
├── ui/
│   └── app.py                 # Interface gráfica Tkinter
│
└── logs/
    ├── logger.py              # Sistema de logs
    └── files/                 # Arquivos gerados
        ├── app.log            # Log completo
        ├── historico_cadastros.jsonl   # Histórico
        └── erros.jsonl        # Erros exportados
```

---

## Como o parser funciona (sem IA)

O sistema usa uma abordagem em camadas:

1. **Regex para padrões explícitos** — `Email: joao@x.com`, `UUID: 123456`
2. **Palavras-gatilho** — `"cadastrar João Silva"`, `"da XP"`, `"corretora BTG"`
3. **Fuzzy matching (RapidFuzz)** — reconhece `"XP Investimentos"` como `"XP"`, `"Itaú BBA"` como `"Itaú"`
4. **Lookup na planilha** — Broker → Mesa, Instituição → Conta
5. **Score de confiança** — indica quão bem a mensagem foi interpretada

---

## Adicionar novos padrões de mensagem

Edite `parser/message_parser.py`, seção `FIELD_KEYWORDS`:

```python
FIELD_KEYWORDS = {
    "broker": [
        "broker", "corretora", "da", "de",
        "nova_palavra_chave_aqui",   # ← adicione aqui
    ],
    ...
}
```

---

## Melhorias futuras sugeridas

- [ ] **Integração Outlook** — Ler emails diretamente via `win32com`
- [ ] **OCR** — Interpretar prints de tela com Tesseract (offline)
- [ ] **Aprendizado de padrões** — Salvar mensagens bem-sucedidas para treino local
- [ ] **Exportar relatório** — Histórico em PDF/Excel
- [ ] **Interface web** — Migrar para Flask/FastAPI + HTML (acessível pela rede)
- [ ] **Ollama local** — Para mensagens muito complexas (opcional, gratuito)
- [ ] **Múltiplas planilhas** — Separar por período/equipe

---

## Dependências

| Biblioteca | Versão | Uso |
|-----------|--------|-----|
| pandas | ≥2.0 | Leitura/manipulação da planilha |
| openpyxl | ≥3.1 | Escrita no Excel |
| rapidfuzz | ≥3.0 | Fuzzy matching no parser |
| tkinter | (built-in) | Interface gráfica |

**Nenhuma API externa. Nenhum custo. Funciona offline.**
