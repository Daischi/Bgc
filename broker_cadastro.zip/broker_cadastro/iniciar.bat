@echo off
cd /d "%~dp0"
python main.py
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Erro ao iniciar. Verifique se rodou instalar.bat primeiro.
    pause
)
