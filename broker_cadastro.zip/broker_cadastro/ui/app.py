"""
ui/app.py
Interface gráfica principal — Tkinter com visual moderno.
Fluxo: Cola mensagem → Confirmação → Salva no Excel.
"""

import sys
import os
import tkinter as tk
from tkinter import ttk, messagebox, filedialog, scrolledtext
from pathlib import Path

# Garante que os módulos do projeto sejam encontrados
sys.path.insert(0, str(Path(__file__).parent.parent))

from services.orchestrator import CadastroService
from logs.logger import log_success, log_error, load_history


# ─── Paleta de cores ──────────────────────────────────────────────────────────
THEME = {
    "bg":           "#0F1117",   # fundo principal
    "bg2":          "#1A1D27",   # fundo de painel
    "bg3":          "#23263A",   # fundo de campos
    "accent":       "#4F8EF7",   # azul principal
    "accent2":      "#2DD4BF",   # ciano/turquesa
    "success":      "#22C55E",
    "warning":      "#F59E0B",
    "danger":       "#EF4444",
    "text":         "#E8EAF0",
    "text_muted":   "#6B7280",
    "border":       "#2D3148",
}

FONT_MONO = ("Consolas", 10)
FONT_SANS = ("Segoe UI", 10)
FONT_SANS_BOLD = ("Segoe UI", 10, "bold")
FONT_TITLE = ("Segoe UI", 13, "bold")
FONT_SMALL = ("Segoe UI", 8)

FIELDS = [
    ("nome",        "Nome Completo",     False),
    ("email",       "Email",             False),
    ("broker",      "Broker Associado",  False),
    ("mesa",        "Mesa",              True),   # True = auto-preenchido
    ("instituicao", "Instituição",       False),
    ("conta",       "Conta",             True),
    ("uuid",        "UUID",              False),
]


# ─── Widgets helpers ──────────────────────────────────────────────────────────

def styled_label(parent, text, **kw):
    return tk.Label(
        parent, text=text,
        bg=kw.pop("bg", THEME["bg2"]),
        fg=kw.pop("fg", THEME["text"]),
        font=kw.pop("font", FONT_SANS),
        **kw
    )


def styled_entry(parent, textvariable=None, **kw):
    e = tk.Entry(
        parent,
        textvariable=textvariable,
        bg=THEME["bg3"],
        fg=THEME["text"],
        insertbackground=THEME["accent"],
        relief="flat",
        font=FONT_SANS,
        **kw
    )
    e.bind("<FocusIn>",  lambda ev: e.config(highlightthickness=1,
                                              highlightcolor=THEME["accent"],
                                              highlightbackground=THEME["accent"]))
    e.bind("<FocusOut>", lambda ev: e.config(highlightthickness=1,
                                              highlightcolor=THEME["border"],
                                              highlightbackground=THEME["border"]))
    e.config(highlightthickness=1, highlightbackground=THEME["border"])
    return e


def styled_button(parent, text, command, color=None, **kw):
    c = color or THEME["accent"]
    btn = tk.Button(
        parent, text=text, command=command,
        bg=c, fg="white",
        activebackground=THEME["bg3"], activeforeground=THEME["text"],
        relief="flat", font=FONT_SANS_BOLD,
        cursor="hand2", padx=18, pady=8,
        **kw
    )
    btn.bind("<Enter>", lambda e: btn.config(bg=_darken(c)))
    btn.bind("<Leave>", lambda e: btn.config(bg=c))
    return btn


def _darken(hex_color: str) -> str:
    """Escurece uma cor hex em ~20%."""
    hex_color = hex_color.lstrip("#")
    r, g, b = [int(hex_color[i:i+2], 16) for i in (0, 2, 4)]
    r, g, b = max(0, r-40), max(0, g-40), max(0, b-40)
    return f"#{r:02x}{g:02x}{b:02x}"


# ─── Janela principal ─────────────────────────────────────────────────────────

class BrokerCadastroApp(tk.Tk):

    def __init__(self, excel_path: str = None):
        super().__init__()

        self.title("Broker Cadastro — Automação de Planilha")
        self.configure(bg=THEME["bg"])
        self.geometry("900x700")
        self.minsize(820, 580)

        # Serviço
        self._excel_path = excel_path or self._ask_excel_path()
        if not self._excel_path:
            messagebox.showerror("Erro", "Nenhuma planilha selecionada. O programa será encerrado.")
            self.destroy()
            return

        self.service = CadastroService(self._excel_path)
        self._current_data: dict = {}
        self._field_vars: dict[str, tk.StringVar] = {}
        self._auto_fields: set[str] = set()   # campos preenchidos automaticamente

        self._build_ui()
        self._load_service()

    def _ask_excel_path(self) -> str:
        path = filedialog.askopenfilename(
            title="Selecione a planilha Excel",
            filetypes=[("Excel", "*.xlsx *.xls"), ("Todos", "*.*")]
        )
        if not path:
            # Cria uma nova planilha padrão
            path = filedialog.asksaveasfilename(
                title="Criar nova planilha",
                defaultextension=".xlsx",
                filetypes=[("Excel", "*.xlsx")]
            )
        return path

    def _load_service(self):
        try:
            self.service.load()
            self._set_status(
                f"Planilha carregada: {Path(self._excel_path).name} | "
                f"Brokers: {len(self.service.get_known_brokers())} | "
                f"Instituições: {len(self.service.get_known_institutions())}",
                color=THEME["success"]
            )
        except Exception as e:
            self._set_status(f"Erro ao carregar planilha: {e}", color=THEME["danger"])

    # ── UI Builder ────────────────────────────────────────────────────────────

    def _build_ui(self):
        # ── Barra superior
        topbar = tk.Frame(self, bg=THEME["bg2"], height=56)
        topbar.pack(fill="x", side="top")
        topbar.pack_propagate(False)

        tk.Label(
            topbar, text="⬡  Broker Cadastro",
            bg=THEME["bg2"], fg=THEME["accent"],
            font=("Segoe UI", 14, "bold"), padx=20
        ).pack(side="left", pady=10)

        tk.Label(
            topbar, text=f"📂 {Path(self._excel_path).name}",
            bg=THEME["bg2"], fg=THEME["text_muted"],
            font=FONT_SMALL
        ).pack(side="right", padx=20)

        # ── Abas
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("TNotebook", background=THEME["bg"], borderwidth=0)
        style.configure("TNotebook.Tab",
                         background=THEME["bg2"], foreground=THEME["text_muted"],
                         padding=[18, 8], font=FONT_SANS)
        style.map("TNotebook.Tab",
                   background=[("selected", THEME["bg3"])],
                   foreground=[("selected", THEME["accent"])])
        style.configure("TFrame", background=THEME["bg"])

        notebook = ttk.Notebook(self)
        notebook.pack(fill="both", expand=True, padx=0, pady=0)

        # Aba 1: Cadastro
        self._tab_cadastro = tk.Frame(notebook, bg=THEME["bg"])
        notebook.add(self._tab_cadastro, text="  ✉  Nova Mensagem  ")
        self._build_cadastro_tab(self._tab_cadastro)

        # Aba 2: Histórico
        self._tab_hist = tk.Frame(notebook, bg=THEME["bg"])
        notebook.add(self._tab_hist, text="  📋  Histórico  ")
        self._build_historico_tab(self._tab_hist)

        # ── Barra de status
        self._status_var = tk.StringVar(value="Pronto.")
        status_bar = tk.Label(
            self, textvariable=self._status_var,
            bg=THEME["bg2"], fg=THEME["text_muted"],
            font=FONT_SMALL, anchor="w", padx=12, pady=4
        )
        status_bar.pack(fill="x", side="bottom")
        self._status_label = status_bar

    def _build_cadastro_tab(self, parent):
        parent.columnconfigure(0, weight=1)
        parent.columnconfigure(1, weight=1)
        parent.rowconfigure(0, weight=1)

        # ── Painel esquerdo: mensagem
        left = tk.Frame(parent, bg=THEME["bg2"], padx=20, pady=20)
        left.grid(row=0, column=0, sticky="nsew", padx=(12, 6), pady=12)
        left.columnconfigure(0, weight=1)
        left.rowconfigure(1, weight=1)

        tk.Label(
            left, text="📨 Cole a mensagem do broker",
            bg=THEME["bg2"], fg=THEME["accent2"],
            font=FONT_TITLE
        ).grid(row=0, column=0, sticky="w", pady=(0, 8))

        self._msg_text = scrolledtext.ScrolledText(
            left,
            bg=THEME["bg3"], fg=THEME["text"],
            insertbackground=THEME["accent"],
            relief="flat", font=FONT_MONO,
            wrap="word",
            highlightthickness=1, highlightbackground=THEME["border"]
        )
        self._msg_text.grid(row=1, column=0, sticky="nsew")
        self._msg_text.insert("1.0",
            "Exemplo:\n"
            "Consegue cadastrar o João Silva da XP? Instituição BTG. UUID 3213812. Email dele é joao@email.com"
        )
        self._msg_text.bind("<FocusIn>", self._clear_placeholder)

        btn_frame = tk.Frame(left, bg=THEME["bg2"])
        btn_frame.grid(row=2, column=0, sticky="ew", pady=(12, 0))
        btn_frame.columnconfigure(0, weight=1)

        styled_button(
            btn_frame, "⚡  Interpretar Mensagem",
            self._on_parse,
            color=THEME["accent"]
        ).grid(row=0, column=0, sticky="ew")

        styled_button(
            btn_frame, "🗑  Limpar",
            self._on_clear,
            color=THEME["bg3"]
        ).grid(row=0, column=1, padx=(8, 0))

        # ── Painel direito: confirmação
        right = tk.Frame(parent, bg=THEME["bg2"], padx=20, pady=20)
        right.grid(row=0, column=1, sticky="nsew", padx=(6, 12), pady=12)
        right.columnconfigure(1, weight=1)

        tk.Label(
            right, text="✅ Confirmar dados",
            bg=THEME["bg2"], fg=THEME["accent2"],
            font=FONT_TITLE
        ).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 12))

        # Campos de confirmação
        for i, (field, label, is_auto) in enumerate(FIELDS):
            var = tk.StringVar()
            self._field_vars[field] = var

            color = THEME["text_muted"] if is_auto else THEME["text"]
            badge = " 🤖" if is_auto else ""

            tk.Label(
                right, text=label + badge,
                bg=THEME["bg2"], fg=color,
                font=FONT_SANS, width=18, anchor="e"
            ).grid(row=i+1, column=0, sticky="e", pady=4, padx=(0, 8))

            entry = styled_entry(right, textvariable=var)
            entry.grid(row=i+1, column=1, columnspan=2, sticky="ew", pady=4)

            if is_auto:
                self._auto_fields.add(field)

        # Indicador de confiança
        tk.Label(
            right, text="Confiança:",
            bg=THEME["bg2"], fg=THEME["text_muted"],
            font=FONT_SMALL
        ).grid(row=len(FIELDS)+1, column=0, sticky="e", pady=(12, 0))

        self._confidence_var = tk.StringVar(value="—")
        tk.Label(
            right, textvariable=self._confidence_var,
            bg=THEME["bg2"], fg=THEME["accent"],
            font=FONT_SANS_BOLD
        ).grid(row=len(FIELDS)+1, column=1, sticky="w", pady=(12, 0))

        # Avisos
        self._warn_var = tk.StringVar(value="")
        tk.Label(
            right, textvariable=self._warn_var,
            bg=THEME["bg2"], fg=THEME["warning"],
            font=FONT_SMALL, wraplength=300, justify="left"
        ).grid(row=len(FIELDS)+2, column=0, columnspan=3, sticky="w", pady=(4, 0))

        # Botões de ação
        action_frame = tk.Frame(right, bg=THEME["bg2"])
        action_frame.grid(row=len(FIELDS)+3, column=0, columnspan=3,
                           sticky="ew", pady=(16, 0))
        action_frame.columnconfigure(0, weight=1)
        action_frame.columnconfigure(1, weight=1)

        self._btn_save = styled_button(
            action_frame, "💾  Salvar no Excel",
            self._on_save, color=THEME["success"]
        )
        self._btn_save.grid(row=0, column=0, sticky="ew", padx=(0, 6))
        self._btn_save.config(state="disabled")

        styled_button(
            action_frame, "✖  Cancelar",
            self._on_cancel, color=THEME["danger"]
        ).grid(row=0, column=1, sticky="ew", padx=(6, 0))

    def _build_historico_tab(self, parent):
        parent.columnconfigure(0, weight=1)
        parent.rowconfigure(1, weight=1)

        header = tk.Frame(parent, bg=THEME["bg"], pady=12, padx=16)
        header.grid(row=0, column=0, sticky="ew")

        tk.Label(
            header, text="📋 Histórico de Cadastros",
            bg=THEME["bg"], fg=THEME["accent2"], font=FONT_TITLE
        ).pack(side="left")

        styled_button(
            header, "🔄 Atualizar",
            self._refresh_history, color=THEME["bg3"]
        ).pack(side="right")

        # Treeview
        cols = ("timestamp", "nome", "email", "broker", "uuid")
        style = ttk.Style()
        style.configure("History.Treeview",
                         background=THEME["bg2"],
                         fieldbackground=THEME["bg2"],
                         foreground=THEME["text"],
                         rowheight=28,
                         borderwidth=0)
        style.configure("History.Treeview.Heading",
                         background=THEME["bg3"],
                         foreground=THEME["accent"],
                         relief="flat", font=FONT_SANS_BOLD)

        self._tree = ttk.Treeview(
            parent, columns=cols, show="headings", style="History.Treeview"
        )
        col_widths = {"timestamp": 160, "nome": 200, "email": 220, "broker": 120, "uuid": 100}
        col_labels = {"timestamp": "Data/Hora", "nome": "Nome", "email": "Email",
                       "broker": "Broker", "uuid": "UUID"}
        for col in cols:
            self._tree.heading(col, text=col_labels[col])
            self._tree.column(col, width=col_widths[col], minwidth=80)

        self._tree.grid(row=1, column=0, sticky="nsew", padx=12, pady=(0, 12))

        scrollbar = ttk.Scrollbar(parent, orient="vertical", command=self._tree.yview)
        scrollbar.grid(row=1, column=1, sticky="ns", pady=(0, 12))
        self._tree.config(yscrollcommand=scrollbar.set)

        self._refresh_history()

    # ── Handlers ──────────────────────────────────────────────────────────────

    def _clear_placeholder(self, event=None):
        content = self._msg_text.get("1.0", "end-1c")
        if content.startswith("Exemplo:"):
            self._msg_text.delete("1.0", "end")

    def _on_parse(self):
        msg = self._msg_text.get("1.0", "end-1c").strip()
        if not msg or msg.startswith("Exemplo:"):
            messagebox.showwarning("Atenção", "Cole uma mensagem antes de interpretar.")
            return

        self._set_status("Interpretando mensagem...", color=THEME["accent"])
        try:
            data = self.service.process_message(msg)
            self._current_data = data
            self._populate_fields(data)

            conf = data.get("_confidence", 0)
            self._confidence_var.set(f"{conf}%")

            warns = data.get("_warnings", [])
            self._warn_var.set("\n".join(warns) if warns else "")

            self._btn_save.config(state="normal")
            self._set_status(
                f"Mensagem interpretada com {conf}% de confiança. Revise os campos e confirme.",
                color=THEME["success"] if conf >= 60 else THEME["warning"]
            )
        except Exception as e:
            self._set_status(f"Erro ao interpretar: {e}", color=THEME["danger"])
            log_error(str(e))

    def _populate_fields(self, data: dict):
        for field, var in self._field_vars.items():
            value = data.get(field) or ""
            var.set(value)

    def _on_save(self):
        # Coleta valores editados manualmente pelo usuário
        final_data = {}
        for field, var in self._field_vars.items():
            final_data[field] = var.get().strip() or None
        final_data["outros"] = self._current_data.get("outros", {})

        # Confirmação extra
        nome = final_data.get("nome") or "?"
        if not messagebox.askyesno(
            "Confirmar Cadastro",
            f"Salvar '{nome}' na planilha?\n\n"
            f"Email: {final_data.get('email')}\n"
            f"Broker: {final_data.get('broker')}\n"
            f"UUID: {final_data.get('uuid')}"
        ):
            return

        self._set_status("Salvando...", color=THEME["accent"])
        ok, msg, warnings = self.service.save(final_data)

        if ok:
            log_success(final_data)
            self._set_status(msg, color=THEME["success"])
            messagebox.showinfo("Sucesso", msg)
            self._on_cancel()
            self._refresh_history()
        else:
            log_error(msg, final_data)
            self._set_status(f"Erro: {msg}", color=THEME["danger"])
            messagebox.showerror("Erro ao salvar", msg)

    def _on_cancel(self):
        for var in self._field_vars.values():
            var.set("")
        self._confidence_var.set("—")
        self._warn_var.set("")
        self._current_data = {}
        self._btn_save.config(state="disabled")
        self._msg_text.delete("1.0", "end")

    def _on_clear(self):
        self._msg_text.delete("1.0", "end")

    def _refresh_history(self):
        for row in self._tree.get_children():
            self._tree.delete(row)
        entries = load_history()
        for e in reversed(entries[-200:]):   # últimas 200
            d = e.get("data", {})
            ts = e.get("timestamp", "")[:19].replace("T", " ")
            self._tree.insert("", "end", values=(
                ts,
                d.get("nome", ""),
                d.get("email", ""),
                d.get("broker", ""),
                d.get("uuid", ""),
            ))

    def _set_status(self, text: str, color: str = None):
        self._status_var.set(text)
        if color:
            self._status_label.config(fg=color)


# ─── Entry point ──────────────────────────────────────────────────────────────

def run(excel_path: str = None):
    app = BrokerCadastroApp(excel_path=excel_path)
    app.mainloop()


if __name__ == "__main__":
    run()
