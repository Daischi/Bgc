"""
parser/message_parser.py
Parser inteligente offline para mensagens de brokers.
Usa regex, fuzzy matching e dicionários de palavras-chave.
"""

import re
from typing import Optional
from rapidfuzz import fuzz, process


# ─── Dicionários de palavras-chave ────────────────────────────────────────────

# Sinônimos para cada campo — adicione novos padrões aqui
FIELD_KEYWORDS = {
    "nome": [
        "cadastrar", "cadastro", "usuário", "usuario", "user", "nome", "name",
        "cliente", "pessoa", "colaborador"
    ],
    "email": ["email", "e-mail", "mail", "correio"],
    "broker": [
        "broker", "corretora", "da", "de", "assessor", "distribuidor",
        "plataforma"
    ],
    "instituicao": [
        "instituição", "instituicao", "institution", "banco", "custodia",
        "custodiante", "clearing"
    ],
    "uuid": ["uuid", "id", "código", "codigo", "code", "identificador"],
    "conta": ["conta", "account", "número", "numero"],
    "mesa": ["mesa", "desk", "team", "equipe"],
}

# Termos que indicam INÍCIO de um valor de nome próprio após essas palavras
NAME_TRIGGER_WORDS = {
    "cadastrar", "cadastro", "usuário", "usuario", "user", "cliente",
    "pessoa", "colaborador", "nome"
}


# ─── Funções auxiliares ────────────────────────────────────────────────────────

def _clean(text: str) -> str:
    return text.strip().strip(".,;:-")


def _find_email(text: str) -> Optional[str]:
    pattern = r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}"
    match = re.search(pattern, text)
    return match.group(0).lower() if match else None


def _find_uuid(text: str) -> Optional[str]:
    """UUID = número inteiro puro (7+ dígitos, sem letras)."""
    # Procura padrão explícito: uuid NNNNNN
    explicit = re.search(
        r"\b(?:uuid|id|código|codigo|code)\s*[:\-]?\s*(\d{6,})\b",
        text, re.IGNORECASE
    )
    if explicit:
        return explicit.group(1)
    # Fallback: qualquer número isolado de 6+ dígitos
    candidates = re.findall(r"\b(\d{6,})\b", text)
    return candidates[0] if candidates else None


def _find_name(text: str) -> Optional[str]:
    """
    Tenta extrair nome próprio após palavras-gatilho.
    Ex: "cadastrar João Silva" → "João Silva"
    """
    # Padrão: palavra-gatilho seguida de palavras capitalizadas
    # (?:usu[aá]rio\s+)? — permite "cadastrar usuário João Silva" → captura apenas "João Silva"
    pattern = (
        r"\b(?:cadastrar?|cliente|pessoa|colaborador)\s+"
        r"(?:usu[aá]rio\s+)?"
        r"([A-ZÁÉÍÓÚÀÂÊÔÃÕÇ][a-záéíóúàâêôãõç]{1,}(?:\s+[A-ZÁÉÍÓÚÀÂÊÔÃÕÇ][a-záéíóúàâêôãõç]{1,})+)"
    )
    match = re.search(pattern, text, re.IGNORECASE)
    if match:
        candidate = _clean(match.group(1))
        # Remove palavras que não são nomes
        bad_starts = re.compile(r'^(usu[aá]rio|user|cliente|pessoa)\b', re.IGNORECASE)
        candidate = bad_starts.sub('', candidate).strip()
        if candidate:
            return candidate

    # Padrão alternativo: "usuário João Silva" (sem 'cadastrar' antes)
    pattern2 = (
        r"\busu[aá]rio\s+"
        r"([A-ZÁÉÍÓÚÀÂÊÔÃÕÇ][a-záéíóúàâêôãõç]{1,}(?:\s+[A-ZÁÉÍÓÚÀÂÊÔÃÕÇ][a-záéíóúàâêôãõç]{1,})+)"
    )
    match2 = re.search(pattern2, text, re.IGNORECASE)
    if match2:
        return _clean(match2.group(1))

    # Padrão: "Nome: João Silva"
    labeled = re.search(
        r"\b(?:nome|name)\s*[:\-]\s*([A-ZÁÉÍÓÚÀÂÊÔÃÕÇ][^\n,;]+)",
        text, re.IGNORECASE
    )
    if labeled:
        candidate = _clean(labeled.group(1))
        # Remove possíveis campos extras que vieram junto
        candidate = re.split(r"\b(?:email|broker|uuid|conta|mesa|institui)", candidate, flags=re.IGNORECASE)[0]
        return _clean(candidate) or None

    # Último recurso: sequência de 2+ palavras capitalizadas no início
    caps = re.findall(
        r"\b([A-ZÁÉÍÓÚÀÂÊÔÃÕÇ][a-záéíóúàâêôãõç]{2,}(?:\s+[A-ZÁÉÍÓÚÀÂÊÔÃÕÇ][a-záéíóúàâêôãõç]{2,})+)\b",
        text
    )
    return caps[0] if caps else None


def _find_labeled_field(text: str, labels: list[str]) -> Optional[str]:
    """
    Procura padrão 'Label: Valor' ou 'Label Valor' no texto.
    Para antes de ponto+espaço, vírgula, ponto-e-vírgula, nova linha.
    """
    for label in labels:
        # Com separador explícito — para antes de . seguido de espaço ou fim de linha
        pattern = rf"\b{re.escape(label)}\s*[:\-]\s*([^\n,;]+?)(?=\s*[,;]|\s*\.\s+|\s*\.\s*$|\s*$)"
        match = re.search(pattern, text, re.IGNORECASE | re.MULTILINE)
        if match:
            val = _clean(match.group(1))
            if val:
                return val
    return None


def _fuzzy_match_known_values(raw: str, known_values: list[str],
                               threshold: int = 75) -> Optional[str]:
    """
    Dado um texto bruto, tenta encontrar o valor mais próximo
    dentro de uma lista de valores conhecidos (ex: brokers da planilha).
    """
    if not known_values or not raw:
        return None
    result = process.extractOne(raw, known_values, scorer=fuzz.token_sort_ratio)
    if result and result[1] >= threshold:
        return result[0]
    return None


def _find_broker_inline(text: str, known_brokers: list[str]) -> Optional[str]:
    """
    Detecta o broker mesmo sem label explícito.
    Ex: "da XP", "corretora BTG", "XP Investimentos"
    """
    # Com label
    labeled = _find_labeled_field(text, FIELD_KEYWORDS["broker"])
    if labeled:
        match = _fuzzy_match_known_values(labeled, known_brokers)
        return match or _clean(labeled)

    # Sem label: varre cada palavra/bigrama procurando broker conhecido
    words = text.split()
    for i, word in enumerate(words):
        candidate = _clean(word)
        match = _fuzzy_match_known_values(candidate, known_brokers)
        if match:
            return match
        # Bigrama
        if i < len(words) - 1:
            bigram = f"{_clean(words[i])} {_clean(words[i+1])}"
            match = _fuzzy_match_known_values(bigram, known_brokers)
            if match:
                return match
    return None


def _find_institution_inline(text: str, known_institutions: list[str]) -> Optional[str]:
    """Mesma lógica de broker para instituições."""
    labeled = _find_labeled_field(text, FIELD_KEYWORDS["instituicao"])
    if labeled:
        match = _fuzzy_match_known_values(labeled, known_institutions)
        return match or _clean(labeled)

    words = text.split()
    for i, word in enumerate(words):
        candidate = _clean(word)
        match = _fuzzy_match_known_values(candidate, known_institutions)
        if match:
            return match
        if i < len(words) - 1:
            bigram = f"{_clean(words[i])} {_clean(words[i+1])}"
            match = _fuzzy_match_known_values(bigram, known_institutions)
            if match:
                return match
    return None


# ─── Parser principal ─────────────────────────────────────────────────────────

class MessageParser:
    """
    Parser inteligente offline.
    Recebe uma mensagem de texto e retorna um dicionário com os campos extraídos.
    """

    def __init__(self, known_brokers: list[str] = None,
                 known_institutions: list[str] = None):
        self.known_brokers = known_brokers or []
        self.known_institutions = known_institutions or []

    def update_known_values(self, brokers: list[str], institutions: list[str]):
        self.known_brokers = brokers
        self.known_institutions = institutions

    def parse(self, message: str) -> dict:
        """
        Retorna dict com os campos encontrados.
        Campos não encontrados terão valor None.
        """
        text = message.strip()

        result = {
            "nome": None,
            "email": None,
            "broker": None,
            "mesa": None,          # preenchido depois via planilha
            "instituicao": None,
            "conta": None,         # preenchido depois via planilha
            "uuid": None,
            "outros": {},
        }

        # Email — padrão bem definido, extrair primeiro
        result["email"] = _find_email(text)

        # Remover email do texto para não confundir outros parsers
        clean_text = re.sub(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}", "", text)

        # UUID
        result["uuid"] = _find_uuid(clean_text)

        # Nome
        result["nome"] = _find_name(clean_text)

        # Broker
        result["broker"] = _find_broker_inline(clean_text, self.known_brokers)

        # Instituição
        result["instituicao"] = _find_institution_inline(clean_text, self.known_institutions)

        # Conta (se vier explícito)
        conta_raw = _find_labeled_field(clean_text, FIELD_KEYWORDS["conta"])
        if conta_raw:
            result["conta"] = conta_raw

        # Mesa (se vier explícito)
        mesa_raw = _find_labeled_field(clean_text, FIELD_KEYWORDS["mesa"])
        if mesa_raw:
            result["mesa"] = mesa_raw

        return result

    def confidence_score(self, parsed: dict) -> int:
        """
        Retorna um score de confiança (0-100) baseado em quantos
        campos obrigatórios foram preenchidos.
        """
        required = ["nome", "email", "broker", "instituicao", "uuid"]
        filled = sum(1 for f in required if parsed.get(f))
        return int((filled / len(required)) * 100)
