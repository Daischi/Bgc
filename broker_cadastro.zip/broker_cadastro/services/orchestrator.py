"""
services/orchestrator.py
Orquestra o fluxo: parse → enriquecer → validar → salvar.
"""

from parser.message_parser import MessageParser
from excel.excel_handler import ExcelHandler
from validations.validator import FieldValidator, ValidationError
from logs.logger import get_logger

logger = get_logger(__name__)


class CadastroService:
    def __init__(self, excel_path: str):
        self.excel = ExcelHandler(excel_path)
        self.parser = MessageParser()
        self.validator = FieldValidator()
        self._loaded = False

    def load(self):
        """Carrega a planilha e atualiza o parser com valores conhecidos."""
        self.excel.load()
        self.parser.update_known_values(
            brokers=self.excel.get_known_brokers(),
            institutions=self.excel.get_known_institutions(),
        )
        self._loaded = True
        logger.info(
            f"Planilha carregada. Brokers: {self.excel.get_known_brokers()} | "
            f"Instituições: {self.excel.get_known_institutions()}"
        )

    def reload(self):
        """Recarrega a planilha (útil após salvar)."""
        self.load()

    def process_message(self, message: str) -> dict:
        """
        Passo 1-4 do fluxo: parse + enriquecimento automático.
        Retorna dict com todos os campos prontos para confirmação.
        """
        if not self._loaded:
            self.load()

        parsed = self.parser.parse(message)
        logger.info(f"Mensagem parseada: {parsed}")

        # Enriquecimento automático via planilha
        if parsed.get("broker") and not parsed.get("mesa"):
            parsed["mesa"] = self.excel.lookup_mesa(parsed["broker"])

        if parsed.get("instituicao") and not parsed.get("conta"):
            parsed["conta"] = self.excel.lookup_conta(parsed["instituicao"])

        confidence = self.parser.confidence_score(parsed)
        parsed["_confidence"] = confidence
        parsed["_warnings"] = []

        if confidence < 60:
            parsed["_warnings"].append(
                f"Confiança de extração baixa ({confidence}%). Verifique os campos manualmente."
            )

        logger.info(f"Dados enriquecidos (confiança {confidence}%): {parsed}")
        return parsed

    def check_duplicate(self, data: dict) -> bool:
        return self.excel.user_exists(
            email=data.get("email"),
            uuid=data.get("uuid")
        )

    def save(self, data: dict) -> tuple[bool, str, list[str]]:
        """
        Valida e salva na planilha.
        Retorna (sucesso, mensagem, avisos).
        """
        try:
            cleaned, warnings = self.validator.validate_all(data)
        except ValidationError as e:
            return False, str(e), []

        if self.check_duplicate(cleaned):
            return False, "Usuário já cadastrado (email ou UUID duplicado).", warnings

        row = self.excel.insert_user(cleaned)
        self.reload()  # Atualiza lookups com novo dado

        logger.info(f"Usuário salvo na linha {row}: {cleaned}")
        return True, f"Usuário cadastrado com sucesso na linha {row}.", warnings

    def get_known_brokers(self) -> list[str]:
        return self.excel.get_known_brokers()

    def get_known_institutions(self) -> list[str]:
        return self.excel.get_known_institutions()

    def get_column_map(self) -> dict:
        return self.excel.get_column_map()
