"""
excel/excel_handler.py
Leitura e escrita na planilha Excel.
Descobre automaticamente relações Broker→Mesa e Instituição→Conta.
"""

import os
from pathlib import Path
from typing import Optional
import pandas as pd
import openpyxl
from openpyxl.styles import PatternFill, Font
from rapidfuzz import fuzz, process


# Colunas esperadas (case-insensitive, com variações)
COLUMN_ALIASES = {
    "nome":       ["nome", "name", "usuario", "usuário", "colaborador"],
    "email":      ["email", "e-mail", "mail"],
    "broker":     ["broker", "corretora", "broker associado"],
    "mesa":       ["mesa", "desk"],
    "instituicao":["instituição", "instituicao", "institution", "banco"],
    "conta":      ["conta", "account"],
    "uuid":       ["uuid", "id", "código", "codigo"],
}


def _normalize(s: str) -> str:
    import unicodedata
    s = str(s).lower().strip()
    s = unicodedata.normalize("NFD", s)
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return s


class ExcelHandler:
    def __init__(self, filepath: str):
        self.filepath = Path(filepath)
        self._df: Optional[pd.DataFrame] = None
        self._col_map: dict[str, str] = {}   # campo→coluna real
        self._broker_mesa: dict[str, str] = {}
        self._inst_conta: dict[str, str] = {}

    # ── Carregamento ──────────────────────────────────────────────────────────

    def load(self):
        """Lê a planilha e mapeia colunas e relações automaticamente."""
        if not self.filepath.exists():
            self._create_template()

        self._df = pd.read_excel(self.filepath, dtype=str)
        self._df.fillna("", inplace=True)
        self._map_columns()
        self._build_lookup_tables()

    def _create_template(self):
        """Cria planilha template se não existir."""
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Usuários"

        headers = ["Nome", "Email", "Broker Associado", "Mesa",
                   "Instituição", "Conta", "UUID"]
        fill = PatternFill("solid", fgColor="1A3C5E")
        font = Font(color="FFFFFF", bold=True)

        for col, header in enumerate(headers, start=1):
            cell = ws.cell(row=1, column=col, value=header)
            cell.fill = fill
            cell.font = font
            ws.column_dimensions[openpyxl.utils.get_column_letter(col)].width = 20

        # Aba de referências
        ws_ref = wb.create_sheet("Referências")
        ws_ref["A1"], ws_ref["B1"] = "Broker", "Mesa"
        ws_ref["D1"], ws_ref["E1"] = "Instituição", "Conta"

        wb.save(self.filepath)
        self._df = pd.read_excel(self.filepath, dtype=str)
        self._df.fillna("", inplace=True)

    def _map_columns(self):
        """Mapeia nomes de campo interno → nome de coluna real na planilha."""
        real_cols = list(self._df.columns)
        norm_cols = {_normalize(c): c for c in real_cols}

        for field, aliases in COLUMN_ALIASES.items():
            for alias in aliases:
                key = _normalize(alias)
                if key in norm_cols:
                    self._col_map[field] = norm_cols[key]
                    break
            else:
                # Fuzzy fallback
                best = process.extractOne(
                    _normalize(aliases[0]),
                    list(norm_cols.keys()),
                    scorer=fuzz.token_sort_ratio
                )
                if best and best[1] >= 70:
                    self._col_map[field] = norm_cols[best[0]]

    def _build_lookup_tables(self):
        """
        Constrói lookup Broker→Mesa e Instituição→Conta
        lendo os dados JÁ existentes na planilha.
        Também tenta ler de uma aba 'Referências' se existir.
        """
        # Tenta aba de referências primeiro
        try:
            wb = openpyxl.load_workbook(self.filepath, read_only=True, data_only=True)
            if "Referências" in wb.sheetnames:
                ws = wb["Referências"]
                rows = list(ws.values)
                for row in rows[1:]:  # pula cabeçalho
                    if row[0] and row[1]:
                        self._broker_mesa[str(row[0]).strip()] = str(row[1]).strip()
                    if len(row) > 3 and row[3] and row[4]:
                        self._inst_conta[str(row[3]).strip()] = str(row[4]).strip()
            wb.close()
        except Exception:
            pass

        # Complementa com dados da planilha principal
        broker_col = self._col_map.get("broker")
        mesa_col = self._col_map.get("mesa")
        inst_col = self._col_map.get("instituicao")
        conta_col = self._col_map.get("conta")

        if broker_col and mesa_col:
            for _, row in self._df.iterrows():
                b, m = str(row.get(broker_col, "")), str(row.get(mesa_col, ""))
                if b and m and b not in self._broker_mesa:
                    self._broker_mesa[b] = m

        if inst_col and conta_col:
            for _, row in self._df.iterrows():
                i, c = str(row.get(inst_col, "")), str(row.get(conta_col, ""))
                if i and c and i not in self._inst_conta:
                    self._inst_conta[i] = c

    # ── Lookups ───────────────────────────────────────────────────────────────

    def get_known_brokers(self) -> list[str]:
        return list(self._broker_mesa.keys())

    def get_known_institutions(self) -> list[str]:
        return list(self._inst_conta.keys())

    def lookup_mesa(self, broker: str) -> Optional[str]:
        if not broker:
            return None
        # Exact
        if broker in self._broker_mesa:
            return self._broker_mesa[broker]
        # Fuzzy
        best = process.extractOne(broker, list(self._broker_mesa.keys()),
                                   scorer=fuzz.token_sort_ratio)
        if best and best[1] >= 75:
            return self._broker_mesa[best[0]]
        return None

    def lookup_conta(self, instituicao: str) -> Optional[str]:
        if not instituicao:
            return None
        if instituicao in self._inst_conta:
            return self._inst_conta[instituicao]
        best = process.extractOne(instituicao, list(self._inst_conta.keys()),
                                   scorer=fuzz.token_sort_ratio)
        if best and best[1] >= 75:
            return self._inst_conta[best[0]]
        return None

    # ── Validações ────────────────────────────────────────────────────────────

    def user_exists(self, email: str = None, uuid: str = None) -> bool:
        """Verifica duplicidade por email ou UUID."""
        if self._df is None:
            return False
        email_col = self._col_map.get("email")
        uuid_col = self._col_map.get("uuid")

        if email and email_col:
            mask = self._df[email_col].str.lower() == email.lower()
            if mask.any():
                return True
        if uuid and uuid_col:
            mask = self._df[uuid_col].str.strip() == str(uuid).strip()
            if mask.any():
                return True
        return False

    # ── Escrita ───────────────────────────────────────────────────────────────

    def insert_user(self, data: dict) -> int:
        """
        Insere o usuário na planilha.
        Retorna o número da linha inserida.
        """
        wb = openpyxl.load_workbook(self.filepath)
        ws = wb.active

        # Descobre a próxima linha vazia
        next_row = ws.max_row + 1

        # Monta mapeamento coluna-índice
        header_map = {}
        for col in ws.iter_cols(1, ws.max_column, 1, 1):
            cell = col[0]
            if cell.value:
                header_map[_normalize(str(cell.value))] = cell.column

        field_to_excel = {
            "nome":        "nome",
            "email":       "email",
            "broker":      "broker associado",
            "mesa":        "mesa",
            "instituicao": "instituição",
            "conta":       "conta",
            "uuid":        "uuid",
        }

        for field, excel_label in field_to_excel.items():
            value = data.get(field, "")
            if not value:
                continue
            col_idx = header_map.get(_normalize(excel_label))
            if col_idx:
                ws.cell(row=next_row, column=col_idx, value=value)

        # Campos extras (outros)
        for k, v in data.get("outros", {}).items():
            norm_k = _normalize(k)
            col_idx = header_map.get(norm_k)
            if col_idx and v:
                ws.cell(row=next_row, column=col_idx, value=v)

        wb.save(self.filepath)

        # Recarrega o DataFrame em memória
        self._df = pd.read_excel(self.filepath, dtype=str)
        self._df.fillna("", inplace=True)

        return next_row

    def get_column_map(self) -> dict:
        return self._col_map.copy()
