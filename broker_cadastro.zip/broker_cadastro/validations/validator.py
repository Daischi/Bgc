"""
validations/validator.py
Validações de campos antes de salvar.
"""

import re
from typing import Optional


class ValidationError(Exception):
    pass


class FieldValidator:

    REQUIRED_FIELDS = ["nome", "email", "broker", "uuid"]

    @staticmethod
    def validate_email(email: Optional[str]) -> str:
        if not email:
            raise ValidationError("Email é obrigatório.")
        pattern = r"^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$"
        if not re.match(pattern, email.strip()):
            raise ValidationError(f"Email inválido: '{email}'")
        return email.strip().lower()

    @staticmethod
    def validate_uuid(uuid: Optional[str]) -> str:
        if not uuid:
            raise ValidationError("UUID é obrigatório.")
        clean = str(uuid).strip()
        if not re.match(r"^\d+$", clean):
            raise ValidationError(
                f"UUID deve ser um número inteiro. Recebido: '{uuid}'"
            )
        if len(clean) < 6:
            raise ValidationError(
                f"UUID muito curto (mínimo 6 dígitos). Recebido: '{uuid}'"
            )
        return clean

    @staticmethod
    def validate_nome(nome: Optional[str]) -> str:
        if not nome or len(nome.strip()) < 2:
            raise ValidationError("Nome é obrigatório e deve ter ao menos 2 caracteres.")
        return nome.strip()

    @staticmethod
    def validate_broker(broker: Optional[str]) -> str:
        if not broker or len(broker.strip()) < 1:
            raise ValidationError("Broker Associado é obrigatório.")
        return broker.strip()

    def validate_all(self, data: dict) -> tuple[dict, list[str]]:
        """
        Valida todos os campos.
        Retorna (data_limpo, lista_de_avisos).
        Levanta ValidationError para erros críticos.
        """
        warnings = []
        cleaned = dict(data)

        cleaned["nome"] = self.validate_nome(data.get("nome"))
        cleaned["email"] = self.validate_email(data.get("email"))
        cleaned["broker"] = self.validate_broker(data.get("broker"))
        cleaned["uuid"] = self.validate_uuid(data.get("uuid"))

        if not data.get("mesa"):
            warnings.append("Mesa não encontrada para este broker. Verifique a planilha de referências.")
        if not data.get("instituicao"):
            warnings.append("Instituição não informada.")
        if not data.get("conta"):
            warnings.append("Conta não encontrada para esta instituição. Verifique a planilha de referências.")

        return cleaned, warnings
