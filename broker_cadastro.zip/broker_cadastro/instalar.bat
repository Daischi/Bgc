@echo off
echo =========================================
echo   Broker Cadastro - Instalacao
echo =========================================
echo.

REM Verifica se Python esta instalado
python --version >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    echo ERRO: Python nao encontrado.
    echo Instale Python 3.10+ em: https://www.python.org/downloads/
    pause
    exit /b 1
)

echo [OK] Python encontrado.
echo.

REM Instala dependencias
echo Instalando dependencias...
pip install -r requirements.txt

IF %ERRORLEVEL% NEQ 0 (
    echo ERRO ao instalar dependencias.
    pause
    exit /b 1
)

echo.
echo [OK] Dependencias instaladas com sucesso!
echo.
echo Para iniciar o sistema, execute:  python main.py
echo Ou clique duas vezes em:          iniciar.bat
echo.
pause
