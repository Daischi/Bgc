"""
logs/logger.py
Sistema de log com rotação diária e exportação de erros.
"""

import logging
import logging.handlers
import json
import os
from pathlib import Path
from datetime import datetime

LOG_DIR = Path(__file__).parent / "files"
LOG_DIR.mkdir(exist_ok=True)

HISTORY_FILE = LOG_DIR / "historico_cadastros.jsonl"
ERROR_FILE = LOG_DIR / "erros.jsonl"


def get_logger(name: str) -> logging.Logger:
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger  # já configurado

    logger.setLevel(logging.DEBUG)

    # Arquivo com rotação diária
    fh = logging.handlers.TimedRotatingFileHandler(
        LOG_DIR / "app.log", when="midnight", backupCount=30, encoding="utf-8"
    )
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter(
        "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    ))

    # Console
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    ch.setFormatter(logging.Formatter("[%(levelname)s] %(message)s"))

    logger.addHandler(fh)
    logger.addHandler(ch)
    return logger


def log_success(data: dict):
    entry = {
        "timestamp": datetime.now().isoformat(),
        "status": "success",
        "data": {k: v for k, v in data.items() if not k.startswith("_")},
    }
    with open(HISTORY_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")


def log_error(message: str, data: dict = None):
    entry = {
        "timestamp": datetime.now().isoformat(),
        "status": "error",
        "message": message,
        "data": data or {},
    }
    with open(ERROR_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")


def load_history() -> list[dict]:
    if not HISTORY_FILE.exists():
        return []
    entries = []
    with open(HISTORY_FILE, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    entries.append(json.loads(line))
                except Exception:
                    pass
    return entries
