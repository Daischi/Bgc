#!/usr/bin/env python3
"""
main.py — Ponto de entrada do sistema Broker Cadastro
"""

import sys
import os
from pathlib import Path

# Permite rodar de qualquer pasta
sys.path.insert(0, str(Path(__file__).parent))

def main():
    excel_path = None

    # Argumento de linha de comando opcional
    if len(sys.argv) > 1:
        excel_path = sys.argv[1]
        if not Path(excel_path).exists():
            print(f"Arquivo não encontrado: {excel_path}")
            sys.exit(1)

    from ui.app import run
    run(excel_path=excel_path)


if __name__ == "__main__":
    main()
